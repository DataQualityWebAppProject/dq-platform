"""Cleaning Glue job scripts."""
