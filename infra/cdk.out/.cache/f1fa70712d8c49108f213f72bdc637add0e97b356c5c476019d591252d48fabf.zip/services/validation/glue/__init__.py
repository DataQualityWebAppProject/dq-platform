"""Validation Glue job scripts."""
