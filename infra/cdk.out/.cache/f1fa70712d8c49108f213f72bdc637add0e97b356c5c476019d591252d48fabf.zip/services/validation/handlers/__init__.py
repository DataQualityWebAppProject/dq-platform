"""Validation Service Lambda handlers."""
