"""Anomaly detection training scripts."""
