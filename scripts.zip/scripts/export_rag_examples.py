#!/usr/bin/env python3
"""Export B1 syntax-pass predictions as RAG examples for B2.

Also exports HISTORICAL B1 predictions for B2 historical run.

Usage:
    python scripts/export_rag_examples.py
"""
from __future__ import annotations

import json
import pathlib
import sys

import pandas as pd

_REPO = pathlib.Path(__file__).resolve().parent.parent

RAG_DIR = _REPO / "data" / "rag"
RAG_DIR.mkdir(parents=True, exist_ok=True)


def export_rag_from_parquet(parquet_path: pathlib.Path, output_path: pathlib.Path) -> int:
    if not parquet_path.exists():
        print(f"  SKIP: {parquet_path} not found")
        return 0
    df = pd.read_parquet(parquet_path)
    ok = df[df["syntax_pass"] == True][["rule_id", "nl_text", "dimension", "generated_code"]]
    count = 0
    with open(output_path, "w", encoding="utf-8") as f:
        for _, row in ok.iterrows():
            rec = {
                "rule_id": str(row["rule_id"]),
                "nl_text": str(row["nl_text"]),
                "dimension": str(row["dimension"]),
                "generated_code": str(row["generated_code"]),
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            count += 1
    return count


def main() -> int:
    # POINT_IN_TIME examples from B1
    pt_parquet = _REPO / "artifacts" / "predictions" / "pilot" / "B1" / "predictions.parquet"
    pt_out = RAG_DIR / "train_b2_examples.jsonl"
    n_pt = export_rag_from_parquet(pt_parquet, pt_out)
    print(f"POINT_IN_TIME RAG examples: {n_pt} -> {pt_out}")

    # HISTORICAL examples from B1_historical
    h_parquet = _REPO / "artifacts" / "predictions" / "pilot" / "B1_historical" / "predictions.parquet"
    h_out = RAG_DIR / "train_b2_historical_examples.jsonl"
    n_h = export_rag_from_parquet(h_parquet, h_out)
    print(f"HISTORICAL RAG examples: {n_h} -> {h_out}")

    print(f"\nTotal RAG examples: {n_pt + n_h}")
    print(f"\nNext commands:")
    print(f"  # POINT_IN_TIME (B2 with RAG):")
    print(f"  python scripts/run_inference_pilot.py --rules data/rules/pilot_reviewed_20.jsonl --config B2 --rag-file data/rag/train_b2_examples.jsonl")
    print(f"")
    print(f"  # HISTORICAL (B2 with RAG):")
    print(f"  python scripts/run_inference_pilot.py --rules data/rules/pilot_historical_rules.jsonl --config B2 --rag-file data/rag/train_b2_examples.jsonl --tag historical")
    print(f"")
    print(f"  # After inference, compute metrics:")
    print(f"  python scripts/compute_metrics.py --config B2 --rules data/rules/pilot_reviewed_20.jsonl")
    print(f"  python scripts/compute_metrics.py --config B2_historical --rules data/rules/pilot_historical_rules.jsonl")
    return 0


if __name__ == "__main__":
    sys.exit(main())
