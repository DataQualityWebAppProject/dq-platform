#!/usr/bin/env python3
"""Registry audit: verify 200 eligible datasets exist or emit a deficit report.

Usage:
    python scripts/audit_registry.py [--registry-path PATH] [--target 200]

Per the research integrity rules:
- NEVER invent or pad the count.
- If fewer than TARGET eligible datasets are in the registry, emit a deficit
  report and exit with code 1.
- If TARGET datasets are present, freeze the registry and exit with code 0.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

from data_registry.registry import load_registry, freeze_registry


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry-path", default=str(_REPO_ROOT / "data/registry/datasets.csv"))
    parser.add_argument("--target", type=int, default=200)
    parser.add_argument("--phase", default="full", choices=["pilot-20", "pilot-50", "full"])
    parser.add_argument("--deficit-report-path", default=str(_REPO_ROOT / "reports/registry_deficit.md"))
    args = parser.parse_args()

    records = load_registry(args.registry_path)
    eligible = [r for r in records if r.eligible]
    n = len(eligible)

    print(f"Registry: {n} eligible datasets (target: {args.target})")

    if n >= args.target:
        out = freeze_registry(eligible[: args.target], phase=args.phase)
        print(f"FROZEN: {out}")
        return 0

    # Deficit — emit report and exit 1
    deficit = args.target - n
    report_path = Path(args.deficit_report_path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report = (
        f"# Registry Deficit Report\n\n"
        f"**Date:** {datetime.now(timezone.utc).isoformat()}\n"
        f"**Target:** {args.target} eligible datasets\n"
        f"**Found:** {n} eligible datasets\n"
        f"**Deficit:** {deficit} datasets missing\n\n"
        "## Status\n\n"
        "The full-run cannot proceed until the registry contains "
        f"{args.target} eligible datasets.\n\n"
        "## Action Required\n\n"
        "1. Run `make pilot-50` to search and evaluate additional Kaggle datasets.\n"
        "2. Add eligible datasets to `data/registry/datasets.csv` via `freeze_registry()`.\n"
        "3. Re-run this script until the deficit is zero.\n\n"
        "## Integrity Note\n\n"
        "The count has NOT been falsified. "
        f"Only {n} datasets are present; {deficit} are genuinely missing.\n"
        "Do not add placeholder or synthetic entries to inflate the count.\n"
    )
    report_path.write_text(report, encoding="utf-8")
    print(f"DEFICIT REPORT written to: {report_path}")
    print(f"ERROR: Only {n}/{args.target} eligible datasets. {deficit} missing.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
