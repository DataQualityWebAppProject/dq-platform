import pandas as pd
import pathlib

base = pathlib.Path("artifacts/metrics/pilot")
files = sorted(base.glob("*_metrics.parquet"))
for f in files:
    df = pd.read_parquet(f)
    valid = df[df["f1"].notna()]
    n_datasets = df["dataset_id"].nunique()
    print(f"{f.stem:<40} n={len(df):>3} n_valid={len(valid):>3} datasets={n_datasets:>3}")
