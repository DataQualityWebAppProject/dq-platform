#!/usr/bin/env python3
"""B5 prerequisite test: check IR schema compatibility and TDD agent.

Tests:
  1. ir_gold scope/logic structure from pilot_reviewed_20.jsonl
  2. ir_gold scope/logic structure from pilot_historical_rules.jsonl
  3. TDD agent generates >=3 tests for a PT rule
  4. TDD agent generates >=3 tests for a HIST rule
  5. IR model_validate works with both PT and HIST ir_gold

Usage:
    python scripts/test_b5_prereqs.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO / "src"))


def check_ir_schema(rule: dict, label: str) -> dict:
    """Try to model_validate the ir_gold and return results."""
    from models.ir import IR
    ir = rule.get("ir_gold", {})
    result = {"rule_id": rule["rule_id"], "label": label, "ir_keys": list(ir.keys())}

    # Check scope type
    scope = ir.get("scope", {})
    result["scope_type"] = type(scope).__name__
    if isinstance(scope, dict):
        result["scope_cols"] = scope.get("columns", [])
    elif isinstance(scope, list):
        result["scope_cols"] = scope
    else:
        result["scope_cols"] = []

    # Check logic type
    logic = ir.get("logic", {})
    result["logic_type"] = type(logic).__name__
    result["logic_operator"] = logic.get("operator", "?") if isinstance(logic, dict) else "list"

    # Try model_validate
    try:
        validated = IR.model_validate(ir)
        result["ir_valid"] = True
        result["ir_error"] = ""
    except Exception as e:
        result["ir_valid"] = False
        result["ir_error"] = str(e)[:100]

    return result


def test_tdd_agent(rule: dict, label: str) -> dict:
    """Test TDD agent with this rule's ir_gold."""
    from agents.tdd_agent import generate_tdd_tests

    ir = rule.get("ir_gold", {})
    scope = ir.get("scope", {})
    cols = scope.get("columns", []) if isinstance(scope, dict) else (scope if isinstance(scope, list) else [])

    try:
        result_ag = generate_tdd_tests(ir_payload=ir, dataset_columns=cols)
        # Only count diagnostics with level="error" or "warning" as errors
        error_diags = [
            d["message"] for d in result_ag.diagnostics
            if d.get("level", "info") in ("error", "warning")
        ]
        return {
            "rule_id": rule["rule_id"],
            "label": label,
            "status": result_ag.status,
            "n_tests": len(result_ag.payload.get("tdd_tests", [])),
            "error": error_diags[0] if error_diags else "",
        }
    except Exception as e:
        return {
            "rule_id": rule["rule_id"],
            "label": label,
            "status": "EXCEPTION",
            "n_tests": 0,
            "error": str(e)[:100],
        }


def main() -> int:
    print("=== B5 PREREQUISITE CHECK ===\n")

    # Load rules
    pt_rules = []
    with open(_REPO / "data/rules/pilot_reviewed_20.jsonl", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                pt_rules.append(json.loads(line))

    hist_rules = []
    with open(_REPO / "data/rules/pilot_historical_rules.jsonl", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                hist_rules.append(json.loads(line))

    print(f"PT rules: {len(pt_rules)} | HIST rules: {len(hist_rules)}\n")

    # Check IR schema for first 3 of each
    print("--- IR schema check ---")
    all_rules = pt_rules[:3] + hist_rules[:3]
    schema_errors = 0
    for rule in all_rules:
        label = "PT" if rule["rule_id"].startswith("R-0") else "HIST"
        res = check_ir_schema(rule, label)
        icon = "✓" if res["ir_valid"] else "✗"
        print(f"  {icon} {res['rule_id']} ({label}): scope={res['scope_type']} cols={res['scope_cols'][:2]}, logic_op={res['logic_operator']}, valid={res['ir_valid']}", end="")
        if not res["ir_valid"]:
            print(f"  ERR: {res['ir_error']}", end="")
            schema_errors += 1
        print()

    print()
    # Test TDD agent for first 2 of each
    print("--- TDD agent check ---")
    tdd_errors = 0
    for rule in pt_rules[:2] + hist_rules[:2]:
        label = "PT" if rule["rule_id"].startswith("R-0") else "HIST"
        res = test_tdd_agent(rule, label)
        icon = "✓" if res["status"] == "OK" else "✗"
        print(f"  {icon} {res['rule_id']} ({label}): status={res['status']}, n_tests={res['n_tests']}", end="")
        if res["status"] not in ("OK",) or res["error"]:
            if res["error"]:
                print(f"  ERR: {res['error']}", end="")
            if res["status"] not in ("OK",):
                tdd_errors += 1
        print()

    print()
    print("=== SUMMARY ===")
    print(f"IR schema errors  : {schema_errors}/{len(all_rules)}")
    print(f"TDD agent errors  : {tdd_errors}/4")

    if schema_errors > 0 or tdd_errors > 0:
        print(f"\nFIXES NEEDED: {schema_errors} schema errors, {tdd_errors} TDD errors.")
        return 1
    else:
        print(f"\nAll checks passed ({len(all_rules)} IR schemas OK, TDD OK). Ready to run B5.")
        print("  python scripts/run_b5_inference.py --rules data/rules/pilot_reviewed_20.jsonl")
        return 0


if __name__ == "__main__":
    sys.exit(main())
