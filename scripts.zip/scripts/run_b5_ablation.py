#!/usr/bin/env python3
"""B5 incremental forward ablation — 9 variants.

Starts from B0 (no pipeline) and adds one component at a time:

  abl0_B0_base     : B0 prompt only (no pipeline at all)
  abl1_+CAN        : + canonicalisation (Stage 1 IR normalisation)
  abl2_+SCOPE      : + scope resolution (Stage 2: verify columns exist)
  abl3_+EVID       : + evidence location (Stage 3: sample values)
  abl4_+PLAN       : + logical planning (Stage 4: operator+clauses enrichment)
  abl5_+TEST       : + TDD test generation (Stage 5a: tests in prompt)
  abl6_+AST        : + AST guard (Stage 6: static analysis)
  abl7_+EXEC       : + sandbox execution (Stage 7: isolated run)
  abl8_+REPAIR     : + repair loop (Stage 9: iterative fix) = B5 full
  abl9_+META       : + metamorphic validation (Stage 10) [proxy: always VALIDATED]

Each variant saves predictions to:
  artifacts/predictions/pilot/{variant_name}/predictions.parquet

Usage (run ALL variants sequentially — use overnight):
  python scripts/run_b5_ablation.py --rules data/rules/pilot_reviewed_20.jsonl
  python scripts/run_b5_ablation.py --rules data/rules/pilot_rules_200_eligible.jsonl --tag ext

Usage (run ONE specific variant):
  python scripts/run_b5_ablation.py --rules data/rules/pilot_reviewed_20.jsonl --variant abl1_+CAN
  python scripts/run_b5_ablation.py --rules data/rules/pilot_reviewed_20.jsonl --variant abl4_+PLAN

Variant definitions (what each level ADDS vs the previous):
  abl0: raw B0 prompt, no IR enrichment, no TDD, no AST, no sandbox, no repair
  abl1: adds _canonicalize_ir() → IR from ir_gold or LLM
  abl2: adds scope-aware column hints in prompt (columns from IR)
  abl3: adds evidence-aware sample values hint in prompt
  abl4: adds logical planner enrichment (operator+clauses)
  abl5: adds TDD test code appended to prompt
  abl6: adds AST guard (rejects bad imports; repair if AST fails)
  abl7: adds sandbox execution (runs code, captures error)
  abl8: adds repair loop on sandbox failure = B5 full
  abl9: adds metamorphic validation flag (proxy: no re-run needed, marks VALIDATED if passes)
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

_REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO / "src"))

_IM_START = "<|im_start|>"
_IM_END   = "<|im_end|>"

_CODE_HEADER = (
    "import pandas as pd\n"
    "import re\n"
    "import math\n"
    "from datetime import datetime, date\n"
)

_SYSTEM_CODE = (
    "You are a Python data quality expert. "
    "Write ONLY a Python function `check(df)` that receives a pandas DataFrame "
    "and returns a list[int] of violating row indices (df.index values). "
    "Rules by dimension:\n"
    "- validity: check range/format/enum constraints row by row\n"
    "- uniqueness: ALWAYS use df[df.duplicated(subset=['col'], keep=False)].index.tolist()\n"
    "- consistency: mask = df['col_a'] >= df['col_b']; return df[mask].index.tolist()\n"
    "- completeness: df[df['col'].isna()].index.tolist()\n"
    "- timeliness: pd.to_datetime(df['col'], errors='coerce'), compare Timestamps.\n"
    "Return [] if rule not applicable or column missing. "
    "No explanation. No markdown. Just the function."
)

_SYSTEM_REPAIR = (
    "You are a Python debugging expert. Fix the provided check(df) function. "
    "- Never use int() on datetime strings — use pd.to_datetime(..., errors='coerce')\n"
    "- For uniqueness: df.duplicated(subset=['col'], keep=False)\n"
    "Only change what is necessary. No explanation. No markdown. Just the function."
)

_DIM_HINTS = {
    "uniqueness": "CRITICAL: mask = df.duplicated(subset=['<col>'], keep=False)\nreturn df[mask].index.tolist()",
    "consistency": "CRITICAL: a = pd.to_datetime(df['col_a'], errors='coerce')\nb = pd.to_datetime(df['col_b'], errors='coerce')\nmask = a.notna() & b.notna() & (a >= b)\nreturn df[mask].index.tolist()",
    "timeliness": "CRITICAL: Always pd.to_datetime(df['col'], errors='coerce'). NEVER int() on date strings.",
    "validity": "For range: mask = (df['col'] < min_val) | (df['col'] > max_val)\nFor unix: compare as numbers.\nFor enum: mask = ~df['col'].isin(['val1','val2'])",
    "completeness": "mask = df['col'].isna()\nreturn df[mask].index.tolist()",
}

_REPAIR_HINTS = {
    "timeliness": "HINT: pd.to_datetime(df['col'], errors='coerce'). Never int() on date strings.",
    "consistency": "HINT: pd.to_datetime(..., errors='coerce'). mask = df['col_a'] >= df['col_b']",
    "uniqueness": "HINT: df[df.duplicated(subset=['col'], keep=False)].index.tolist()",
    "validity": "HINT: For unix compare as numbers. For dates pd.to_datetime(..., errors='coerce').",
    "completeness": "HINT: df[df['col'].isna()].index.tolist()",
}

VARIANTS = [
    "abl0_B0_base",
    "abl1_+CAN",
    "abl2_+SCOPE",
    "abl3_+EVID",
    "abl4_+PLAN",
    "abl5_+TEST",
    "abl6_+AST",
    "abl7_+EXEC",
    "abl8_+REPAIR",
    "abl9_+META",
]


# ── Helpers (shared with run_b5_inference.py) ─────────────────────────────────

def _sha256_str(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def _load_rules(path: str) -> list[dict]:
    rules = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rules.append(json.loads(line))
    return rules


def _check_syntax(code: str) -> tuple[bool, str]:
    try:
        ast.parse(code)
        return True, ""
    except SyntaxError as e:
        return False, str(e)


def _extract_code(raw: str) -> str:
    primed = _CODE_HEADER + raw

    def _try(code: str):
        try:
            ast.parse(code)
            if "def check" in code:
                return code.strip()
        except SyntaxError:
            pass
        return None

    for fence in ["```python", "```"]:
        idx = primed.find(fence)
        if idx != -1:
            s = idx + len(fence)
            e = primed.find("```", s)
            if e != -1:
                r = _try(_CODE_HEADER + primed[s:e].strip())
                if r:
                    return r

    lines, fn_lines, in_fn = primed.split("\n"), [], False
    for line in lines:
        if line.strip().startswith("def check(") or line.strip().startswith("def check ("):
            in_fn = True
        if in_fn:
            fn_lines.append(line)
    if fn_lines:
        r = _try(_CODE_HEADER + "\n".join(fn_lines))
        if r:
            return r
    r = _try(primed)
    if r:
        return r
    return _CODE_HEADER + "\ndef check(df):\n    return []\n"


def _ast_guard(code: str) -> tuple[bool, list[str]]:
    DENIED = frozenset({"os", "subprocess", "socket", "requests", "urllib", "http",
                        "shutil", "pathlib", "pickle", "marshal"})
    DENIED_BUILTINS = frozenset({"eval", "exec", "compile", "__import__", "open"})
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return False, [f"SyntaxError: {e}"]
    violations = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            mods = [a.name for a in getattr(node, "names", [])]
            mod = getattr(node, "module", "") or ""
            for m in mods + [mod]:
                root = m.split(".")[0]
                if root in DENIED:
                    violations.append(f"Denied import: {m}")
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in DENIED_BUILTINS:
                violations.append(f"Denied call: {node.func.id}")
    return len(violations) == 0, violations


def _run_sandbox(code: str, df_sample: pd.DataFrame, timeout: int = 20):
    with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tf:
        sample_path = tf.name
    try:
        df_sample.to_parquet(sample_path, index=True)
        wrapper = (
            "import pandas as pd, json, sys\n"
            + code
            + "\ntry:\n"
            "    df = pd.read_parquet('" + sample_path.replace("\\", "\\\\") + "')\n"
            "    result = check(df)\n"
            "    if isinstance(result, (list, tuple)):\n"
            "        print(json.dumps({'flagged': list(result)}))\n"
            "    else:\n"
            "        print(json.dumps({'flagged': []}))\n"
            "except Exception as e:\n"
            "    print(json.dumps({'error': str(e)}))\n"
            "    sys.exit(1)\n"
        )
        proc = subprocess.run([sys.executable, "-c", wrapper],
                              capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, f"TimeoutExpired ({timeout}s)", []
    except Exception as e:
        return False, str(e), []
    finally:
        try:
            os.unlink(sample_path)
        except OSError:
            pass
    if proc.returncode != 0:
        return False, (proc.stderr.strip()[-400:] if proc.stderr else "non-zero exit"), []
    try:
        out = json.loads(proc.stdout)
        if "error" in out:
            return False, out["error"][:400], []
        return True, "", [int(x) for x in out.get("flagged", [])]
    except Exception as e:
        return False, f"JSON parse error: {e}", []


def _llm_generate(tokenizer, model, prompt: str, max_new_tokens: int = 512) -> str:
    import torch
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_new_tokens,
                             do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)


def _load_dataset_sample(rule: dict, n: int = 200):
    dataset_id = rule.get("dataset_id", "")
    if not dataset_id or "/" not in dataset_id:
        return None
    owner, slug = dataset_id.split("/", 1)
    raw_dir = _REPO / "data" / "raw" / owner / slug / "vlatest" / "raw"
    if not raw_dir.exists():
        return None
    csvs = list(raw_dir.glob("*.csv"))
    if not csvs:
        return None
    try:
        return pd.read_csv(csvs[0], nrows=n, low_memory=False)
    except Exception:
        return None


def _canonicalize_ir(rule: dict) -> dict:
    try:
        from agents.canonicalizer import canonicalize
        result = canonicalize(rule.get("nl_text", ""), rule.get("ir_gold"))
        if result.status == "OK":
            return result.payload.get("ir", rule.get("ir_gold", {}))
    except Exception:
        pass
    return rule.get("ir_gold", {})


def _run_logical_planner(ir: dict) -> dict:
    try:
        from agents.logical_planner import plan
        result = plan(ir)
        if result.status == "OK":
            return {**ir, **result.payload.get("plan", {})}
    except Exception:
        pass
    return ir


def _run_tdd_agent(rule: dict, ir: dict):
    try:
        from agents.tdd_agent import generate_tdd_tests
        scope = ir.get("scope", {})
        cols = scope.get("columns", []) if isinstance(scope, dict) else (scope if isinstance(scope, list) else [])
        tdd_result = generate_tdd_tests(ir_payload=ir, dataset_columns=cols)
        if tdd_result.status == "OK":
            return (tdd_result.payload.get("tdd_tests", []),
                    tdd_result.payload.get("test_code", ""))
    except Exception:
        pass
    return [], ""


def _make_prompt(rule: dict, ir: dict, tdd_code: str,
                 use_scope: bool, use_evid: bool,
                 use_plan: bool, use_tdd: bool) -> str:
    """Build code generation prompt with only the enabled components."""

    # abl0/abl1: just rule text — no IR enrichment
    # abl2 (use_scope): add columns from IR scope
    # abl3 (use_evid): add sample values hint (evidence)
    # abl4 (use_plan): add operator + clauses from planner
    # abl5 (use_tdd): add TDD test code

    dim = ir.get("dimension", rule.get("dimension", "validity")) if (use_plan or use_scope) else rule.get("dimension", "validity")
    complexity = ir.get("complexity", rule.get("complexity", "POINT_IN_TIME")) if use_plan else rule.get("complexity", "POINT_IN_TIME")
    dim_hint = _DIM_HINTS.get(dim, "")

    user_parts = [
        f"Dataset: {rule['dataset_id']}",
        f"Rule: {rule['nl_text']}",
        f"Dimension: {dim}",
    ]

    if use_plan:
        user_parts.append(f"Complexity: {complexity}")

    if use_scope:
        scope = ir.get("scope", {})
        cols = scope.get("columns", []) if isinstance(scope, dict) else []
        user_parts.append(f"Columns: {', '.join(cols) if cols else 'see rule'}")

    if use_evid:
        # Evidence: add a hint about the dataset structure from sample values
        # (In this proxy, we add the column types from ir_gold if available)
        ir_gold = rule.get("ir_gold", {})
        ev_cols = []
        if isinstance(ir_gold.get("scope"), dict):
            ev_cols = ir_gold["scope"].get("columns", [])
        if ev_cols:
            user_parts.append(f"Target columns (evidence): {', '.join(ev_cols)}")

    if use_plan:
        logic = ir.get("logic", {})
        operator = logic.get("operator", "AND") if isinstance(logic, dict) else "AND"
        clauses = logic.get("clauses", []) if isinstance(logic, dict) else []
        clause_strs = []
        for c in clauses[:8]:
            if isinstance(c, dict):
                parts = [f"{k}={v}" for k, v in c.items()]
                clause_strs.append("{" + ", ".join(parts) + "}")
        clauses_str = ", ".join(clause_strs) if clause_strs else "see rule"
        non_app = ir.get("non_applicability_condition") or ir.get("non_applicability") or ""
        if isinstance(non_app, dict):
            non_app = non_app.get("condition", "")
        user_parts.append(f"Logic operator: {operator}")
        user_parts.append(f"Clauses: {clauses_str}")
        if non_app and str(non_app).lower() not in ("never", "none", ""):
            user_parts.append(f"Non-applicability: {non_app}")

    user_parts.append(f"\n{dim_hint}")

    if use_tdd and tdd_code:
        user_parts.append("\n# TDD tests — your check(df) MUST pass all of these:")
        user_parts.append(tdd_code[:1400])

    user_parts.append("\nWrite check(df):")
    user = "\n".join(user_parts)
    return (
        f"{_IM_START}system\n{_SYSTEM_CODE}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n"
        + _CODE_HEADER
    )


def _make_repair_prompt(code: str, error: str, rule: dict) -> str:
    dim = rule.get("dimension", "validity")
    hint = _REPAIR_HINTS.get(dim, "")
    user = (
        f"Rule: {rule['nl_text']}\nDimension: {dim}\nDataset: {rule['dataset_id']}\n\n"
        f"Failed code:\n```python\n{code[:900]}\n```\n\n"
        f"Error:\n{error[:400]}\n\n{hint}\n\n"
        "Provide the corrected check(df) function:"
    )
    return (
        f"{_IM_START}system\n{_SYSTEM_REPAIR}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n" + _CODE_HEADER
    )


# ── Per-variant logic ─────────────────────────────────────────────────────────

def run_variant(variant: str, rules: list[dict], tokenizer, model,
                max_repair: int = 5) -> list[dict]:
    """Run one ablation variant and return predictions list."""

    # Parse variant flags
    level = int(variant[3])  # abl0 → 0, abl1 → 1, ...
    use_can   = level >= 1
    use_scope = level >= 2
    use_evid  = level >= 3
    use_plan  = level >= 4
    use_tdd   = level >= 5
    use_ast   = level >= 6
    use_exec  = level >= 7
    use_repair = level >= 8
    # level 9 = +META: same as 8 but marks VALIDATED for all sandbox_ok rules
    #           (metamorphic check is idempotency/monotonicity — proxy: always pass)

    predictions = []
    for rule in rules:
        rule_id = rule["rule_id"]
        t_start = time.monotonic()
        pipeline_stages = []
        repair_attempts = 0
        tdd_n_tests = 0

        # Stage 1: Canonicalise
        if use_can:
            ir = _canonicalize_ir(rule)
            pipeline_stages.append("S1:canonicalized")
        else:
            ir = rule.get("ir_gold", {})
            pipeline_stages.append("S1:skipped")

        # Stages 2-3: Scope + Evidence (affect prompt only)
        if use_scope:
            pipeline_stages.append("S2:scoped")
        else:
            pipeline_stages.append("S2:skipped")

        if use_evid:
            pipeline_stages.append("S3:evidence")
        else:
            pipeline_stages.append("S3:skipped")

        # Stage 4: Logical Planner
        if use_plan:
            ir = _run_logical_planner(ir)
            pipeline_stages.append("S4:planned")
        else:
            pipeline_stages.append("S4:skipped")

        # Stage 5a: TDD
        tdd_tests, tdd_code = [], ""
        if use_tdd:
            tdd_tests, tdd_code = _run_tdd_agent(rule, ir)
            tdd_n_tests = len(tdd_tests)
            pipeline_stages.append(f"S5a:tdd(n={tdd_n_tests})")
        else:
            pipeline_stages.append("S5a:skipped")

        # Stage 5b: Code Generation
        prompt = _make_prompt(rule, ir, tdd_code,
                              use_scope=use_scope, use_evid=use_evid,
                              use_plan=use_plan, use_tdd=use_tdd)
        raw = _llm_generate(tokenizer, model, prompt)
        code = _extract_code(raw)
        pipeline_stages.append("S5b:generated")

        # Stage 6: AST Guard
        ast_ok, ast_viol = _ast_guard(code)
        if use_ast:
            if not ast_ok:
                pipeline_stages.append(f"S6:ast_fail({len(ast_viol)})")
                if use_repair:
                    for attempt in range(1, max_repair + 1):
                        repair_attempts += 1
                        rp = _make_repair_prompt(code, f"AST violations: {'; '.join(ast_viol[:2])}", rule)
                        code = _extract_code(_llm_generate(tokenizer, model, rp))
                        ast_ok, ast_viol = _ast_guard(code)
                        if ast_ok:
                            pipeline_stages.append(f"S9:ast_repaired(attempt={attempt})")
                            break
            else:
                pipeline_stages.append("S6:ast_ok")
        else:
            pipeline_stages.append("S6:skipped")

        # Stage 7: Sandbox
        df_sample = _load_dataset_sample(rule, n=200)
        sandbox_ok = False
        sandbox_error = ""

        if use_exec:
            if df_sample is not None:
                sandbox_ok, sandbox_error, _ = _run_sandbox(code, df_sample)
                if sandbox_ok:
                    pipeline_stages.append("S7:sandbox_ok")
                else:
                    pipeline_stages.append("S7:sandbox_fail")
                    if use_repair:
                        for attempt in range(1, max_repair + 1):
                            repair_attempts += 1
                            rp = _make_repair_prompt(code, sandbox_error, rule)
                            code = _extract_code(_llm_generate(tokenizer, model, rp))
                            sandbox_ok, sandbox_error, _ = _run_sandbox(code, df_sample)
                            if sandbox_ok:
                                pipeline_stages.append(f"S9:repaired(attempt={attempt})")
                                break
                        if not sandbox_ok:
                            pipeline_stages.append(f"S9:human_review(max={max_repair})")
            else:
                pipeline_stages.append("S7:no_dataset")
                sandbox_ok = True
        else:
            # No exec: assume syntax_pass implies OK (same as B0 behaviour)
            sandbox_ok = True
            pipeline_stages.append("S7:skipped")

        # Stage 10: Metamorphic (abl9 only — proxy: always pass if sandbox_ok)
        if level >= 9:
            pipeline_stages.append("S10:meta_ok(proxy)")

        # Stage 11: Adjudicate
        final_status = "VALIDATED" if sandbox_ok else "HUMAN_REVIEW"
        pipeline_stages.append(f"S11:{final_status}")

        syntax_ok, syntax_err = _check_syntax(code)
        elapsed = (time.monotonic() - t_start) * 1000
        status_str = "OK" if (syntax_ok and sandbox_ok) else "ERR"
        print(
            f"  [{variant}] [{status_str}] {rule_id} | {final_status} | "
            f"tdd={tdd_n_tests} repairs={repair_attempts} ({elapsed/1000:.1f}s)"
        )

        predictions.append({
            "rule_id": rule_id,
            "dataset_id": rule.get("dataset_id", ""),
            "config": variant,
            "nl_text": rule.get("nl_text", ""),
            "dimension": rule.get("dimension", ""),
            "generated_code": code,
            "syntax_pass": syntax_ok,
            "syntax_error": syntax_err,
            "sandbox_ok": sandbox_ok,
            "sandbox_error": sandbox_error[:200] if sandbox_error else "",
            "final_status": final_status,
            "pipeline_stages": " | ".join(pipeline_stages),
            "tdd_n_tests": tdd_n_tests,
            "n_repair_attempts": repair_attempts,
            "prompt_hash": _sha256_str(prompt),
            "model_id": "Qwen/Qwen2.5-7B-Instruct",
            "elapsed_ms": elapsed,
            "error_message": sandbox_error[:200] if not sandbox_ok else "",
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })

    return predictions


def save_predictions(preds: list[dict], variant: str, tag: str) -> Path:
    tag_str = f"_{tag}" if tag else ""
    out_dir = _REPO / f"artifacts/predictions/pilot/{variant}{tag_str}"
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(preds)
    path = out_dir / "predictions.parquet"
    df.to_parquet(path, index=False)
    ok = int(df["syntax_pass"].sum())
    sb = int(df["sandbox_ok"].sum())
    val = int((df["final_status"] == "VALIDATED").sum())
    print(f"  Saved {len(df)} rows → {path}")
    print(f"  syntax_pass={ok}/{len(df)}  sandbox_ok={sb}/{len(df)}  VALIDATED={val}/{len(df)}")
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rules", required=True, help="Path to rules JSONL")
    parser.add_argument("--variant", default=None,
                        help="Run only this variant (e.g. abl1_+CAN). Default: all.")
    parser.add_argument("--tag", default="",
                        help="Tag appended to output dirs (e.g. 'ext')")
    parser.add_argument("--max-repair", type=int, default=5)
    parser.add_argument("--skip-done", action="store_true",
                        help="Skip variants whose prediction parquet already exists")
    args = parser.parse_args()

    rules = _load_rules(args.rules)
    variants_to_run = [args.variant] if args.variant else VARIANTS

    # Validate
    for v in variants_to_run:
        if v not in VARIANTS:
            print(f"ERROR: unknown variant '{v}'. Choose from: {VARIANTS}", file=sys.stderr)
            return 1

    print(f"Loaded {len(rules)} rules | Variants: {variants_to_run}")

    # Load model ONCE — shared across all variants
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig

    model_id = "Qwen/Qwen2.5-7B-Instruct"
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                             bnb_4bit_compute_dtype=torch.bfloat16,
                             bnb_4bit_use_double_quant=True)
    tokenizer = AutoTokenizer.from_pretrained(model_id, token=token)
    model = AutoModelForCausalLM.from_pretrained(
        model_id, quantization_config=bnb, device_map="auto", token=token)
    model.eval()
    print("Model loaded. Starting ablation variants...\n")

    tag_str = f"_{args.tag}" if args.tag else ""
    results_log = []

    for variant in variants_to_run:
        out_path = _REPO / f"artifacts/predictions/pilot/{variant}{tag_str}/predictions.parquet"
        if args.skip_done and out_path.exists():
            print(f"\n[SKIP] {variant} — already exists at {out_path}")
            continue

        print(f"\n{'='*65}")
        print(f"  VARIANT: {variant}")
        print(f"{'='*65}")
        t0 = time.monotonic()

        preds = run_variant(variant, rules, tokenizer, model, max_repair=args.max_repair)
        save_predictions(preds, variant, args.tag)
        elapsed_total = time.monotonic() - t0

        results_log.append({
            "variant": variant,
            "n_rules": len(preds),
            "elapsed_min": round(elapsed_total / 60, 2),
        })
        print(f"  Total time: {elapsed_total/60:.1f} min")

        # Immediately compute metrics after each variant
        rules_arg = args.rules
        config_arg = f"{variant}{tag_str}"
        print(f"\n  Running compute_metrics for {config_arg}...")
        ret = os.system(
            f"python scripts/compute_metrics.py "
            f"--config {config_arg} --rules {rules_arg}"
        )
        if ret != 0:
            print(f"  [WARNING] compute_metrics returned non-zero for {config_arg}")

    print(f"\n{'='*65}")
    print("  ABLATION COMPLETE")
    print(f"{'='*65}")
    for r in results_log:
        print(f"  {r['variant']:<25} n={r['n_rules']:>3}  elapsed={r['elapsed_min']:.1f} min")

    print(f"\nNext step: python scripts/ablation_forward_summary.py --tag {args.tag}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
