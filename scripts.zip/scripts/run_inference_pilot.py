#!/usr/bin/env python3
"""Run inference over pilot rules (B0, B1, B2, B3).

Usage:
    python scripts/run_inference_pilot.py --rules data/rules/pilot_reviewed_20.jsonl --config B0
    python scripts/run_inference_pilot.py --rules data/rules/pilot_reviewed_20.jsonl --config B1
    python scripts/run_inference_pilot.py --rules data/rules/pilot_reviewed_20.jsonl --config B2 --rag-file data/rag/train_syntax_pass.jsonl
    python scripts/run_inference_pilot.py --rules data/rules/pilot_reviewed_20.jsonl --config B3 --seed 42
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

# Qwen chat tokens
_IM_START = "<|im_start|>"
_IM_END   = "<|im_end|>"
_EOT      = "<|endoftext|>"

_SYSTEM_CODE = (
    "You are a Python data quality expert. "
    "When given a data quality rule and column info, you write ONLY a Python function "
    "`check(df)` that returns a list of violating row indices. "
    "No explanation. No markdown. Just the function."
)

_SYSTEM_CODE_B1 = (
    "You are a Python data quality expert. "
    "Given a structured rule interpretation, write ONLY a Python function `check(df)` "
    "that detects violations. Return empty list [] if the rule is not applicable. "
    "No explanation. No markdown. Just the function."
)


def _sha256_str(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def _load_rules(path: str) -> list[dict]:
    rules = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rules.append(json.loads(line))
    return rules


def _check_syntax(code: str) -> tuple[bool, str]:
    try:
        ast.parse(code)
        return True, ""
    except SyntaxError as e:
        return False, str(e)


def _make_b0_prompt(rule: dict) -> str:
    """B0: chat template with system + user. Concise user message."""
    cols = []
    if rule.get("ir_gold") and rule["ir_gold"].get("scope"):
        cols = rule["ir_gold"]["scope"].get("columns", [])
    col_hint = f"\nRelevant columns: {', '.join(cols)}" if cols else ""
    user = (
        f"Dataset: {rule['dataset_id']}\n"
        f"Rule: {rule['nl_text']}"
        f"{col_hint}\n\n"
        "Write check(df):"
    )
    return (
        f"{_IM_START}system\n{_SYSTEM_CODE}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n"
        "import pandas as pd\n"
    )


def _make_b1_prompt(rule: dict) -> str:
    """B1: structured prompt with IR hints in chat template."""
    ir = rule.get("ir_gold") or {}
    cols = ir.get("scope", {}).get("columns", [])
    operator = ir.get("logic", {}).get("operator", "AND")
    non_app = ir.get("non_applicability", {})
    non_app_hint = ""
    if non_app and non_app.get("condition"):
        non_app_hint = f"\nNon-applicability: {non_app['condition']}"
    user = (
        f"Dataset: {rule['dataset_id']}\n"
        f"Rule: {rule['nl_text']}\n"
        f"Dimension: {rule.get('dimension','validity')}\n"
        f"Columns: {', '.join(cols) if cols else 'see rule'}\n"
        f"Logic: {operator}"
        f"{non_app_hint}\n\n"
        "Write check(df):"
    )
    return (
        f"{_IM_START}system\n{_SYSTEM_CODE_B1}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n"
        "import pandas as pd\n"
    )


def _make_b2_prompt(rule: dict, rag_examples: list[dict]) -> str:
    """B2: B1 prompt + static RAG examples from the train split."""
    ir = rule.get("ir_gold") or {}
    cols = ir.get("scope", {}).get("columns", [])
    operator = ir.get("logic", {}).get("operator", "AND")
    non_app = ir.get("non_applicability", {})
    non_app_hint = ""
    if non_app and non_app.get("condition"):
        non_app_hint = f"\nNon-applicability: {non_app['condition']}"

    # Build RAG context from train examples
    rag_ctx = ""
    if rag_examples:
        rag_ctx = "\nEXAMPLES FROM SIMILAR RULES:\n"
        for ex in rag_examples[:3]:  # max 3 examples
            rag_ctx += f"\n# Rule: {ex.get('nl_text','')[:80]}\n"
            rag_ctx += f"# Dimension: {ex.get('dimension','')}\n"
            code = ex.get("generated_code", "")
            if code and "def check" in code:
                # Only include first 8 lines of code
                lines = code.split("\n")[:8]
                rag_ctx += "\n".join(lines) + "\n...\n"

    user = (
        f"Dataset: {rule['dataset_id']}\n"
        f"Rule: {rule['nl_text']}\n"
        f"Dimension: {rule.get('dimension','validity')}\n"
        f"Columns: {', '.join(cols) if cols else 'see rule'}\n"
        f"Logic: {operator}"
        f"{non_app_hint}"
        f"{rag_ctx}\n\n"
        "Write check(df):"
    )
    return (
        f"{_IM_START}system\n{_SYSTEM_CODE_B1}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n"
        "import pandas as pd\n"
    )


def _extract_code(raw: str) -> str:
    """
    Robust code extractor. 5-step cascade:
    1. Fenced ```python block
    2. Any ``` block
    3. def check( by indentation
    4. Full raw parse
    5. Safe stub
    """
    def _try_parse(code: str) -> str | None:
        try:
            ast.parse(code)
            if "def check" in code:
                return code.strip()
        except SyntaxError:
            pass
        return None

    # Since we prime with "import pandas as pd\n", prepend it to raw
    primed = "import pandas as pd\n" + raw

    for fence in ["```python", "```"]:
        idx = primed.find(fence)
        if idx != -1:
            start = idx + len(fence)
            end = primed.find("```", start)
            if end != -1:
                candidate = primed[start:end].strip()
                r = _try_parse(candidate)
                if r:
                    return r
                if "def check" in candidate:
                    fn = _extract_function(candidate)
                    if fn:
                        r = _try_parse(fn)
                        if r:
                            return r

    fn = _extract_function(primed)
    if fn:
        r = _try_parse(fn)
        if r:
            return r

    r = _try_parse(primed)
    if r:
        return r

    return (
        "import pandas as pd\n\n"
        "def check(df):\n"
        "    # Could not extract valid function\n"
        "    return []\n"
    )


def _extract_function(text: str) -> str | None:
    lines = text.split("\n")
    imports = []
    check_start = -1
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("def check(") or s.startswith("def check ("):
            check_start = i
            break
        if s.startswith("import ") or s.startswith("from "):
            imports.append(line)
    if check_start == -1:
        return None
    func_lines = [lines[check_start]]
    for line in lines[check_start + 1:]:
        s = line.strip()
        if not s:
            func_lines.append(line)
            continue
        indent = len(line) - len(line.lstrip())
        if indent == 0:
            if s.startswith(("def ", "class ")):
                break
            if not s.startswith(("import ", "from ", "return ")):
                try:
                    ast.parse(s)
                    func_lines.append(line)
                except SyntaxError:
                    break
            else:
                func_lines.append(line)
        else:
            func_lines.append(line)
    if not func_lines:
        return None
    return "\n".join((imports or []) + func_lines).strip()


def _run_config(rules: list[dict], model_adapter, config: str, rag_file: str | None = None) -> list[dict]:
    # Load RAG examples for B2
    rag_examples = []
    if config == "B2" and rag_file:
        try:
            with open(rag_file, encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        rag_examples.append(json.loads(line))
        except Exception as e:
            print(f"  [WARNING] Could not load RAG file: {e}")

    predictions = []
    for rule in rules:
        if config in ("B0", "B3"):
            prompt = _make_b0_prompt(rule)
        elif config == "B2":
            prompt = _make_b2_prompt(rule, rag_examples)
        else:
            prompt = _make_b1_prompt(rule)
        prompt_hash = _sha256_str(prompt)
        start = time.monotonic()
        try:
            result = model_adapter.generate(prompt)
            # The model continues from "import pandas as pd\n" — prepend it
            raw_with_prefix = "import pandas as pd\n" + result.generated_text
            code = _extract_code(raw_with_prefix)
            syntax_ok, syntax_err = _check_syntax(code)
            elapsed = (time.monotonic() - start) * 1000
            predictions.append({
                "rule_id": rule["rule_id"],
                "dataset_id": rule["dataset_id"],
                "config": config,
                "nl_text": rule["nl_text"],
                "dimension": rule["dimension"],
                "generated_code": code,
                "syntax_pass": syntax_ok,
                "syntax_error": syntax_err,
                "prompt_hash": prompt_hash,
                "model_id": result.model_id,
                "elapsed_ms": elapsed,
                "error_message": "",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            })
            print(f"  [{'OK' if syntax_ok else 'ERR'}] {rule['rule_id']} {rule['nl_text'][:55]}")
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            predictions.append({
                "rule_id": rule["rule_id"],
                "dataset_id": rule["dataset_id"],
                "config": config,
                "nl_text": rule["nl_text"],
                "dimension": rule["dimension"],
                "generated_code": "",
                "syntax_pass": False,
                "syntax_error": "",
                "prompt_hash": prompt_hash,
                "model_id": "unknown",
                "elapsed_ms": elapsed,
                "error_message": str(e),
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            })
            print(f"  [ERROR] {rule['rule_id']}: {e}")
    return predictions


def save_predictions(predictions: list[dict], config: str, seed: int | None, tag: str = "") -> Path:
    seed_str = f"_seed{seed}" if seed else ""
    tag_str = f"_{tag}" if tag else ""
    out_dir = _REPO_ROOT / f"artifacts/predictions/pilot/{config}{seed_str}{tag_str}"
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(predictions)
    parquet_path = out_dir / "predictions.parquet"
    df.to_parquet(parquet_path, index=False)
    manifest = {
        "config": config, "seed": seed, "n_rules": len(predictions),
        "syntax_pass_rate": float(df["syntax_pass"].mean()) if len(df) else 0.0,
        "error_rate": float((df["error_message"] != "").mean()) if len(df) else 0.0,
        "avg_elapsed_ms": float(df["elapsed_ms"].mean()) if len(df) else 0.0,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "predictions_path": str(parquet_path),
    }
    (out_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"\nSaved: {parquet_path}")
    return parquet_path


def print_summary(preds: list[dict], config: str) -> None:
    df = pd.DataFrame(preds)
    ok = int(df["syntax_pass"].sum())
    err = int((df["error_message"] != "").sum())
    print(f"\n{'='*55}")
    print(f"Config: {config} | Rules: {len(df)}")
    print(f"Syntax pass : {ok}/{len(df)} ({ok/len(df)*100:.0f}%)")
    print(f"Errors      : {err}/{len(df)}")
    print(f"Avg latency : {df['elapsed_ms'].mean()/1000:.1f} s/rule")
    print(f"{'='*55}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rules", required=True)
    parser.add_argument("--config", required=True, choices=["B0", "B1", "B2", "B3"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--tag", default="", help="Optional tag appended to output directory name (e.g. 'historical')")
    parser.add_argument("--rag-file", default=None,
                        help="JSONL file with (rule, code) pairs for B2 RAG context")
    args = parser.parse_args()

    rules = _load_rules(args.rules)
    print(f"Loaded {len(rules)} rules | Config: {args.config}")

    from models.qwen_adapter import QwenBaseAdapter, GenerationConfig
    # 256 tokens is enough for 5-15 lines of pandas code
    gen_config = GenerationConfig(temperature=0.0, seed=args.seed, max_new_tokens=256)

    if args.config == "B3":
        adapter_path = _REPO_ROOT / f"artifacts/adapters/qlora_nl2code_seed{args.seed}"
        if not adapter_path.exists():
            print(f"ERROR: adapter not found: {adapter_path}", file=sys.stderr)
            return 1
        from models.qlora_adapter import QLoRAAdapter
        adapter = QLoRAAdapter(
            config_path=str(_REPO_ROOT / "configs/qlora_nl2code.yaml"),
            adapter_weights_path=str(adapter_path),
            stub_mode=False,
        )
    else:
        adapter = QwenBaseAdapter(stub_mode=False, config=gen_config)

    print(f"Model loaded. Running {len(rules)} rules...\n")
    preds = _run_config(rules, adapter, args.config, rag_file=args.rag_file)
    seed_save = args.seed if args.config == "B3" else None
    save_predictions(preds, args.config, seed_save, tag=args.tag)
    print_summary(preds, args.config)
    return 0


if __name__ == "__main__":
    sys.exit(main())
