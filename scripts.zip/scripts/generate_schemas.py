#!/usr/bin/env python3
"""Generate JSON Schema files for all benchmark models.

Run from the repository root::

    python scripts/generate_schemas.py

The script writes one ``.schema.json`` file per model to the ``schemas/``
directory.  Existing files are overwritten so that the schemas stay in sync
with the Python models.

The ``schemas/`` directory is committed to Git so that:

* CI can validate incoming data without importing Python.
* Downstream consumers (JS, Rust, …) can use the schemas directly.
* Schema diffs appear in pull-request reviews.

Usage::

    python scripts/generate_schemas.py [--out-dir SCHEMAS_DIR]

Options
-------
--out-dir
    Directory where schema files are written.  Defaults to ``schemas/``
    relative to the repository root (detected from ``__file__``).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Ensure the package is importable when running from repo root
# ---------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

from models import (  # noqa: E402
    IR,
    AgentResult,
    DatasetRecord,
    Prediction,
    RuleRecord,
    RunManifest,
)

_MODELS = {
    "dataset": DatasetRecord,
    "rule": RuleRecord,
    "ir": IR,
    "agent_result": AgentResult,
    "run_manifest": RunManifest,
    "prediction": Prediction,
}


def generate(out_dir: Path) -> None:
    """Generate JSON Schema files for all models.

    Parameters
    ----------
    out_dir:
        Directory where ``*.schema.json`` files will be written.
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    for name, model in _MODELS.items():
        schema = model.model_json_schema()
        # Add $schema and title for better tooling support
        schema.setdefault("$schema", "https://json-schema.org/draft/2020-12/schema")
        schema.setdefault("title", name)
        path = out_dir / f"{name}.schema.json"
        path.write_text(json.dumps(schema, indent=2, ensure_ascii=False) + "\n")
        print(f"  written: {path}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=_REPO_ROOT / "schemas",
        help="Directory where schema files are written (default: schemas/)",
    )
    args = parser.parse_args()
    print(f"Generating schemas → {args.out_dir}/")
    generate(args.out_dir)
    print("Done.")


if __name__ == "__main__":
    main()
