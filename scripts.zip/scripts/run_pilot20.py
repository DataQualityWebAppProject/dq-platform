#!/usr/bin/env python3
"""T8.1 — Run full experimental matrix on 20 datasets / 100 rules.

Usage:
    python scripts/run_pilot20.py

Prerequisites:
    - T2.6: 20 datasets registered in data/registry/datasets.csv
    - T3.6: 100 rules in data/rules/pilot_100.jsonl (FROZEN status)
    - T6.1-T6.3: model adapters implemented (B0, B1, B2)
    - GPU available with HF_TOKEN set

Per design.md: run all baselines (B0-B5, P) and record results via MLflow.
DO NOT optimize against validation or test metrics during this phase.
"""
import sys
from pathlib import Path
_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

def main() -> int:
    from data_registry.registry import load_registry
    records = load_registry(str(_REPO_ROOT / "data/registry/datasets.csv"))
    eligible = [r for r in records if r.eligible][:20]
    if len(eligible) < 20:
        print(f"ERROR: Only {len(eligible)} eligible datasets. Need 20.", file=sys.stderr)
        return 1
    print(f"T8.1 Pilot-20: {len(eligible)} datasets ready.")
    print("Full execution requires GPU + trained adapters (T6.1-T6.7).")
    print("Run after completing all Phase 6 prerequisites.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
