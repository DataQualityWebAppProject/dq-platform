"""Extract timing and summary for all _ext configs."""
import pandas as pd
import pathlib
import os
import datetime

base_metrics = pathlib.Path("artifacts/metrics/pilot")
base_preds   = pathlib.Path("artifacts/predictions/pilot")
base_logs    = pathlib.Path("artifacts/logs")

CONFIGS = ["B0_ext", "B1_ext", "B2_ext", "B3_seed42_ext", "B4_seed42_ext", "B5_ext"]

print(f"{'Config':<20} {'F1':>6} {'n':>4} {'F1>0.5':>7} {'F1=1':>5} {'ERR':>5} {'median_exec_ms':>15} {'inference_elapsed_min':>22} {'pred_dir_mtime':>25}")
print("-" * 120)

for cfg in CONFIGS:
    mf = base_metrics / f"{cfg}_metrics.parquet"
    if not mf.exists():
        print(f"{cfg:<20} {'MISSING':>6}")
        continue

    df = pd.read_parquet(mf)
    valid = df[df["f1"].notna()]
    f1_macro = valid["f1"].mean()
    n_valid  = len(valid)
    n_gt05   = (valid["f1"] > 0.5).sum()
    n_eq1    = (valid["f1"] == 1.0).sum()
    n_err    = df["error"].notna().sum()

    # Median exec latency from parquet
    if "exec_latency_ms" in df.columns:
        med_exec = valid["exec_latency_ms"].median()
        med_str  = f"{med_exec:.0f}" if not pd.isna(med_exec) else "N/A"
    else:
        med_str = "N/A"

    # Inference elapsed: from log file first line timestamp vs last line timestamp
    # Approximate from prediction dir mtime vs metrics file mtime
    pred_dir = base_preds / cfg
    metrics_mtime = datetime.datetime.fromtimestamp(mf.stat().st_mtime)

    if pred_dir.exists():
        pred_mtime = datetime.datetime.fromtimestamp(pred_dir.stat().st_mtime)
        pred_str = pred_mtime.strftime("%Y-%m-%d %H:%M")
    else:
        pred_str = "N/A"

    # Try to get elapsed from log
    log_cfg = cfg.replace("_seed42", "").replace("_ext", "")
    log_f = base_logs / f"{cfg}_inference.txt"
    elapsed_str = "N/A"
    if log_f.exists():
        # Get file creation time and modification time difference
        log_ctime = datetime.datetime.fromtimestamp(log_f.stat().st_ctime)
        log_mtime = datetime.datetime.fromtimestamp(log_f.stat().st_mtime)
        elapsed_sec = (log_mtime - log_ctime).total_seconds()
        if elapsed_sec > 0:
            elapsed_str = f"{elapsed_sec/60:.1f}"
        else:
            # fallback: pred dir mtime minus metrics mtime
            elapsed_str = "see log"

    print(f"{cfg:<20} {f1_macro:>6.4f} {n_valid:>4} {n_gt05:>7} {n_eq1:>5} {n_err:>5} {med_str:>15} {elapsed_str:>22} {pred_str:>25}")

print()
print("Notes:")
print("- median_exec_ms: median sandbox execution time per rule (from parquet)")
print("- inference_elapsed_min: total wall-clock for LLM inference (from log ctime->mtime)")
print("- pred_dir_mtime: timestamp of predictions directory (last write)")
