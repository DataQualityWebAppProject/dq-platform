import pandas as pd
import pathlib

base = pathlib.Path("artifacts/metrics/pilot")

for stem in ["B5_metrics", "B5_ext_metrics"]:
    f = base / f"{stem}.parquet"
    if not f.exists():
        print(f"{stem}: NOT FOUND")
        continue
    df = pd.read_parquet(f)
    print(f"\n{stem} columns ({len(df)} rows):")
    for col in df.columns:
        sample = df[col].iloc[0] if len(df) > 0 else "N/A"
        print(f"  {col:<35} dtype={str(df[col].dtype):<15} sample={repr(sample)[:50]}")

# Also check the prediction parquet for pipeline metadata
pred_base = pathlib.Path("artifacts/predictions/pilot")
for pdir in ["B5", "B5_ext"]:
    pf = pred_base / pdir / "predictions.parquet"
    if not pf.exists():
        print(f"\n{pdir}/predictions.parquet: NOT FOUND")
        continue
    df = pd.read_parquet(pf)
    print(f"\n{pdir}/predictions.parquet columns ({len(df)} rows):")
    for col in df.columns:
        sample = df[col].iloc[0] if len(df) > 0 else "N/A"
        print(f"  {col:<35} dtype={str(df[col].dtype):<15} sample={repr(sample)[:50]}")
