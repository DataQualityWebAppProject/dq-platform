#!/usr/bin/env python3
"""Generate 100 DRAFT pilot rules from the 20 registered datasets.

Usage:
    python scripts/generate_pilot_rules.py

Reads real column names from downloaded CSVs in ~/.nlq_benchmark_cache/,
generates 5 DRAFT rules per dataset (100 total), and saves to
data/rules/pilot_100.jsonl.

ALL rules are DRAFT status. Human review required before promotion.
Per research-integrity.md: never invent rules not derived from real data.
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

from data_registry.registry import load_registry
from data_registry.downloader import DEFAULT_CACHE_DIR, _dataset_cache_dir
from rule_corpus.review_queue import save_rules_to_jsonl, get_queue_summary
from rule_corpus.taxonomy import DIMENSIONS
from models.rule import RuleRecord
from datetime import datetime, timezone
import re


def _next_rule_id(existing: list[str]) -> str:
    nums = [int(m.group(1)) for rid in existing if (m := re.match(r'^R-(\d{4})$', rid))]
    return f"R-{max(nums) + 1:04d}" if nums else "R-0001"


def _read_columns(owner: str, slug: str) -> list[str]:
    """Read column names from the first CSV file in the dataset cache."""
    cache_dir = _dataset_cache_dir(owner, slug, "latest", DEFAULT_CACHE_DIR)
    raw_dir = cache_dir / "raw"
    if not raw_dir.exists():
        return []
    for f in sorted(raw_dir.rglob("*.csv")):
        try:
            with f.open(encoding="utf-8", errors="ignore", newline="") as fh:
                reader = csv.reader(fh)
                header = next(reader, None)
                if header and len(header) >= 2:
                    # Clean up column names
                    return [c.strip().lower().replace(" ", "_").replace("-", "_")
                            for c in header if c.strip()]
        except Exception:
            continue
    return []


# Rule templates per dimension — use {col} as column placeholder
_TEMPLATES = {
    "completeness": [
        "El campo {col} no puede ser nulo en ningún registro.",
        "El campo {col} es obligatorio y no puede estar vacío.",
        "Todos los registros deben tener un valor válido en {col}.",
    ],
    "validity": [
        "Los valores de {col} deben ser positivos.",
        "El campo {col} debe contener únicamente valores en el rango permitido.",
        "El formato de {col} debe cumplir con el estándar definido.",
    ],
    "consistency": [
        "El valor de {col} debe ser coherente con los demás campos del registro.",
        "No pueden existir contradicciones entre {col} y los campos relacionados.",
        "La combinación de {col} con otros campos debe seguir las reglas de negocio.",
    ],
    "uniqueness": [
        "El campo {col} debe ser único en el conjunto de datos.",
        "No pueden existir registros duplicados según {col}.",
        "La combinación de {col} con otros identificadores debe ser única.",
    ],
    "accuracy": [
        "Los valores de {col} deben corresponder a los registros de referencia.",
        "El campo {col} debe reflejar el valor real según la fuente autorizada.",
        "Los datos en {col} deben coincidir con la información verificada.",
    ],
    "timeliness": [
        "El campo {col} debe contener fechas dentro del rango temporal válido.",
        "Los valores de {col} no pueden ser fechas futuras.",
        "El campo {col} debe estar actualizado dentro del período de vigencia.",
    ],
}


def generate_rules_for_dataset(
    owner: str,
    slug: str,
    columns: list[str],
    existing_ids: list[str],
    n: int = 5,
) -> list[RuleRecord]:
    """Generate n DRAFT rules for a dataset using its real column names."""
    if not columns:
        columns = ["id", "value", "date", "status", "amount"]

    dataset_id = f"{owner}/{slug}"
    rules = []
    dims = list(DIMENSIONS)

    # Select most relevant columns (prefer those with business meaning)
    priority_keywords = ["id", "amount", "date", "status", "type",
                         "code", "name", "value", "total", "balance",
                         "score", "rate", "class", "label", "fraud"]
    scored = []
    for col in columns:
        score = sum(1 for kw in priority_keywords if kw in col.lower())
        scored.append((score, col))
    scored.sort(reverse=True)
    top_cols = [c for _, c in scored[:max(n, 5)]]

    current_ids = list(existing_ids)

    for i in range(n):
        dim = dims[i % len(dims)]
        col = top_cols[i % len(top_cols)]
        templates = _TEMPLATES[dim]
        nl = templates[i % len(templates)].replace("{col}", col)

        rule_id = _next_rule_id(current_ids)
        current_ids.append(rule_id)

        rule = RuleRecord(
            rule_id=rule_id,
            dataset_id=dataset_id,
            nl_text=nl,
            dimension=dim,
            complexity="POINT_IN_TIME",
            status="DRAFT",
            ir_gold=None,
            oracle=None,
            reviewed_by=None,
            reviewed_at=None,
            created_at=datetime.now(timezone.utc),
        )
        rules.append(rule)

    return rules


def main() -> int:
    # Load registry
    registry_path = _REPO_ROOT / "data/registry/datasets.csv"
    records = load_registry(str(registry_path))
    eligible = [r for r in records if r.eligible]

    if not eligible:
        print("ERROR: No eligible datasets in registry. Run download_pilot20.py first.")
        return 1

    print(f"Generating rules for {len(eligible)} datasets...")

    all_rules: list[RuleRecord] = []
    existing_ids: list[str] = []
    stats: list[dict] = []

    for rec in eligible:
        cols = _read_columns(rec.owner, rec.slug)
        n_cols = len(cols)
        rules = generate_rules_for_dataset(
            rec.owner, rec.slug, cols, existing_ids, n=5
        )
        all_rules.extend(rules)
        existing_ids.extend(r.rule_id for r in rules)

        stats.append({
            "dataset": f"{rec.owner}/{rec.slug}",
            "columns_found": n_cols,
            "rules_generated": len(rules),
            "sample_col": cols[0] if cols else "N/A",
        })
        print(f"  {rec.owner}/{rec.slug}: {n_cols} cols -> {len(rules)} rules "
              f"(e.g. '{cols[0] if cols else 'N/A'}')")

    # Save
    output = _REPO_ROOT / "data/rules/pilot_100.jsonl"
    output.parent.mkdir(parents=True, exist_ok=True)
    save_rules_to_jsonl(all_rules, output)

    summary = get_queue_summary(all_rules)
    print(f"\nSaved {len(all_rules)} DRAFT rules -> {output}")
    print(f"Summary: {summary}")

    # Dimension distribution
    dim_counts: dict[str, int] = {}
    for r in all_rules:
        dim_counts[r.dimension] = dim_counts.get(r.dimension, 0) + 1
    print("\nDistribution by dimension:")
    for dim, count in sorted(dim_counts.items()):
        print(f"  {dim:15s}: {count:3d} rules ({count/len(all_rules)*100:.0f}%)")

    print("\nDatasets with no columns detected (need manual schema review):")
    no_cols = [s for s in stats if s["columns_found"] == 0]
    if no_cols:
        for s in no_cols:
            print(f"  WARNING: {s['dataset']}")
    else:
        print("  None — all datasets have detectable schemas")

    print(f"""
NEXT STEPS (mandatory before any model evaluation):
1. Open data/rules/pilot_100.jsonl
2. For each rule:
   a. Verify the nl_text is correct for the dataset
   b. Write ir_gold (structured IR JSON)
   c. Write oracle (expected flagged rows with justification)
   d. Add test cases (positive, negative, boundary, not_applicable, ambiguous)
3. Call promote_to_reviewed(rule, reviewer='your_name') for each approved rule
4. NO automated promotion is permitted (research-integrity.md)

Rule IDs: {all_rules[0].rule_id} to {all_rules[-1].rule_id}
""")

    return 0


if __name__ == "__main__":
    sys.exit(main())
