#!/usr/bin/env python3
"""Quick test of B4 NL→IR adapter.

Generates IR for 2 rules and checks if output is valid JSON.
Also diagnoses if train_loss=24.85 is due to truncation.

Usage:
    python scripts/test_b4_inference.py
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO / "src"))

_INSTRUCTION = (
    "You are a data quality rule analyzer. "
    "Given a natural language data quality rule, produce a structured JSON Intermediate Representation (IR) "
    "that captures the rule's dimension, complexity, scope (columns), logic (operator and clauses), "
    "trigger condition, non-applicability condition, and blueprint (columns_involved, error_condition, correction_action). "
    "Output ONLY the JSON object, no explanation."
)

_TEST_RULES = [
    {
        "rule_id": "R-0102",
        "dataset_id": "sakshigoyal7/credit-card-customers",
        "nl_text": "La edad del cliente (Customer_Age) debe estar entre 18 y 100 años.",
        "dimension": "validity",
        "complexity": "POINT_IN_TIME",
        "columns": ["Customer_Age"],
    },
    {
        "rule_id": "R-H001",
        "dataset_id": "larsen0966/sba-loans-case-data-set",
        "nl_text": "La fecha de aprobación del préstamo (ApprovalDate) debe ser anterior a la fecha de desembolso (DisbursementDate).",
        "dimension": "consistency",
        "complexity": "HISTORICAL",
        "columns": ["ApprovalDate", "DisbursementDate"],
    },
]


def check_token_lengths(tokenizer, rules: list[dict]) -> None:
    """Diagnose if prompts are too long for max_seq=1024."""
    print("\n=== TOKEN LENGTH DIAGNOSIS ===")
    for rule in rules:
        input_text = (
            f"Dataset: {rule['dataset_id']}\n"
            f"Rule: {rule['nl_text']}\n"
            f"Dimension hint: {rule['dimension']}\n"
            f"Complexity hint: {rule['complexity']}\n"
            f"Known columns: {', '.join(rule['columns'])}"
        )
        prompt = (
            f"<|im_start|>system\n{_INSTRUCTION}<|im_end|>\n"
            f"<|im_start|>user\n{input_text}<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )
        tokens = tokenizer(prompt, return_tensors=None)
        n_prompt = len(tokens["input_ids"])
        print(f"  {rule['rule_id']}: prompt = {n_prompt} tokens")
        if n_prompt > 800:
            print(f"    WARNING: prompt too long, little room for IR output in 1024 max")


def main() -> int:
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    adapter_path = _REPO / "artifacts" / "adapters" / "qlora_nl2ir_seed42"

    if not adapter_path.exists():
        print(f"ERROR: adapter not found at {adapter_path}")
        return 1

    print(f"Loading adapter from {adapter_path}")

    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
    from peft import PeftModel

    model_id = "Qwen/Qwen2.5-7B-Instruct"
    tokenizer = AutoTokenizer.from_pretrained(model_id, token=token)

    # Diagnose token lengths first
    check_token_lengths(tokenizer, _TEST_RULES)

    print("\n=== LOADING MODEL + ADAPTER ===")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True,
    )
    base = AutoModelForCausalLM.from_pretrained(
        model_id, quantization_config=bnb_config, device_map="auto", token=token,
    )
    model = PeftModel.from_pretrained(base, str(adapter_path))
    model.eval()

    print("\n=== B4 INFERENCE TEST ===")
    for rule in _TEST_RULES:
        print(f"\n--- {rule['rule_id']} ({rule['dimension']}) ---")
        input_text = (
            f"Dataset: {rule['dataset_id']}\n"
            f"Rule: {rule['nl_text']}\n"
            f"Dimension hint: {rule['dimension']}\n"
            f"Complexity hint: {rule['complexity']}\n"
            f"Known columns: {', '.join(rule['columns'])}"
        )
        prompt = (
            f"<|im_start|>system\n{_INSTRUCTION}<|im_end|>\n"
            f"<|im_start|>user\n{input_text}<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )

        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        n_prompt_tokens = inputs["input_ids"].shape[1]
        print(f"  Prompt tokens: {n_prompt_tokens}")

        with torch.no_grad():
            out = model.generate(
                **inputs, max_new_tokens=512,
                do_sample=False, pad_token_id=tokenizer.eos_token_id,
            )

        generated = tokenizer.decode(
            out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True
        )
        print(f"  Generated ({len(generated)} chars):")
        print(f"  {generated[:300]}{'...' if len(generated) > 300 else ''}")

        # Try to parse as JSON
        try:
            # Find JSON block
            start = generated.find("{")
            end = generated.rfind("}") + 1
            if start >= 0 and end > start:
                ir = json.loads(generated[start:end])
                print(f"  ✓ Valid JSON — dimension={ir.get('dimension')}, complexity={ir.get('complexity')}")
                cols = ir.get("scope", {}).get("columns", [])
                print(f"    scope.columns = {cols}")
                blueprint = ir.get("blueprint", {})
                print(f"    blueprint.error_condition = {blueprint.get('error_condition','')[:60]}")
            else:
                print(f"  ✗ No JSON object found in output")
        except json.JSONDecodeError as e:
            print(f"  ✗ Invalid JSON: {e}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
