#!/usr/bin/env python3
"""Update datasets.csv from data/raw/ directory.

Structure: data/raw/{owner}/{slug}/vlatest/raw/{files.csv}

- Datasets with CSV files > 10KB are marked eligible=True
- Datasets with only empty folders are marked eligible=False
- Writes frozen snapshot

Usage:
    python scripts/update_registry_from_raw.py
"""
from __future__ import annotations

import csv
import datetime
import json
import pathlib
import sys

REPO = pathlib.Path(__file__).resolve().parent.parent
RAW_DIR = REPO / "data" / "raw"
REGISTRY_PATH = REPO / "data" / "registry" / "datasets.csv"
FROZEN_DIR = REPO / "data" / "registry" / "frozen"
FROZEN_DIR.mkdir(parents=True, exist_ok=True)

FIELDNAMES = [
    "owner", "slug", "url", "version", "license", "eligible",
    "eligibility_reason", "format", "n_tables", "sha256_files_json",
    "profile_path", "frozen_at", "phase",
]

MIN_FILE_SIZE = 10_000  # 10 KB — anything smaller is likely a placeholder


def load_existing() -> dict[str, dict]:
    if not REGISTRY_PATH.exists():
        return {}
    with open(REGISTRY_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return {f"{r['owner']}/{r['slug']}": dict(r) for r in reader}


def scan_raw() -> list[tuple[str, str]]:
    """Return sorted list of (owner, slug) found in data/raw/."""
    result = []
    if not RAW_DIR.exists():
        print(f"ERROR: {RAW_DIR} does not exist", file=sys.stderr)
        sys.exit(1)
    for owner_dir in sorted(RAW_DIR.iterdir()):
        if owner_dir.is_dir():
            for slug_dir in sorted(owner_dir.iterdir()):
                if slug_dir.is_dir():
                    result.append((owner_dir.name, slug_dir.name))
    return result


def find_data_files(slug_path: pathlib.Path) -> list[pathlib.Path]:
    """Find CSV/Parquet files larger than MIN_FILE_SIZE anywhere under slug_path."""
    found = []
    for ext in ["*.csv", "*.parquet", "*.tsv", "*.xlsx"]:
        for f in slug_path.rglob(ext):
            if f.is_file() and f.stat().st_size >= MIN_FILE_SIZE:
                found.append(f)
    return found


def read_manifest(slug_path: pathlib.Path) -> dict:
    for candidate in [
        slug_path / "vlatest" / "manifest.json",
        slug_path / "manifest.json",
    ]:
        if candidate.exists():
            try:
                return json.loads(candidate.read_text(encoding="utf-8"))
            except Exception:
                pass
    return {}


def detect_format(files: list[pathlib.Path]) -> tuple[str, int]:
    csvs = [f for f in files if f.suffix.lower() == ".csv"]
    parquets = [f for f in files if f.suffix.lower() == ".parquet"]
    if csvs:
        return ("multitable" if len(csvs) > 1 else "csv"), len(csvs)
    if parquets:
        return "parquet", len(parquets)
    return "other", len(files)


def main() -> None:
    existing = load_existing()
    all_raw = scan_raw()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()

    print(f"Existing in registry : {len(existing)}")
    print(f"Found in data/raw/   : {len(all_raw)}")

    rows: list[dict] = []
    with_data: list[str] = []
    no_data: list[str] = []

    for owner, slug in all_raw:
        key = f"{owner}/{slug}"
        slug_path = RAW_DIR / owner / slug
        data_files = find_data_files(slug_path)
        manifest = read_manifest(slug_path)
        has_data = len(data_files) > 0

        if has_data:
            fmt, n_tables = detect_format(data_files)
            with_data.append(key)
        else:
            fmt, n_tables = "unknown", 0
            no_data.append(key)

        # Determine phase: preserve original for pilot-20 datasets
        if key in existing:
            phase = existing[key].get("phase", "pilot-200")
            license_val = existing[key].get("license", manifest.get("licenseName", "CC0: Public Domain"))
        else:
            phase = "pilot-200"
            license_val = manifest.get("licenseName", "CC0: Public Domain")

        rows.append({
            "owner": owner,
            "slug": slug,
            "url": f"https://www.kaggle.com/datasets/{owner}/{slug}",
            "version": "1",
            "license": license_val,
            "eligible": "True" if has_data else "False",
            "eligibility_reason": (
                "Verified: CSV data present in data/raw/"
                if has_data
                else "Download incomplete: no data files found (empty folder)"
            ),
            "format": fmt,
            "n_tables": max(n_tables, 1),
            "sha256_files_json": "{}",
            "profile_path": str(slug_path),
            "frozen_at": now,
            "phase": phase,
        })

    # Write main registry
    with open(REGISTRY_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)

    # Write frozen snapshot
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    frozen_path = FROZEN_DIR / f"pilot-200_{ts}.csv"
    with open(frozen_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n=== REGISTRY UPDATE COMPLETE ===")
    print(f"Total datasets       : {len(rows)}")
    print(f"  With data (usable) : {len(with_data)}  (eligible=True)")
    print(f"  Empty/incomplete   : {len(no_data)}  (eligible=False)")
    print(f"datasets.csv         : {REGISTRY_PATH}")
    print(f"Frozen snapshot      : {frozen_path}")

    print(f"\nUsable datasets ({len(with_data)}):")
    for k in with_data:
        print(f"  OK  {k}")

    if no_data:
        print(f"\nEmpty/incomplete ({len(no_data)}) — eligible=False:")
        for k in no_data:
            print(f"  --  {k}")

    print(f"\nBenchmark can proceed with {len(with_data)} datasets.")
    print(f"Next: python scripts/compute_metrics.py")


if __name__ == "__main__":
    main()
