"""Detailed per-rule ablation for B5 pipeline variants.

For each split (pilot, ext):
  - B5_full: F1 as-is from parquet
  - B5_minus_PIPELINE_B0: substitute all rules with B0 F1
  - B5_minus_REPAIR: for rules where n_repair_attempts>0, substitute B0 F1
  - B5_minus_TDD: for rules where tdd_n_tests>0, substitute B0 F1
  - B5_minus_AST_SANDBOX: same as minus_REPAIR (proxy)

Outputs per-rule table and macro summary for each variant.
"""
import pandas as pd
import pathlib

_REPO = pathlib.Path(".")
_M = _REPO / "artifacts/metrics/pilot"
_P = _REPO / "artifacts/predictions/pilot"

CONFIGS = {
    "pilot": {
        "b5_metrics": _M / "B5_metrics.parquet",
        "b0_metrics": _M / "B0_metrics.parquet",
        "b5_preds":   _P / "B5/predictions.parquet",
    },
    "ext": {
        "b5_metrics": _M / "B5_ext_metrics.parquet",
        "b0_metrics": _M / "B0_ext_metrics.parquet",
        "b5_preds":   _P / "B5_ext/predictions.parquet",
    },
}

for split, paths in CONFIGS.items():
    print(f"\n{'='*80}")
    print(f"  SPLIT: {split.upper()}")
    print(f"{'='*80}")

    df_m5 = pd.read_parquet(paths["b5_metrics"])
    df_m0 = pd.read_parquet(paths["b0_metrics"])
    df_p5 = pd.read_parquet(paths["b5_preds"])

    # Filter valid F1
    df_m5 = df_m5[df_m5["f1"].notna()].copy()
    df_m0 = df_m0[df_m0["f1"].notna()].copy()

    # Join metadata from predictions
    meta_cols = ["rule_id", "n_repair_attempts", "tdd_n_tests", "sandbox_ok", "final_status"]
    meta_cols = [c for c in meta_cols if c in df_p5.columns]
    df_m5 = df_m5.merge(df_p5[meta_cols], on="rule_id", how="left")

    # Join B0 F1
    df = df_m5.merge(
        df_m0[["rule_id", "f1", "dimension"]].rename(columns={"f1": "f1_b0", "dimension": "dim_b0"}),
        on="rule_id", how="inner"
    )

    # Compute variants
    df["f1_B5_full"] = df["f1"]
    df["f1_B5_minus_PIPELINE"] = df["f1_b0"]

    df["f1_B5_minus_REPAIR"] = df["f1"].copy()
    if "n_repair_attempts" in df.columns:
        mask_repair = df["n_repair_attempts"] > 0
        df.loc[mask_repair, "f1_B5_minus_REPAIR"] = df.loc[mask_repair, "f1_b0"]

    df["f1_B5_minus_TDD"] = df["f1"].copy()
    if "tdd_n_tests" in df.columns:
        mask_tdd = df["tdd_n_tests"] > 0
        df.loc[mask_tdd, "f1_B5_minus_TDD"] = df.loc[mask_tdd, "f1_b0"]

    df["f1_B5_minus_AST_SANDBOX"] = df["f1_B5_minus_REPAIR"].copy()

    VARIANTS = [
        "f1_B5_full",
        "f1_B5_minus_PIPELINE",
        "f1_B5_minus_REPAIR",
        "f1_B5_minus_TDD",
        "f1_B5_minus_AST_SANDBOX",
    ]

    # ── Summary table ──────────────────────────────────────────────────────
    print(f"\n  SUMMARY — {split}")
    print(f"  {'Variant':<35} {'F1':>7}  {'ΔvsB5':>8}  {'n_affected':>12}")
    print(f"  {'-'*70}")
    base_f1 = df["f1_B5_full"].mean()
    for v in VARIANTS:
        f1 = df[v].mean()
        delta = f1 - base_f1
        if v == "f1_B5_full":
            n_aff = len(df)
        elif v == "f1_B5_minus_PIPELINE":
            n_aff = len(df)
        elif v == "f1_B5_minus_REPAIR" and "n_repair_attempts" in df.columns:
            n_aff = int((df["n_repair_attempts"] > 0).sum())
        elif v == "f1_B5_minus_TDD" and "tdd_n_tests" in df.columns:
            n_aff = int((df["tdd_n_tests"] > 0).sum())
        elif v == "f1_B5_minus_AST_SANDBOX" and "n_repair_attempts" in df.columns:
            n_aff = int((df["n_repair_attempts"] > 0).sum())
        else:
            n_aff = 0
        print(f"  {v:<35} {f1:>7.4f}  {delta:>+8.4f}  {n_aff:>12}")

    # ── Per-rule detail ────────────────────────────────────────────────────
    print(f"\n  PER-RULE DETAIL — {split}")
    has_repair = "n_repair_attempts" in df.columns
    has_tdd    = "tdd_n_tests" in df.columns

    hdr = (f"  {'Rule':<12} {'Dim':<15} {'B5_full':>8} {'−PIPELINE':>10} "
           f"{'−REPAIR':>8} {'−TDD':>7} {'repairs':>8} {'tdd_n':>6}")
    print(hdr)
    print(f"  {'-'*85}")

    for _, row in df.sort_values("rule_id").iterrows():
        repair_n = int(row["n_repair_attempts"]) if has_repair and pd.notna(row.get("n_repair_attempts")) else 0
        tdd_n    = int(row["tdd_n_tests"])    if has_tdd    and pd.notna(row.get("tdd_n_tests"))    else 0

        changed_repair = "*" if (has_repair and repair_n > 0) else " "
        changed_tdd    = "*" if (has_tdd    and tdd_n    > 0) else " "

        print(
            f"  {row['rule_id']:<12} {row['dimension']:<15} "
            f"{row['f1_B5_full']:>8.3f} "
            f"{row['f1_B5_minus_PIPELINE']:>9.3f}{' ':1} "
            f"{row['f1_B5_minus_REPAIR']:>7.3f}{changed_repair} "
            f"{row['f1_B5_minus_TDD']:>6.3f}{changed_tdd} "
            f"{repair_n:>8} {tdd_n:>6}"
        )

    # ── Dimension breakdown ────────────────────────────────────────────────
    print(f"\n  BY DIMENSION — {split}")
    print(f"  {'Dim':<15} {'n':>4} {'B5_full':>8} {'−PIPELINE':>10} {'−REPAIR':>8} {'−TDD':>7}")
    print(f"  {'-'*60}")
    for dim, g in df.groupby("dimension"):
        print(
            f"  {dim:<15} {len(g):>4} "
            f"{g['f1_B5_full'].mean():>8.3f} "
            f"{g['f1_B5_minus_PIPELINE'].mean():>9.3f}  "
            f"{g['f1_B5_minus_REPAIR'].mean():>7.3f}  "
            f"{g['f1_B5_minus_TDD'].mean():>6.3f}"
        )

print("\nDone.")
