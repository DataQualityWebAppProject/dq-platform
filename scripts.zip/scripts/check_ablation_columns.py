import pandas as pd
import pathlib

_P = pathlib.Path("artifacts/predictions/pilot")

for pdir in ["B5", "B5_ext"]:
    pf = _P / pdir / "predictions.parquet"
    if not pf.exists():
        print(f"{pdir}: NOT FOUND")
        continue
    df = pd.read_parquet(pf)
    print(f"\n{'='*60}")
    print(f"{pdir}  n={len(df)}")
    print(f"{'='*60}")
    for col in df.columns:
        sample = df[col].iloc[0] if len(df) > 0 else "N/A"
        print(f"  {col:<30} {str(df[col].dtype):<12} {repr(str(sample))[:60]}")

    # Show pipeline_stages values to understand what stages are logged
    if "pipeline_stages" in df.columns:
        print(f"\n  pipeline_stages samples:")
        for v in df["pipeline_stages"].head(5):
            print(f"    {v[:100]}")

    # Count n_repair_attempts distribution
    if "n_repair_attempts" in df.columns:
        print(f"\n  n_repair_attempts distribution:")
        print(df["n_repair_attempts"].value_counts().sort_index().to_string())

    # Count tdd_n_tests distribution  
    if "tdd_n_tests" in df.columns:
        print(f"\n  tdd_n_tests distribution:")
        print(df["tdd_n_tests"].value_counts().sort_index().to_string())

    # Count sandbox_ok
    if "sandbox_ok" in df.columns:
        print(f"\n  sandbox_ok: {df['sandbox_ok'].sum()}/{len(df)} OK")

    # Count final_status
    if "final_status" in df.columns:
        print(f"\n  final_status distribution:")
        print(df["final_status"].value_counts().to_string())
