#!/usr/bin/env python3
"""Paraphrase pilot: run 3/5/7 paraphrase strategies on 100 rules.

Usage:
    python scripts/run_paraphrase_pilot.py --rules data/rules/pilot_100.jsonl

Per Wang & Zhu (2024/2026):
- n=3: baseline (low recall)
- n=5: recommended (75% recall, 8.6% FPR)
- n=7: high recall (may introduce clustering noise)
- repetition: same prompt N times (baseline without diversity)
- conservative: alarm on any disagreement
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rules", default=str(_REPO_ROOT / "data/rules/pilot_100.jsonl"))
    parser.add_argument("--output", default=str(_REPO_ROOT / "reports/paraphrase_pilot_results.md"))
    args = parser.parse_args()

    rules_path = Path(args.rules)
    if not rules_path.exists() or rules_path.stat().st_size < 50:
        print(
            f"ERROR: Rules file '{rules_path}' is empty or missing. "
            "Run T3.6 first to generate pilot rules.",
            file=sys.stderr,
        )
        return 1

    print("T5.4 Paraphrase pilot: requires LLM inference backend (T6.1+).")
    print("This script is a stub — full implementation requires T6.1 model adapters.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
