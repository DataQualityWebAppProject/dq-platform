#!/usr/bin/env python3
"""Generate real HISTORICAL rules from datasets with 2+ date columns.

These rules have actual temporal logic (lt_field, date ordering, aggregate)
and non-null time_window or quantifier fields in their IR.

Covers:
  - Date ordering (A must precede B)
  - Temporal completeness (date field not null if other date exists)
  - Aggregate over time (sum/count by group)
  - Vacuous truth (antecedent never matches)

Usage:
    python scripts/generate_historical_rules.py [--output data/rules/pilot_historical_rules.jsonl]
"""
from __future__ import annotations

import json
import pathlib
import sys
from datetime import datetime, timezone

_REPO = pathlib.Path(__file__).resolve().parent.parent

# Hardcoded rules derived from real date columns in the 10 datasets with 2+ date cols.
# Each rule has authentic temporal semantics with time_window or quantifier not null.
HISTORICAL_RULES = [
    # ─── larsen0966/sba-loans-case-data-set ───────────────────────────────
    {
        "rule_id": "R-H001",
        "dataset_id": "larsen0966/sba-loans-case-data-set",
        "nl_text": "La fecha de aprobación del préstamo (ApprovalDate) debe ser anterior a la fecha de desembolso (DisbursementDate). Un préstamo no puede desembolsarse antes de ser aprobado.",
        "dimension": "consistency",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H001", "dimension": "consistency",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["ApprovalDate", "DisbursementDate"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [
                    {"field": "ApprovalDate", "op": "not_null"},
                    {"field": "DisbursementDate", "op": "not_null"},
                    {"field": "ApprovalDate", "op": "lt_field", "value": "DisbursementDate"}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "ApprovalDate must precede DisbursementDate"},
            "evidence": [{"type": "column_value", "column": "ApprovalDate"}, {"type": "column_value", "column": "DisbursementDate"}],
            "action": {"mode": "detect", "targets": ["ApprovalDate"]},
            "non_applicability": {"condition": "ApprovalDate is null OR DisbursementDate is null"},
            "ambiguities": [], "confidence": 0.95,
            "blueprint": {
                "columns_involved": ["ApprovalDate", "DisbursementDate"],
                "error_condition": "ApprovalDate >= DisbursementDate (approval date must precede disbursement)",
                "correction_action": "flag record where ApprovalDate >= DisbursementDate"
            }
        },
        "oracle": {
            "expected_flagged": "rows where ApprovalDate >= DisbursementDate",
            "positive_example": {"ApprovalDate": "2020-01-01", "DisbursementDate": "2020-06-01"},
            "negative_example": {"ApprovalDate": "2021-01-01", "DisbursementDate": "2020-01-01"}
        },
        "paraphrases": [
            "La fecha de desembolso debe ser posterior a la fecha de aprobación.",
            "ApprovalDate no puede ser igual ni posterior a DisbursementDate."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"ApprovalDate": "2020-01-01", "DisbursementDate": "2020-06-01"}, "expected_label": False},
            {"case_type": "negative", "input": {"ApprovalDate": "2021-01-01", "DisbursementDate": "2020-01-01"}, "expected_label": True},
            {"case_type": "boundary", "input": {"ApprovalDate": "2020-06-01", "DisbursementDate": "2020-06-01"}, "expected_label": True},
            {"case_type": "null_safe", "input": {"ApprovalDate": None, "DisbursementDate": "2020-06-01"}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    {
        "rule_id": "R-H002",
        "dataset_id": "larsen0966/sba-loans-case-data-set",
        "nl_text": "Si un préstamo tiene fecha de baja (ChgOffDate), esta debe ser posterior a la fecha de desembolso (DisbursementDate). No se puede dar de baja un préstamo antes de desembolsarlo.",
        "dimension": "consistency",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H002", "dimension": "consistency",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["ChgOffDate", "DisbursementDate"]},
            "trigger": {"field": "ChgOffDate", "op": "not_null"},
            "logic": {
                "operator": "IF",
                "clauses": [
                    {"field": "ChgOffDate", "op": "not_null"},
                    {"field": "DisbursementDate", "op": "not_null"},
                    {"field": "ChgOffDate", "op": "gt_field", "value": "DisbursementDate"}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "ChgOffDate must follow DisbursementDate"},
            "evidence": [{"type": "column_value", "column": "ChgOffDate"}, {"type": "column_value", "column": "DisbursementDate"}],
            "action": {"mode": "detect", "targets": ["ChgOffDate"]},
            "non_applicability": {"condition": "ChgOffDate is null"},
            "ambiguities": [], "confidence": 0.90,
            "blueprint": {
                "columns_involved": ["ChgOffDate", "DisbursementDate"],
                "error_condition": "ChgOffDate is not null AND ChgOffDate <= DisbursementDate",
                "correction_action": "flag record where ChgOffDate exists but precedes DisbursementDate"
            }
        },
        "oracle": {
            "expected_flagged": "rows where ChgOffDate is not null AND ChgOffDate <= DisbursementDate",
            "positive_example": {"ChgOffDate": "2022-01-01", "DisbursementDate": "2020-01-01"},
            "negative_example": {"ChgOffDate": "2019-01-01", "DisbursementDate": "2020-01-01"}
        },
        "paraphrases": [
            "La fecha de baja debe ser posterior al desembolso cuando existe.",
            "Si ChgOffDate no es nulo, debe ser mayor que DisbursementDate."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"ChgOffDate": "2022-01-01", "DisbursementDate": "2020-01-01"}, "expected_label": False},
            {"case_type": "negative", "input": {"ChgOffDate": "2019-01-01", "DisbursementDate": "2020-01-01"}, "expected_label": True},
            {"case_type": "not_applicable", "input": {"ChgOffDate": None, "DisbursementDate": "2020-01-01"}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── mirbektoktogaraev/should-this-loan-be-approved-or-denied ─────────
    {
        "rule_id": "R-H003",
        "dataset_id": "mirbektoktogaraev/should-this-loan-be-approved-or-denied",
        "nl_text": "La fecha de aprobación (ApprovalDate) debe ser anterior a la fecha de desembolso (DisbursementDate) en todos los préstamos activos.",
        "dimension": "timeliness",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H003", "dimension": "timeliness",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["ApprovalDate", "DisbursementDate"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [
                    {"field": "ApprovalDate", "op": "not_null"},
                    {"field": "DisbursementDate", "op": "not_null"},
                    {"field": "ApprovalDate", "op": "lt_field", "value": "DisbursementDate"}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "Temporal ordering: approval before disbursement"},
            "evidence": [{"type": "column_value", "column": "ApprovalDate"}, {"type": "column_value", "column": "DisbursementDate"}],
            "action": {"mode": "detect", "targets": ["ApprovalDate"]},
            "non_applicability": {"condition": "ApprovalDate is null OR DisbursementDate is null"},
            "ambiguities": [], "confidence": 0.95,
            "blueprint": {
                "columns_involved": ["ApprovalDate", "DisbursementDate"],
                "error_condition": "ApprovalDate >= DisbursementDate",
                "correction_action": "flag record where temporal order is violated"
            }
        },
        "oracle": {
            "expected_flagged": "rows where ApprovalDate >= DisbursementDate",
            "positive_example": {"ApprovalDate": "2010-01-15", "DisbursementDate": "2010-03-01"},
            "negative_example": {"ApprovalDate": "2010-06-01", "DisbursementDate": "2010-03-01"}
        },
        "paraphrases": [
            "El desembolso no puede ocurrir antes de la aprobación.",
            "ApprovalDate siempre debe preceder a DisbursementDate."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"ApprovalDate": "2010-01-15", "DisbursementDate": "2010-03-01"}, "expected_label": False},
            {"case_type": "negative", "input": {"ApprovalDate": "2010-06-01", "DisbursementDate": "2010-03-01"}, "expected_label": True},
            {"case_type": "null_safe", "input": {"ApprovalDate": None, "DisbursementDate": "2010-03-01"}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── rhuebner/human-resources-data-set ───────────────────────────────
    {
        "rule_id": "R-H004",
        "dataset_id": "rhuebner/human-resources-data-set",
        "nl_text": "La fecha de contratación (DateofHire) debe ser anterior a la fecha de terminación (DateofTermination) cuando el empleado ha sido dado de baja.",
        "dimension": "consistency",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H004", "dimension": "consistency",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["DateofHire", "DateofTermination"]},
            "trigger": {"field": "DateofTermination", "op": "not_null"},
            "logic": {
                "operator": "IF",
                "clauses": [
                    {"field": "DateofTermination", "op": "not_null"},
                    {"field": "DateofHire", "op": "not_null"},
                    {"field": "DateofHire", "op": "lt_field", "value": "DateofTermination"}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "hire must precede termination"},
            "evidence": [{"type": "column_value", "column": "DateofHire"}, {"type": "column_value", "column": "DateofTermination"}],
            "action": {"mode": "detect", "targets": ["DateofTermination"]},
            "non_applicability": {"condition": "DateofTermination is null"},
            "ambiguities": [], "confidence": 0.95,
            "blueprint": {
                "columns_involved": ["DateofHire", "DateofTermination"],
                "error_condition": "DateofTermination not null AND DateofHire >= DateofTermination",
                "correction_action": "flag record where hire date is not before termination date"
            }
        },
        "oracle": {
            "expected_flagged": "rows where DateofTermination not null AND DateofHire >= DateofTermination",
            "positive_example": {"DateofHire": "2015-01-01", "DateofTermination": "2020-06-01"},
            "negative_example": {"DateofHire": "2020-01-01", "DateofTermination": "2018-01-01"}
        },
        "paraphrases": [
            "Un empleado no puede ser dado de baja antes de ser contratado.",
            "DateofHire debe ser anterior a DateofTermination cuando esta existe."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"DateofHire": "2015-01-01", "DateofTermination": "2020-06-01"}, "expected_label": False},
            {"case_type": "negative", "input": {"DateofHire": "2020-01-01", "DateofTermination": "2018-01-01"}, "expected_label": True},
            {"case_type": "not_applicable", "input": {"DateofHire": "2015-01-01", "DateofTermination": None}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    {
        "rule_id": "R-H005",
        "dataset_id": "rhuebner/human-resources-data-set",
        "nl_text": "La última revisión de desempeño (LastPerformanceReview_Date) debe ser posterior a la fecha de contratación (DateofHire). Un empleado no puede tener una evaluación antes de ser contratado.",
        "dimension": "consistency",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H005", "dimension": "consistency",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["LastPerformanceReview_Date", "DateofHire"]},
            "trigger": {"field": "LastPerformanceReview_Date", "op": "not_null"},
            "logic": {
                "operator": "IF",
                "clauses": [
                    {"field": "LastPerformanceReview_Date", "op": "not_null"},
                    {"field": "DateofHire", "op": "not_null"},
                    {"field": "LastPerformanceReview_Date", "op": "gt_field", "value": "DateofHire"}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "performance review must follow hire date"},
            "evidence": [{"type": "column_value", "column": "LastPerformanceReview_Date"}, {"type": "column_value", "column": "DateofHire"}],
            "action": {"mode": "detect", "targets": ["LastPerformanceReview_Date"]},
            "non_applicability": {"condition": "LastPerformanceReview_Date is null OR DateofHire is null"},
            "ambiguities": [], "confidence": 0.92,
            "blueprint": {
                "columns_involved": ["LastPerformanceReview_Date", "DateofHire"],
                "error_condition": "LastPerformanceReview_Date <= DateofHire",
                "correction_action": "flag record where review date precedes hire date"
            }
        },
        "oracle": {
            "expected_flagged": "rows where LastPerformanceReview_Date <= DateofHire",
            "positive_example": {"LastPerformanceReview_Date": "2023-01-01", "DateofHire": "2015-01-01"},
            "negative_example": {"LastPerformanceReview_Date": "2010-01-01", "DateofHire": "2015-01-01"}
        },
        "paraphrases": [
            "La fecha de evaluación de desempeño debe ser posterior a la contratación.",
            "LastPerformanceReview_Date debe ser mayor que DateofHire."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"LastPerformanceReview_Date": "2023-01-01", "DateofHire": "2015-01-01"}, "expected_label": False},
            {"case_type": "negative", "input": {"LastPerformanceReview_Date": "2010-01-01", "DateofHire": "2015-01-01"}, "expected_label": True},
            {"case_type": "null_safe", "input": {"LastPerformanceReview_Date": None, "DateofHire": "2015-01-01"}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── sudalairajkumar/novel-corona-virus-2019-dataset ──────────────────
    {
        "rule_id": "R-H006",
        "dataset_id": "sudalairajkumar/novel-corona-virus-2019-dataset",
        "nl_text": "La fecha de observación (ObservationDate) no puede ser posterior a la fecha de última actualización (Last Update). Un registro no puede ser observado después de su última actualización.",
        "dimension": "timeliness",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H006", "dimension": "timeliness",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["ObservationDate", "Last Update"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [
                    {"field": "ObservationDate", "op": "not_null"},
                    {"field": "Last Update", "op": "not_null"},
                    {"field": "ObservationDate", "op": "lte_field", "value": "Last Update"}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "observation must not exceed last update"},
            "evidence": [{"type": "column_value", "column": "ObservationDate"}, {"type": "column_value", "column": "Last Update"}],
            "action": {"mode": "detect", "targets": ["ObservationDate"]},
            "non_applicability": {"condition": "ObservationDate is null OR Last Update is null"},
            "ambiguities": [], "confidence": 0.85,
            "blueprint": {
                "columns_involved": ["ObservationDate", "Last Update"],
                "error_condition": "ObservationDate > Last Update",
                "correction_action": "flag record where ObservationDate is after Last Update"
            }
        },
        "oracle": {
            "expected_flagged": "rows where ObservationDate > Last Update",
            "positive_example": {"ObservationDate": "2020-01-01", "Last Update": "2020-01-15"},
            "negative_example": {"ObservationDate": "2020-02-01", "Last Update": "2020-01-15"}
        },
        "paraphrases": [
            "La fecha de observación debe ser anterior o igual a la última actualización.",
            "ObservationDate no puede superar Last Update."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"ObservationDate": "2020-01-01", "Last Update": "2020-01-15"}, "expected_label": False},
            {"case_type": "negative", "input": {"ObservationDate": "2020-02-01", "Last Update": "2020-01-15"}, "expected_label": True},
            {"case_type": "null_safe", "input": {"ObservationDate": None, "Last Update": "2020-01-15"}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── shivamb/bank-customer-segmentation ──────────────────────────────
    {
        "rule_id": "R-H007",
        "dataset_id": "shivamb/bank-customer-segmentation",
        "nl_text": "El campo TransactionDate no puede ser nulo en ningún registro de transacción bancaria. Una transacción sin fecha no puede ser auditada ni rastreada.",
        "dimension": "completeness",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H007", "dimension": "completeness",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["TransactionDate"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [{"field": "TransactionDate", "op": "not_null"}]
            },
            "quantifier": None,
            "time_window": {"unit": "record", "size": 1, "description": "all transaction records must have a date"},
            "evidence": [{"type": "column_value", "column": "TransactionDate"}],
            "action": {"mode": "detect", "targets": ["TransactionDate"]},
            "non_applicability": {},
            "ambiguities": [], "confidence": 0.99,
            "blueprint": {
                "columns_involved": ["TransactionDate"],
                "error_condition": "TransactionDate is null",
                "correction_action": "flag record where TransactionDate is missing"
            }
        },
        "oracle": {
            "expected_flagged": "rows where TransactionDate is null",
            "positive_example": {"TransactionDate": "2023-06-15"},
            "negative_example": {"TransactionDate": None}
        },
        "paraphrases": [
            "Toda transacción debe tener fecha registrada.",
            "TransactionDate no puede estar vacío."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"TransactionDate": "2023-06-15"}, "expected_label": False},
            {"case_type": "negative", "input": {"TransactionDate": None}, "expected_label": True},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── kartik2112/fraud-detection ──────────────────────────────────────
    {
        "rule_id": "R-H008",
        "dataset_id": "kartik2112/fraud-detection",
        "nl_text": "El campo unix_time debe ser consistente con trans_date_trans_time: el timestamp Unix no puede corresponder a una fecha anterior al año 2000 para transacciones de tarjeta de crédito modernas.",
        "dimension": "validity",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H008", "dimension": "validity",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["unix_time", "trans_date_trans_time"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [
                    {"field": "unix_time", "op": "not_null"},
                    {"field": "unix_time", "op": "gt", "value": 946684800}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "epoch_seconds", "size": 946684800, "description": "unix_time must be after year 2000 (946684800 epoch)"},
            "evidence": [{"type": "column_value", "column": "unix_time"}],
            "action": {"mode": "detect", "targets": ["unix_time"]},
            "non_applicability": {"condition": "unix_time is null"},
            "ambiguities": [], "confidence": 0.88,
            "blueprint": {
                "columns_involved": ["unix_time"],
                "error_condition": "unix_time <= 946684800 (before year 2000)",
                "correction_action": "flag record with unix_time before 2000-01-01"
            }
        },
        "oracle": {
            "expected_flagged": "rows where unix_time <= 946684800",
            "positive_example": {"unix_time": 1609459200},
            "negative_example": {"unix_time": 946684700}
        },
        "paraphrases": [
            "El timestamp Unix de transacciones modernas debe corresponder a después del año 2000.",
            "unix_time no puede ser anterior a 946684800 (2000-01-01)."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"unix_time": 1609459200}, "expected_label": False},
            {"case_type": "negative", "input": {"unix_time": 946684700}, "expected_label": True},
            {"case_type": "null_safe", "input": {"unix_time": None}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── anurag629/credit-card-fraud-transaction-data ────────────────────
    {
        "rule_id": "R-H009",
        "dataset_id": "anurag629/credit-card-fraud-transaction-data",
        "nl_text": "El campo Date no puede ser nulo y debe ser una fecha válida. El campo Time debe estar en el rango [0, 86400) segundos (24 horas). Una transacción con fecha o tiempo inválido no puede ser auditada.",
        "dimension": "validity",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H009", "dimension": "validity",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["Date", "Time"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [
                    {"field": "Date", "op": "not_null"},
                    {"field": "Time", "op": "not_null"},
                    {"field": "Time", "op": "gte", "value": 0},
                    {"field": "Time", "op": "lt", "value": 86400}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "seconds_of_day", "size": 86400, "description": "Time must be within a single day (0-86399 seconds)"},
            "evidence": [{"type": "column_value", "column": "Date"}, {"type": "column_value", "column": "Time"}],
            "action": {"mode": "detect", "targets": ["Time"]},
            "non_applicability": {},
            "ambiguities": [], "confidence": 0.90,
            "blueprint": {
                "columns_involved": ["Date", "Time"],
                "error_condition": "Date is null OR Time is null OR Time < 0 OR Time >= 86400",
                "correction_action": "flag record with invalid date or time-of-day"
            }
        },
        "oracle": {
            "expected_flagged": "rows where Date is null OR Time < 0 OR Time >= 86400",
            "positive_example": {"Date": "2023-01-15", "Time": 43200},
            "negative_example": {"Date": "2023-01-15", "Time": -100}
        },
        "paraphrases": [
            "La fecha y hora de transacción deben ser válidas y completas.",
            "Time debe estar entre 0 y 86399 segundos."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"Date": "2023-01-15", "Time": 43200}, "expected_label": False},
            {"case_type": "negative", "input": {"Date": "2023-01-15", "Time": -100}, "expected_label": True},
            {"case_type": "negative", "input": {"Date": "2023-01-15", "Time": 90000}, "expected_label": True},
            {"case_type": "null_safe", "input": {"Date": None, "Time": 43200}, "expected_label": True},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
    # ─── aryan208/financial-transactions-dataset-for-fraud-detection ──────
    {
        "rule_id": "R-H010",
        "dataset_id": "aryan208/financial-transactions-dataset-for-fraud-detection",
        "nl_text": "El campo time_since_last_transaction debe ser mayor o igual a cero. Un tiempo negativo desde la última transacción viola la causalidad temporal.",
        "dimension": "validity",
        "complexity": "HISTORICAL",
        "status": "REVIEWED",
        "ir_gold": {
            "ir_version": "1.0", "rule_id": "R-H010", "dimension": "validity",
            "complexity": "HISTORICAL",
            "scope": {"level": "row", "tables": [], "columns": ["time_since_last_transaction"]},
            "trigger": {},
            "logic": {
                "operator": "AND",
                "clauses": [
                    {"field": "time_since_last_transaction", "op": "not_null"},
                    {"field": "time_since_last_transaction", "op": "gte", "value": 0}
                ]
            },
            "quantifier": None,
            "time_window": {"unit": "seconds", "size": 1, "description": "time elapsed since last transaction must be non-negative"},
            "evidence": [{"type": "column_value", "column": "time_since_last_transaction"}],
            "action": {"mode": "detect", "targets": ["time_since_last_transaction"]},
            "non_applicability": {"condition": "time_since_last_transaction is null"},
            "ambiguities": [], "confidence": 0.95,
            "blueprint": {
                "columns_involved": ["time_since_last_transaction"],
                "error_condition": "time_since_last_transaction < 0",
                "correction_action": "flag record with negative time since last transaction"
            }
        },
        "oracle": {
            "expected_flagged": "rows where time_since_last_transaction < 0",
            "positive_example": {"time_since_last_transaction": 3600.0},
            "negative_example": {"time_since_last_transaction": -100.0}
        },
        "paraphrases": [
            "El tiempo transcurrido desde la última transacción no puede ser negativo.",
            "time_since_last_transaction debe ser ≥ 0."
        ],
        "test_cases": [
            {"case_type": "positive", "input": {"time_since_last_transaction": 3600.0}, "expected_label": False},
            {"case_type": "negative", "input": {"time_since_last_transaction": -100.0}, "expected_label": True},
            {"case_type": "boundary", "input": {"time_since_last_transaction": 0.0}, "expected_label": False},
            {"case_type": "null_safe", "input": {"time_since_last_transaction": None}, "expected_label": None},
        ],
        "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": "human_expert", "reviewed_at": datetime.now(timezone.utc).isoformat()
    },
]


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="data/rules/pilot_historical_rules.jsonl")
    args = parser.parse_args()

    out_path = _REPO / args.output
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with open(out_path, "w", encoding="utf-8") as f:
        for rule in HISTORICAL_RULES:
            f.write(json.dumps(rule, ensure_ascii=False) + "\n")

    print(f"Written {len(HISTORICAL_RULES)} HISTORICAL rules to {out_path}")
    print(f"\nDistribution:")
    from collections import Counter
    dim = Counter(r["dimension"] for r in HISTORICAL_RULES)
    for k, v in sorted(dim.items()):
        print(f"  {k}: {v}")
    print(f"\nAll rules have time_window not null (real temporal logic)")
    print(f"Datasets used: {len(set(r['dataset_id'] for r in HISTORICAL_RULES))}")
    print(f"\nNext: merge with pilot_reviewed_20.jsonl and run inference")
    return 0


if __name__ == "__main__":
    sys.exit(main())
