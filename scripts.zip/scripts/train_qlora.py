#!/usr/bin/env python3
"""T6.4 — QLoRA fine-tuning script for NL→code (Baseline B3).

Usage:
    python scripts/train_qlora.py --config configs/qlora_nl2code.yaml --seed 42

v3: Uses static padding (padding=max_length) during tokenization so all
examples have identical tensor shapes. Labels are -100 for pad positions.
Uses DefaultDataCollator — no dynamic padding needed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(65536):
            digest.update(chunk)
    return digest.hexdigest()


def _load_pairs(jsonl_path: Path) -> list[dict]:
    pairs = []
    with jsonl_path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                pairs.append(json.loads(line))
    return pairs


def _format_prompt(nl: str, code: str) -> str:
    """Format prompt for NL→code training (B3)."""
    system = (
        "Eres un experto en calidad de datos bancarios. "
        "Dado una regla de calidad en lenguaje natural, genera una función Python "
        "`check(df)` que recibe un pandas DataFrame y retorna una lista de índices "
        "de filas que violan la regla. Solo usa pandas, numpy, re, math, datetime."
    )
    user = f"Regla de calidad:\n{nl}\n\nGenera la función check(df):"
    return (
        f"<|im_start|>system\n{system}<|im_end|>\n"
        f"<|im_start|>user\n{user}<|im_end|>\n"
        f"<|im_start|>assistant\n{code}<|im_end|>"
    )


def _format_prompt_ir(instruction: str, input_text: str, output: str) -> str:
    """Format prompt for NL→IR training (B4). Uses instruction/input/output format."""
    return (
        f"<|im_start|>system\n{instruction}<|im_end|>\n"
        f"<|im_start|>user\n{input_text}<|im_end|>\n"
        f"<|im_start|>assistant\n{output}<|im_end|>"
    )


def _get_text_for_pair(p: dict) -> str:
    """Extract text from a training pair regardless of format (nl/code or instruction/input/output)."""
    if "nl" in p and "code" in p:
        return _format_prompt(p["nl"], p["code"])
    elif "instruction" in p and "input" in p and "output" in p:
        return _format_prompt_ir(p["instruction"], p["input"], p["output"])
    else:
        raise KeyError(f"Training pair has neither nl/code nor instruction/input/output fields: {list(p.keys())}")


def train(config_path: str, seed: int) -> None:
    import torch
    from transformers import (
        AutoTokenizer,
        AutoModelForCausalLM,
        BitsAndBytesConfig,
        TrainingArguments,
        Trainer,
        DefaultDataCollator,
    )
    from peft import LoraConfig, get_peft_model, TaskType, prepare_model_for_kbit_training
    from datasets import Dataset

    cfg = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    t_cfg = cfg["training"]
    l_cfg = cfg["lora"]
    q_cfg = cfg["quantization"]
    max_seq = t_cfg["max_seq_length"]

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    if not token:
        print("WARNING: HF_TOKEN not set — loading from local cache.")

    # ── Verify training data hash ─────────────────────────────────────────────
    data_path = _REPO_ROOT / cfg["data"]["training_file"]
    actual_hash = _sha256(data_path)
    expected_hash = cfg["data"].get("data_hash", "")
    if expected_hash and actual_hash != expected_hash:
        raise ValueError(
            f"Training data hash mismatch!\n"
            f"  Expected: {expected_hash}\n"
            f"  Actual:   {actual_hash}\n"
            "Do not train on tampered data."
        )
    print(f"Data hash verified: {actual_hash[:16]}...")

    pairs = _load_pairs(data_path)
    print(f"Loaded {len(pairs)} training pairs")

    adapter_type = cfg.get("adapter_type", "qlora_nl2code")
    adapter_dir = _REPO_ROOT / f"artifacts/adapters/{adapter_type}_seed{seed}"
    adapter_dir.mkdir(parents=True, exist_ok=True)

    model_id = cfg["base_model"]
    print(f"Loading tokenizer: {model_id}")
    tokenizer = AutoTokenizer.from_pretrained(
        model_id, trust_remote_code=False, token=token or None,
    )
    tokenizer.padding_side = "right"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    pad_id = tokenizer.pad_token_id

    # ── Tokenize with static padding so all tensors are the same shape ────────
    print(f"Tokenizing {len(pairs)} examples with max_length={max_seq}...")
    all_input_ids = []
    all_attention_mask = []
    all_labels = []

    for p in pairs:
        text = _get_text_for_pair(p)
        enc = tokenizer(
            text,
            truncation=True,
            padding="max_length",
            max_length=max_seq,
            return_tensors=None,  # plain lists
        )
        ids = enc["input_ids"]
        mask = enc["attention_mask"]
        # Labels: same as input_ids but -100 for padding tokens (loss ignored)
        labels = [tok if tok != pad_id else -100 for tok in ids]
        all_input_ids.append(ids)
        all_attention_mask.append(mask)
        all_labels.append(labels)

    tokenized = Dataset.from_dict({
        "input_ids": all_input_ids,
        "attention_mask": all_attention_mask,
        "labels": all_labels,
    })
    tokenized.set_format("torch")
    print(f"Dataset ready: {len(tokenized)} examples, shape: input_ids[0] len={len(all_input_ids[0])}")

    # ── Load quantized model ──────────────────────────────────────────────────
    print(f"Loading model: {model_id} (4-bit NF4)")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=q_cfg["load_in_4bit"],
        bnb_4bit_quant_type=q_cfg["bnb_4bit_quant_type"],
        bnb_4bit_compute_dtype=getattr(torch, q_cfg["bnb_4bit_compute_dtype"]),
        bnb_4bit_use_double_quant=q_cfg["bnb_4bit_use_double_quant"],
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=False,
        token=token or None,
    )
    model.config.use_cache = False
    model = prepare_model_for_kbit_training(model)

    lora_config = LoraConfig(
        r=l_cfg["r"],
        lora_alpha=l_cfg["lora_alpha"],
        lora_dropout=l_cfg["lora_dropout"],
        target_modules=l_cfg["target_modules"],
        bias=l_cfg["bias"],
        task_type=TaskType.CAUSAL_LM,
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    training_args = TrainingArguments(
        output_dir=str(adapter_dir / "checkpoints"),
        num_train_epochs=t_cfg["num_train_epochs"],
        per_device_train_batch_size=t_cfg["per_device_train_batch_size"],
        gradient_accumulation_steps=t_cfg["gradient_accumulation_steps"],
        learning_rate=t_cfg["learning_rate"],
        warmup_ratio=t_cfg["warmup_ratio"],
        lr_scheduler_type=t_cfg["lr_scheduler_type"],
        seed=seed,
        bf16=torch.cuda.is_bf16_supported(),
        fp16=not torch.cuda.is_bf16_supported(),
        logging_steps=10,
        save_strategy="epoch",
        report_to="none",
        remove_unused_columns=False,
        dataloader_pin_memory=False,
        optim="paged_adamw_8bit",
    )

    trainer = Trainer(
        model=model,
        train_dataset=tokenized,
        args=training_args,
        data_collator=DefaultDataCollator(),
    )

    print(f"Starting QLoRA training — seed={seed}, epochs={t_cfg['num_train_epochs']}")
    trainer.train()

    trainer.model.save_pretrained(str(adapter_dir))
    tokenizer.save_pretrained(str(adapter_dir))
    print(f"Adapter saved to: {adapter_dir}")

    manifest = {
        "adapter_type": cfg["adapter_type"],
        "base_model": model_id,
        "seed": seed,
        "trained_at_utc": datetime.now(timezone.utc).isoformat(),
        "training_file": str(data_path),
        "data_hash": actual_hash,
        "n_pairs": len(pairs),
        "lora_r": l_cfg["r"],
        "lora_alpha": l_cfg["lora_alpha"],
        "lora_dropout": l_cfg["lora_dropout"],
        "target_modules": l_cfg["target_modules"],
        "num_train_epochs": t_cfg["num_train_epochs"],
        "learning_rate": t_cfg["learning_rate"],
        "max_seq_length": max_seq,
        "adapter_path": str(adapter_dir),
        "config_path": str(Path(config_path).resolve()),
    }
    (adapter_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print("Run manifest written.")
    print("Training complete.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/qlora_nl2code.yaml")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    config_path = _REPO_ROOT / args.config
    if not config_path.exists():
        print(f"ERROR: Config not found: {config_path}", file=sys.stderr)
        return 1

    train(str(config_path), args.seed)
    return 0


if __name__ == "__main__":
    sys.exit(main())
