import pandas as pd
import pathlib

base = pathlib.Path("artifacts/metrics/pilot")

configs = sorted(base.glob("*_ext_metrics.parquet"))
for f in configs:
    df = pd.read_parquet(f)
    valid = df[df["f1"].notna()]
    config = f.stem.replace("_metrics", "")
    f1_col = valid["f1"]
    print(f"=== {config} ===")
    print(f"  n_total={len(df)}  n_valid={len(valid)}")
    print(f"  F1_macro={f1_col.mean():.4f}")
    print(f"  F1=1: {(f1_col==1.0).sum()}  F1>0.5: {(f1_col>0.5).sum()}  F1=0: {(f1_col==0).sum()}")
    print(f"  errors: {df['error'].notna().sum()}")
    if "dimension" in df.columns:
        for dim, g in valid.groupby("dimension"):
            g_f1 = g["f1"]
            print(f"    {dim}: F1={g_f1.mean():.3f} (n={len(g)})")
    print()
