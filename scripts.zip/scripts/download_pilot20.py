#!/usr/bin/env python3
"""Pilot-20: search, filter and download 20 eligible banking/finance datasets from Kaggle.

Usage:
    python scripts/download_pilot20.py [--dry-run] [--target 20]

Steps:
    1. Search Kaggle for banking/finance/credit tabular datasets
    2. Filter by license, size, format (eligibility)
    3. Download top 20 eligible to ~/.nlq_benchmark_cache/
    4. Profile each with DuckDB
    5. Register in data/registry/datasets.csv
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

_SEARCH_QUERIES = [
    "bank transactions",
    "credit card fraud",
    "loan default",
    "financial transactions",
    "banking customers",
    "credit scoring",
    "insurance claims",
    "financial data quality",
    "bank account",
    "payment fraud detection",
]

_TARGET = 20
_MAX_SIZE_BYTES = 300 * 1024 * 1024   # 300 MB
_MIN_USABILITY = 0.4


def _attr(obj, *names, default=""):
    """Try multiple attribute names, return first found."""
    for name in names:
        v = getattr(obj, name, None)
        if v is not None:
            return v
    return default


def search_candidates(api, query: str) -> list:
    """Search Kaggle for datasets matching query. Returns raw dataset objects."""
    try:
        # Correct Kaggle API signature: no page_size, uses page=1
        results = api.dataset_list(
            search=query,
            file_type="csv",
            license_name="cc",
            page=1,
        )
        return list(results) if results else []
    except Exception as e:
        print(f"  Search '{query}' failed: {e}")
        return []


def get_dataset_id(ds) -> str:
    """Extract owner/slug from dataset object."""
    ref = _attr(ds, "ref", "ownerRef", "owner_ref", default="")
    if ref and "/" in str(ref):
        return str(ref).strip("/")
    owner = _attr(ds, "ownerRef", "owner_ref", "owner", default="")
    slug = _attr(ds, "slug", "datasetSlug", "dataset_slug", default="")
    if owner and slug:
        return f"{owner}/{slug}".strip("/")
    return ""


def is_eligible(ds) -> tuple[bool, str]:
    """Quick eligibility check on metadata."""
    # License
    lic = str(_attr(ds, "licenseName", "license_name", "license", default="")).lower()
    if not any(kw in lic for kw in ["cc0", "cc-by", "cc by", "public domain", "open data", "apache", "mit"]):
        return False, f"License: '{lic}'"

    # Size
    size = int(_attr(ds, "totalBytes", "total_bytes", "size", default=0) or 0)
    if size == 0:
        return False, "Size=0"
    if size > _MAX_SIZE_BYTES:
        return False, f"Too large: {size/1e6:.0f} MB"

    # Usability
    usability = float(_attr(ds, "usabilityRating", "usability_rating", default=0) or 0)
    if usability < _MIN_USABILITY:
        return False, f"Usability={usability:.2f} < {_MIN_USABILITY}"

    return True, "OK"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true",
                        help="Search and filter only, do not download")
    parser.add_argument("--target", type=int, default=_TARGET)
    args = parser.parse_args()

    # Auth
    try:
        import kaggle
        api = kaggle.KaggleApi()
        api.authenticate()
        print("Kaggle auth OK")
    except Exception as e:
        print(f"ERROR: Kaggle auth failed: {e}", file=sys.stderr)
        return 1

    # Search and filter
    candidates: list[dict] = []
    seen_ids: set[str] = set()

    for query in _SEARCH_QUERIES:
        if len(candidates) >= args.target * 4:
            break
        print(f"Searching: '{query}'...")
        results = search_candidates(api, query)
        found = 0
        for ds in (results or []):
            did = get_dataset_id(ds)
            if not did or did in seen_ids:
                continue
            seen_ids.add(did)
            eligible, reason = is_eligible(ds)
            size = int(_attr(ds, "totalBytes", "total_bytes", default=0) or 0)
            title = str(_attr(ds, "title", default=""))
            usability = float(_attr(ds, "usabilityRating", "usability_rating", default=0) or 0)
            votes = int(_attr(ds, "voteCount", "vote_count", default=0) or 0)
            lic = str(_attr(ds, "licenseName", "license_name", default=""))
            if eligible:
                candidates.append({
                    "dataset_id": did,
                    "title": title,
                    "size_bytes": size,
                    "license": lic,
                    "usability": usability,
                    "votes": votes,
                })
                found += 1
                print(f"  [OK]   {did} — {title[:50]} ({size/1e6:.1f} MB, u={usability:.2f})")
            else:
                print(f"  [skip] {did}: {reason}")
        print(f"  => {found} eligible this query, {len(candidates)} total so far")

    # Sort by usability then votes
    candidates.sort(key=lambda x: (x["usability"], x["votes"]), reverse=True)
    selected = candidates[:args.target]

    print(f"\nSelected {len(selected)} / {len(candidates)} candidates")

    if len(selected) == 0:
        print("ERROR: No eligible datasets found. Check credentials and API.")
        return 1

    if args.dry_run:
        print("\n[DRY RUN] Would download:")
        for i, c in enumerate(selected, 1):
            print(f"  {i:2d}. {c['dataset_id']:<45} {c['size_bytes']/1e6:6.1f} MB  u={c['usability']:.2f}  {c['title'][:40]}")
        print(f"\nTotal: {sum(c['size_bytes'] for c in selected)/1e6:.0f} MB estimated")
        return 0

    # Download, profile and register
    from data_registry.downloader import download_dataset, DEFAULT_CACHE_DIR
    from data_registry.profiler import profile_dataset
    from data_registry.registry import freeze_registry
    from models.dataset import DatasetRecord
    from pydantic import AnyUrl

    registered: list[DatasetRecord] = []
    failed: list[str] = []

    for i, c in enumerate(selected, 1):
        did = c["dataset_id"]
        if "/" not in did:
            print(f"  [skip] Invalid dataset_id: {did}")
            continue
        owner, slug = did.split("/", 1)
        print(f"\n[{i}/{len(selected)}] {did} ({c['size_bytes']/1e6:.1f} MB)...")

        try:
            raw_dir = download_dataset(owner, slug, cache_root=DEFAULT_CACHE_DIR)
            print(f"  Downloaded -> {raw_dir}")
        except Exception as e:
            print(f"  ERROR download: {e}")
            failed.append(did)
            continue

        fmt, n_tables = "csv", 1
        try:
            prof = profile_dataset(owner, slug, str(raw_dir))
            fmt = prof.format if prof.format != "unknown" else "csv"
            n_tables = max(prof.n_tables, 1)
            print(f"  Profiled: {n_tables} table(s), format={fmt}")
        except Exception as e:
            print(f"  WARNING profile: {e}")

        try:
            rec = DatasetRecord(
                owner=owner,
                slug=slug,
                url=AnyUrl(f"https://www.kaggle.com/datasets/{owner}/{slug}"),
                version="1",
                license=c["license"] or "CC",
                eligible=True,
                eligibility_reason="Automated check: license + size + usability",
                format=fmt,
                n_tables=n_tables,
            )
            registered.append(rec)
            print(f"  Registered.")
        except Exception as e:
            print(f"  ERROR register: {e}")
            failed.append(did)

    if not registered:
        print("\nERROR: Nothing registered.")
        return 1

    registry_dir = _REPO_ROOT / "data/registry"
    frozen = freeze_registry(registered, phase="pilot-20", registry_dir=str(registry_dir))
    print(f"\nRegistry saved: {frozen}")
    print(f"Registered {len(registered)} datasets. Failed: {len(failed)}")
    if failed:
        for f in failed:
            print(f"  FAILED: {f}")

    print("\nNext: python scripts/audit_registry.py --target 20 --phase pilot-20")
    return 0


if __name__ == "__main__":
    sys.exit(main())
