import pandas as pd
import pathlib

_P = pathlib.Path("artifacts/predictions/pilot")

for pdir in ["B5", "B5_ext"]:
    pf = _P / pdir / "predictions.parquet"
    if not pf.exists():
        print(f"{pdir}: NOT FOUND"); continue
    df = pd.read_parquet(pf)
    print(f"\n{'='*60}")
    print(f"{pdir}  n={len(df)}")
    print(f"{'='*60}")
    print("Columns:")
    for col in df.columns:
        s = df[col].iloc[0] if len(df) > 0 else "N/A"
        print(f"  {col:<30} {str(df[col].dtype):<12} sample={repr(str(s))[:55]}")

    if "pipeline_stages" in df.columns:
        print("\npipeline_stages sample values (first 5):")
        for v in df["pipeline_stages"].head(5):
            print(f"  {str(v)[:120]}")

    if "n_repair_attempts" in df.columns:
        print(f"\nn_repair_attempts dist:\n{df['n_repair_attempts'].value_counts().sort_index()}")
    if "tdd_n_tests" in df.columns:
        print(f"\ntdd_n_tests dist:\n{df['tdd_n_tests'].value_counts().sort_index()}")
    if "sandbox_ok" in df.columns:
        print(f"\nsandbox_ok: {df['sandbox_ok'].sum()}/{len(df)}")
    if "final_status" in df.columns:
        print(f"\nfinal_status:\n{df['final_status'].value_counts()}")
