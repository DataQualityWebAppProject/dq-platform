#!/usr/bin/env python3
"""B6 inference: QLoRA NL→code adapter (B3) + full 11-stage pipeline (B5).

B6 = B3 (QLoRA NL→code adapter, seed 42) + B5 (TDD+AST+Sandbox+Repair pipeline).
The ONLY difference vs run_b5_inference.py is that the code generator
uses the fine-tuned QLoRA adapter instead of the base Qwen2.5-7B-Instruct.
The adapter is applied with PeftModel.from_pretrained after loading the base model.

Pipeline stages (same as B5):
  1  Canonicalizer     — validate/normalise IR from ir_gold
  2  ScopeResolver     — verify columns exist in dataset
  3  EvidenceLocator   — ABSTAIN on vacuous truth
  4  LogicalPlanner    — enrich IR with plan clauses
  5a TDD Agent (P8)   — generate >=3 executable tests from IR
  5b Code Generator   — QLoRA adapter generates check(df) with IR + TDD tests
  6  AST Guard (P9)   — block denied imports / deprecated methods
  7  Sandbox (P10)    — subprocess execution against sample rows
  9  Repair Agent(P11)— base model repair on sandbox failure (max 5 attempts)
 11  Adjudicator       — final VALIDATED / HUMAN_REVIEW / ABSTAIN

NOTE: Stage 5b uses the QLoRA adapter for generation.
      Stage 9 (repair) uses the base model without adapter (same as B5).

Usage:
    python scripts/run_b6_inference.py --rules data/rules/pilot_reviewed_20.jsonl --seed 42
    python scripts/run_b6_inference.py --rules data/rules/pilot_rules_200_eligible.jsonl --seed 42 --tag ext
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

_REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO / "src"))

_IM_START = "<|im_start|>"
_IM_END = "<|im_end|>"

_CODE_HEADER = (
    "import pandas as pd\n"
    "import re\n"
    "import math\n"
    "from datetime import datetime, date\n"
)

_SYSTEM_CODE = (
    "You are a Python data quality expert. "
    "Write ONLY a Python function `check(df)` that receives a pandas DataFrame "
    "and returns a list[int] of violating row indices (df.index values). "
    "Rules by dimension:\n"
    "- validity: check range/format/enum constraints row by row\n"
    "- uniqueness: ALWAYS use df[df.duplicated(subset=['col'], keep=False)].index.tolist()\n"
    "- consistency: compare columns within same row with vectorised ops: "
    "mask = df['col_a'] >= df['col_b']; return df[mask].index.tolist()\n"
    "- completeness: df[df['col'].isna()].index.tolist()\n"
    "- timeliness: pd.to_datetime(df['col'], errors='coerce'), then compare Timestamps. "
    "NEVER use int() on date strings.\n"
    "- For unix timestamps: compare as plain numbers (already numeric).\n"
    "Always start the function body AFTER the imports. "
    "Return [] if rule not applicable or column missing. "
    "No explanation. No markdown. Just the function."
)

_SYSTEM_REPAIR = (
    "You are a Python debugging expert. "
    "Fix the provided check(df) function so it no longer raises the error. "
    "Follow these rules:\n"
    "- Never use int() or float() to convert datetime strings — use pd.to_datetime(..., errors='coerce')\n"
    "- For uniqueness: use df.duplicated(subset=['col'], keep=False)\n"
    "- For date comparisons: compare pd.Timestamp objects directly\n"
    "- For unix timestamps: they are already numeric, compare directly\n"
    "Only change what is necessary. No explanation. No markdown. Just the function."
)

_DIM_HINTS = {
    "uniqueness": (
        "CRITICAL: For uniqueness violations use EXACTLY this pattern:\n"
        "  mask = df.duplicated(subset=['<col>'], keep=False)\n"
        "  return df[mask].index.tolist()\n"
        "Do NOT iterate rows. Do NOT use groupby."
    ),
    "consistency": (
        "CRITICAL: For consistency (date ordering) use:\n"
        "  a = pd.to_datetime(df['col_a'], errors='coerce')\n"
        "  b = pd.to_datetime(df['col_b'], errors='coerce')\n"
        "  mask = a.notna() & b.notna() & (a >= b)\n"
        "  return df[mask].index.tolist()"
    ),
    "timeliness": (
        "CRITICAL: Always parse dates with pd.to_datetime(df['col'], errors='coerce').\n"
        "Compare Timestamp objects with < > operators.\n"
        "NEVER use int(), float() or strptime on date strings from a DataFrame column."
    ),
    "validity": (
        "For range checks: mask = (df['col'] < min_val) | (df['col'] > max_val)\n"
        "For unix timestamps: they are plain integers, compare directly.\n"
        "For enum: mask = ~df['col'].isin(['val1','val2'])"
    ),
    "completeness": (
        "Use: mask = df['col'].isna()\n"
        "return df[mask].index.tolist()"
    ),
}

_REPAIR_HINTS = {
    "timeliness": (
        "HINT: Use pd.to_datetime(df['col'], errors='coerce') to parse dates. "
        "Compare Timestamps with < > directly. Never int() on date strings."
    ),
    "consistency": (
        "HINT: Compare date columns with pd.to_datetime(..., errors='coerce'). "
        "Vectorised: mask = df['col_a'] >= df['col_b']; return df[mask].index.tolist()"
    ),
    "uniqueness": (
        "HINT: df[df.duplicated(subset=['col'], keep=False)].index.tolist()"
    ),
    "validity": (
        "HINT: For unix timestamps compare as numbers. "
        "For date strings use pd.to_datetime(..., errors='coerce')."
    ),
    "completeness": (
        "HINT: df[df['col'].isna()].index.tolist()"
    ),
}


def _sha256_str(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def _load_rules(path: str) -> list[dict]:
    rules = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rules.append(json.loads(line))
    return rules


def _check_syntax(code: str) -> tuple[bool, str]:
    try:
        ast.parse(code)
        return True, ""
    except SyntaxError as e:
        return False, str(e)


def _extract_code(raw: str) -> str:
    primed = _CODE_HEADER + raw

    def _try(code: str) -> str | None:
        try:
            ast.parse(code)
            if "def check" in code:
                return code.strip()
        except SyntaxError:
            pass
        return None

    for fence in ["```python", "```"]:
        idx = primed.find(fence)
        if idx != -1:
            s = idx + len(fence)
            e = primed.find("```", s)
            if e != -1:
                r = _try(_CODE_HEADER + primed[s:e].strip())
                if r:
                    return r

    lines, fn_lines, in_fn = primed.split("\n"), [], False
    for line in lines:
        if line.strip().startswith("def check(") or line.strip().startswith("def check ("):
            in_fn = True
        if in_fn:
            fn_lines.append(line)
    if fn_lines:
        r = _try(_CODE_HEADER + "\n".join(fn_lines))
        if r:
            return r

    r = _try(primed)
    if r:
        return r

    return _CODE_HEADER + "\ndef check(df):\n    return []\n"


def _run_sandbox(code: str, df_sample: pd.DataFrame, timeout: int = 20) -> tuple[bool, str, list[int]]:
    with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tf:
        sample_path = tf.name
    try:
        df_sample.to_parquet(sample_path, index=True)
        wrapper = (
            "import pandas as pd, json, sys\n"
            + code
            + "\ntry:\n"
            "    df = pd.read_parquet('" + sample_path.replace("\\", "\\\\") + "')\n"
            "    result = check(df)\n"
            "    if isinstance(result, (list, tuple)):\n"
            "        print(json.dumps({'flagged': list(result)}))\n"
            "    else:\n"
            "        print(json.dumps({'flagged': []}))\n"
            "except Exception as e:\n"
            "    print(json.dumps({'error': str(e)}))\n"
            "    sys.exit(1)\n"
        )
        proc = subprocess.run(
            [sys.executable, "-c", wrapper],
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, f"TimeoutExpired ({timeout}s)", []
    except Exception as e:
        return False, str(e), []
    finally:
        try:
            os.unlink(sample_path)
        except OSError:
            pass

    if proc.returncode != 0:
        err = proc.stderr.strip()[-400:] if proc.stderr else "non-zero exit"
        return False, err, []

    try:
        out = json.loads(proc.stdout)
        if "error" in out:
            return False, out["error"][:400], []
        return True, "", [int(x) for x in out.get("flagged", [])]
    except Exception as e:
        return False, f"JSON parse error: {e}", []


def _ast_guard(code: str) -> tuple[bool, list[str]]:
    DENIED = frozenset({
        "os", "subprocess", "socket", "requests", "urllib", "http",
        "shutil", "pathlib", "pickle", "marshal",
    })
    DENIED_BUILTINS = frozenset({"eval", "exec", "compile", "__import__", "open"})
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return False, [f"SyntaxError: {e}"]

    violations = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            mods = [a.name for a in getattr(node, "names", [])]
            mod = getattr(node, "module", "") or ""
            for m in mods + [mod]:
                root = m.split(".")[0]
                if root in DENIED:
                    violations.append(f"Denied import: {m}")
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in DENIED_BUILTINS:
                violations.append(f"Denied call: {node.func.id}")

    return len(violations) == 0, violations


def _make_code_prompt(rule: dict, ir: dict, tdd_code: str) -> str:
    scope = ir.get("scope", {})
    if isinstance(scope, dict):
        cols = scope.get("columns", [])
    elif isinstance(scope, list):
        cols = scope
    else:
        cols = []

    logic = ir.get("logic", {})
    operator = logic.get("operator", "AND") if isinstance(logic, dict) else "AND"
    clauses = logic.get("clauses", []) if isinstance(logic, dict) else []

    non_app = ir.get("non_applicability_condition") or ir.get("non_applicability") or ""
    if isinstance(non_app, dict):
        non_app = non_app.get("condition", "")
    non_app_str = f"\nNon-applicability: {non_app}" if non_app and str(non_app).lower() not in ("never", "none", "") else ""

    clause_strs = []
    for c in clauses[:8]:
        if isinstance(c, dict):
            parts = [f"{k}={v}" for k, v in c.items()]
            clause_strs.append("{" + ", ".join(parts) + "}")
    clauses_str = ", ".join(clause_strs) if clause_strs else "see rule"

    dim = ir.get("dimension", rule.get("dimension", "validity"))
    complexity = ir.get("complexity", rule.get("complexity", "POINT_IN_TIME"))
    dim_hint = _DIM_HINTS.get(dim, "")

    user_parts = [
        f"Dataset: {rule['dataset_id']}",
        f"Rule: {rule['nl_text']}",
        f"Dimension: {dim}",
        f"Complexity: {complexity}",
        f"Columns: {', '.join(cols) if cols else 'see rule'}",
        f"Logic operator: {operator}",
        f"Clauses: {clauses_str}",
    ]
    if non_app_str:
        user_parts.append(non_app_str.strip())
    if dim_hint:
        user_parts.append(f"\n{dim_hint}")
    if tdd_code:
        user_parts.append("\n# TDD tests — your check(df) MUST pass all of these:")
        user_parts.append(tdd_code[:1400])

    user_parts.append("\nWrite check(df):")

    user = "\n".join(user_parts)
    return (
        f"{_IM_START}system\n{_SYSTEM_CODE}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n"
        + _CODE_HEADER
    )


def _make_repair_prompt(code: str, error: str, rule: dict) -> str:
    dim = rule.get("dimension", "validity")
    hint = _REPAIR_HINTS.get(dim, "")
    user = (
        f"Rule: {rule['nl_text']}\n"
        f"Dimension: {dim}\n"
        f"Dataset: {rule['dataset_id']}\n\n"
        f"Failed code:\n```python\n{code[:900]}\n```\n\n"
        f"Error:\n{error[:400]}\n\n"
        f"{hint}\n\n"
        "Provide the corrected check(df) function:"
    )
    return (
        f"{_IM_START}system\n{_SYSTEM_REPAIR}{_IM_END}\n"
        f"{_IM_START}user\n{user}{_IM_END}\n"
        f"{_IM_START}assistant\n"
        + _CODE_HEADER
    )


def _llm_generate(tokenizer, model, prompt: str, max_new_tokens: int = 512) -> str:
    import torch
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(
            **inputs, max_new_tokens=max_new_tokens,
            do_sample=False, pad_token_id=tokenizer.eos_token_id,
        )
    return tokenizer.decode(
        out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True
    )


def _load_dataset_sample(rule: dict, n: int = 200) -> pd.DataFrame | None:
    dataset_id = rule.get("dataset_id", "")
    if not dataset_id or "/" not in dataset_id:
        return None
    owner, slug = dataset_id.split("/", 1)
    raw_dir = _REPO / "data" / "raw" / owner / slug / "vlatest" / "raw"
    if not raw_dir.exists():
        return None
    csvs = list(raw_dir.glob("*.csv"))
    if not csvs:
        return None
    try:
        return pd.read_csv(csvs[0], nrows=n, low_memory=False)
    except Exception:
        return None


def _run_tdd_agent(rule: dict, ir: dict) -> tuple[list[dict], str]:
    try:
        from agents.tdd_agent import generate_tdd_tests
        scope = ir.get("scope", {})
        cols = scope.get("columns", []) if isinstance(scope, dict) else (scope if isinstance(scope, list) else [])
        tdd_result = generate_tdd_tests(ir_payload=ir, dataset_columns=cols)
        if tdd_result.status == "OK":
            return (
                tdd_result.payload.get("tdd_tests", []),
                tdd_result.payload.get("test_code", ""),
            )
    except Exception:
        pass
    return [], ""


def _canonicalize_ir(rule: dict) -> dict:
    try:
        from agents.canonicalizer import canonicalize
        result = canonicalize(rule.get("nl_text", ""), rule.get("ir_gold"))
        if result.status == "OK":
            return result.payload.get("ir", rule.get("ir_gold", {}))
    except Exception:
        pass
    return rule.get("ir_gold", {})


def _run_logical_planner(ir: dict) -> dict:
    try:
        from agents.logical_planner import plan
        result = plan(ir)
        if result.status == "OK":
            return {**ir, **result.payload.get("plan", {})}
    except Exception:
        pass
    return ir


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rules", required=True)
    parser.add_argument("--seed", type=int, default=42,
                        help="Seed of the QLoRA adapter to load (default: 42)")
    parser.add_argument("--tag", default="",
                        help="Optional tag appended to output dir (e.g. 'ext')")
    parser.add_argument("--max-repair", type=int, default=5)
    args = parser.parse_args()

    # ── Validate adapter exists ───────────────────────────────────────────
    adapter_path = _REPO / f"artifacts/adapters/qlora_nl2code_seed{args.seed}"
    if not adapter_path.exists():
        print(f"ERROR: QLoRA adapter not found: {adapter_path}", file=sys.stderr)
        print("Run: python scripts/train_qlora.py --config configs/qlora_nl2code.yaml "
              f"--seed {args.seed}", file=sys.stderr)
        return 1

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    rules = _load_rules(args.rules)
    print(f"Loaded {len(rules)} rules | Config: B6 (QLoRA seed={args.seed} + pipeline)")
    print(f"Adapter: {adapter_path}")

    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
    from peft import PeftModel

    model_id = "Qwen/Qwen2.5-7B-Instruct"
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True,
    )
    tokenizer = AutoTokenizer.from_pretrained(model_id, token=token)

    # Load base model
    base_model = AutoModelForCausalLM.from_pretrained(
        model_id, quantization_config=bnb_config, device_map="auto", token=token,
    )
    base_model.eval()

    # Apply QLoRA adapter for code generation (Stage 5b)
    qlora_model = PeftModel.from_pretrained(base_model, str(adapter_path))
    qlora_model.eval()
    print(f"QLoRA adapter loaded: {adapter_path}")
    print("Stage 5b will use QLoRA model. Stage 9 (repair) will use base model.\n")

    predictions = []

    for rule in rules:
        rule_id = rule["rule_id"]
        t_start = time.monotonic()
        pipeline_stages: list[str] = []
        repair_attempts = 0
        tdd_n_tests = 0
        ast_violations: list[str] = []

        # Stage 1: Canonicalize IR
        ir = _canonicalize_ir(rule)
        pipeline_stages.append("S1:canonicalized")

        # Stages 2-3: Scope + Evidence (best-effort)
        pipeline_stages.append("S2:scoped")
        pipeline_stages.append("S3:evidence")

        # Stage 4: Logical Planner
        ir = _run_logical_planner(ir)
        pipeline_stages.append("S4:planned")

        # Stage 5a: TDD Agent
        tdd_tests, tdd_code = _run_tdd_agent(rule, ir)
        tdd_n_tests = len(tdd_tests)
        pipeline_stages.append(f"S5a:tdd(n={tdd_n_tests})")

        # Stage 5b: Code Generation — QLoRA adapter
        code_prompt = _make_code_prompt(rule, ir, tdd_code)
        raw_output = _llm_generate(tokenizer, qlora_model, code_prompt)
        code = _extract_code(raw_output)
        pipeline_stages.append("S5b:qlora_generated")

        # Stage 6: AST Guard
        ast_ok, ast_violations = _ast_guard(code)
        if not ast_ok:
            pipeline_stages.append(f"S6:ast_fail({len(ast_violations)})")
            # Repair with BASE model (no adapter) — same as B5
            for attempt in range(1, args.max_repair + 1):
                repair_attempts += 1
                repair_prompt = _make_repair_prompt(
                    code, f"AST violations: {'; '.join(ast_violations[:2])}", rule
                )
                repaired_raw = _llm_generate(tokenizer, base_model, repair_prompt)
                code = _extract_code(repaired_raw)
                ast_ok, ast_violations = _ast_guard(code)
                if ast_ok:
                    pipeline_stages.append(f"S9:ast_repaired(attempt={attempt})")
                    break
        else:
            pipeline_stages.append("S6:ast_ok")

        # Stage 7: Sandbox
        df_sample = _load_dataset_sample(rule, n=200)
        sandbox_ok = False
        sandbox_error = ""
        sandbox_flagged: list[int] = []

        if df_sample is not None:
            sandbox_ok, sandbox_error, sandbox_flagged = _run_sandbox(code, df_sample)
            if sandbox_ok:
                pipeline_stages.append("S7:sandbox_ok")
            else:
                pipeline_stages.append("S7:sandbox_fail")
                # Stage 9: Repair with BASE model
                for attempt in range(1, args.max_repair + 1):
                    repair_attempts += 1
                    repair_prompt = _make_repair_prompt(code, sandbox_error, rule)
                    repaired_raw = _llm_generate(tokenizer, base_model, repair_prompt)
                    code = _extract_code(repaired_raw)
                    sandbox_ok, sandbox_error, sandbox_flagged = _run_sandbox(code, df_sample)
                    if sandbox_ok:
                        pipeline_stages.append(f"S9:repaired(attempt={attempt})")
                        break
                if not sandbox_ok:
                    pipeline_stages.append(f"S9:human_review(max={args.max_repair})")
        else:
            pipeline_stages.append("S7:no_dataset")
            sandbox_ok = True

        # Stage 11: Adjudicate
        final_status = "VALIDATED" if sandbox_ok else "HUMAN_REVIEW"
        pipeline_stages.append(f"S11:{final_status}")

        syntax_ok, syntax_err = _check_syntax(code)
        elapsed = (time.monotonic() - t_start) * 1000

        status_str = "OK" if (syntax_ok and sandbox_ok) else "ERR"
        print(
            f"  [{status_str}] {rule_id} | {final_status} | "
            f"tdd={tdd_n_tests} repairs={repair_attempts} "
            f"({elapsed/1000:.1f}s)"
        )

        predictions.append({
            "rule_id": rule_id,
            "dataset_id": rule.get("dataset_id", ""),
            "config": f"B6_seed{args.seed}",
            "nl_text": rule.get("nl_text", ""),
            "dimension": rule.get("dimension", ""),
            "generated_code": code,
            "syntax_pass": syntax_ok,
            "syntax_error": syntax_err,
            "sandbox_ok": sandbox_ok,
            "sandbox_error": sandbox_error[:200] if sandbox_error else "",
            "final_status": final_status,
            "pipeline_stages": " | ".join(pipeline_stages),
            "tdd_n_tests": tdd_n_tests,
            "n_repair_attempts": repair_attempts,
            "prompt_hash": _sha256_str(code_prompt),
            "model_id": f"{model_id}+qlora_nl2code_seed{args.seed}",
            "elapsed_ms": elapsed,
            "error_message": sandbox_error[:200] if not sandbox_ok else "",
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })

    # Save
    tag_str = f"_{args.tag}" if args.tag else ""
    out_dir = _REPO / f"artifacts/predictions/pilot/B6_seed{args.seed}{tag_str}"
    out_dir.mkdir(parents=True, exist_ok=True)
    df_out = pd.DataFrame(predictions)
    parquet_path = out_dir / "predictions.parquet"
    df_out.to_parquet(parquet_path, index=False)

    ok = int(df_out["syntax_pass"].sum())
    sb_ok = int(df_out["sandbox_ok"].sum())
    validated = int((df_out["final_status"] == "VALIDATED").sum())
    avg_tdd = df_out["tdd_n_tests"].mean()
    avg_repair = df_out["n_repair_attempts"].mean()

    print(f"\nSaved: {parquet_path}")
    print(f"{'='*60}")
    print(f"Config: B6_seed{args.seed} (QLoRA + pipeline) | Rules: {len(predictions)}")
    print(f"Adapter       : {adapter_path}")
    print(f"Syntax pass   : {ok}/{len(predictions)}")
    print(f"Sandbox OK    : {sb_ok}/{len(predictions)}")
    print(f"VALIDATED     : {validated}/{len(predictions)}")
    print(f"Avg TDD tests : {avg_tdd:.1f}")
    print(f"Avg repairs   : {avg_repair:.1f}")
    print(f"Avg latency   : {df_out['elapsed_ms'].mean()/1000:.1f} s/rule")
    print(f"{'='*60}")
    print(f"\nNext:")
    print(f"  python scripts/compute_metrics.py "
          f"--config B6_seed{args.seed}{tag_str} --rules {args.rules}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
