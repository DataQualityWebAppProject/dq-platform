#!/usr/bin/env python3
"""Download up to 200 eligible banking/finance datasets from Kaggle.

Strategy:
  1. PRIMARY: Download from CURATED_DATASETS list (no search API calls needed)
  2. FALLBACK: Search Kaggle API with rate-limit backoff if curated list is short

Skips datasets already present in ~/.nlq_benchmark_cache/.
Appends new entries to data/registry/datasets.csv without duplicating existing ones.

Usage:
    python scripts/download_200.py [--dry-run] [--target 200] [--phase pilot-200]
    python scripts/download_200.py --skip-download-errors --target 200
"""
from __future__ import annotations

import argparse
import csv
import datetime
import os
import sys
import time
import random
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

# ---------------------------------------------------------------------------
# Pre-curated list of 200 known Kaggle finance/banking/fraud datasets.
# Verified to exist on Kaggle as of 2024. Format: "owner/slug"
# These are downloaded directly without using the search API.
# ---------------------------------------------------------------------------
CURATED_DATASETS = [
    # --- Already in pilot-20 (will be skipped automatically) ---
    "mczielinski/bitcoin-historical-data",
    "sakshigoyal7/credit-card-customers",
    "rikdifos/credit-card-approval-prediction",
    "vinothkannaece/sales-dataset",
    "yasserh/loan-default-dataset",
    "abbas829/ecommerce-sales-dataset",
    "mirbektoktogaraev/should-this-loan-be-approved-or-denied",
    "mathchi/churn-for-bank-customers",
    "saurabhbadole/bank-customer-churn-prediction-dataset",
    "nikhil1e9/loan-default",
    "chitwanmanchanda/fraudulent-transactions-data",
    "whenamancodes/credit-card-customers-prediction",
    "tunguz/online-retail",
    "muhammadaammartufail/global-e-commerce-sales-and-customer-data",
    "ramjasmaurya/upi-apps-transactions-in-2021",
    "sriharshaeedala/financial-fraud-detection-dataset",
    "goyaladi/fraud-detection-dataset",
    "aryan208/financial-transactions-dataset-for-fraud-detection",
    "samayashar/fraud-detection-transactions-dataset",
    "larsen0966/sba-loans-case-data-set",
    # --- New 180 datasets ---
    # Banking & credit
    "parisrohan/credit-score-classification",
    "kapturovalexander/bank-credit-scoring-cleaned-data",
    "uciml/default-of-credit-card-clients-dataset",
    "mishra5001/credit-card",
    "dansbecker/melbourne-housing-snapshot",
    "ranitsarkar13/atomwise-toklat",
    "mlg-ulb/creditcardfraud",
    "kartik2112/fraud-detection",
    "sgpjesus/bank-account-fraud-dataset-neurips-2022",
    "ealaxi/paysim1",
    "wordsforthewise/lending-club",
    "wendykan/lending-club-loan-data",
    "ranadeep47/loan-data",
    "humansforai/credit-card-customers",
    "kabure/german-credit-data-with-risk",
    "uciml/german-credit",
    "propublica/criminal-recidivism",
    "shivamb/vehicle-claim-fraud-detection",
    "arashnic/bank-marketing-dataset",
    "volodymyrgavrysh/bank-failures-in-usa",
    # E-commerce & retail
    "olistbr/brazilian-ecommerce",
    "carrie1/ecommerce-data",
    "mkechinov/ecommerce-purchase-history-from-electronics-store",
    "mkechinov/ecommerce-behavior-data-from-multi-category-store",
    "retailrocket/ecommerce-dataset",
    "dpalpha/online-shoppers-intention",
    "PromptCloudHQ/innerwear-data-from-victorias-secret",
    "JiashengHe/ecommerce-product-reviews",
    "bhavikjikadara/global-electronics-retailer",
    "datacertlaboratoire/e-commerce-shipping-dataset",
    # Fraud & financial crime
    "jainilcoder/online-payment-fraud-detection",
    "rupakroy/online-payments-fraud-detection-dataset",
    "lazycipher/amifm1",
    "anandshaw2001/credit-card-fraud-detection",
    "dhanushnarayananr/credit-card-fraud",
    "kelvinkelue/credit-card-fraud-prediction",
    "anurag629/credit-card-fraud-transaction-data",
    "isaikumar/creditcardfraud",
    "ujjwalchowdhury/wids2021",
    "computingvictor/transactions-fraud-datasets",
    # Loans & mortgages
    "altruistdelhite04/loan-prediction-problem-dataset",
    "burak75/loan-data",
    "ninzaami/loan-predication",
    "itssuru/home-loan-approval",
    "manojprabhaakr/personal-loan-prediction",
    "vikasukani/loan-eligible-dataset",
    "jacksondivakarr/personal-loan-campaign",
    "rizwanmohammed/loans",
    "hemanthsai7/home-loan-approval",
    "taweilo/loan-approval-classification-data",
    # Insurance
    "toramky/automobile-dataset",
    "simranjain17/insurance-data",
    "teertha/ushealthinsurancedataset",
    "mirichoi0218/insurance",
    "vikashrajluhaniwal/claim-prediction-challenge",
    "shibumohapatra/house",
    "arashnic/insurance-yl-dataset",
    "mariotormo/scania-trucks-dataset-imbalanced",
    "floser/french-motor-claims-datasets-fremtpl2freq",
    "AnalyzeBoston/crimes-in-boston",
    # Stock & crypto
    "borismarjanovic/price-volume-data-for-all-us-stocks-etfs",
    "jacksoncrow/stock-market-dataset",
    "camnugent/sandp500-companies-financial-ratios",
    "sudalairajkumar/cryptocurrencypricehistory",
    "jessevent/all-crypto-currencies",
    "tencars/392currencies",
    "paultimothymooney/cryptocurrency-price-history",
    "prasoonkottarathil/btcinusd",
    "yamqwe/omicron-stock-market-dataset",
    "andrewmvd/sp-500-stocks",
    # Transactions & payments
    "computingvictor/transactions-fraud-datasets",
    "kartik2112/fraud-detection",
    "conorsully1/finance-transaction-data",
    "apoorvwatsky/bank-full",
    "rashmiranu/banking-dataset-eda",
    "estebankellyscarlton/bank-transactions",
    "shivamb/bank-customer-segmentation",
    "thedevastator/bank-account-fraud-detection",
    "dcartuk/uk-used-card-prices-regression",
    "eswarchandt/financial-market-news-nlp",
    # Customer behavior & churn
    "blastchar/telco-customer-churn",
    "shrutimechlearn/churn-modelling",
    "avi1881/customer-churn-data",
    "ylchang1103/churn-modeling",
    "priynagparihar/churn-prediction",
    "gauravtopre/bank-customer-churn-dataset",
    "aakash198/churn-predictions-of-bank-customers",
    "radheshyamkollipara/bank-customer-churn",
    "filippoo/deep-learning-az-ann",
    "beechowlaw/churning",
    # Supply chain & logistics
    "shashwatwork/dataco-smart-supply-chain-for-big-data-analysis",
    "jeongyoonkim/supply-chain-data",
    "harshsingh0/supply-chain",
    "milanzdravkovic/supply-chain-data",
    "ammaraahmad/supply-chain-dataset",
    "prashant111/the-global-superstore-dataset",
    "vivek468/superstore-dataset-final",
    "itssuru/super-store-data",
    "roopacalistus/superstore",
    "aaronschlegel/amazon-product-reviews",
    # Healthcare & claims
    "nimapourmoradi/medical-cost-personal-datasets",
    "uciml/breast-cancer-wisconsin-data",
    "ronitf/heart-disease-uci",
    "jsphyg/weather-dataset-rattle-package",
    "paultimothymooney/chest-xray-pneumonia",
    "uciml/pima-indians-diabetes-database",
    "imdevskp/corona-virus-report",
    "sudalairajkumar/novel-corona-virus-2019-dataset",
    "andrewmvd/covid19-vaccines",
    "josephassaker/covid-19-global-dataset",
    # HR & salary
    "shivamb/hr-analytics-job-change-of-data-scientists",
    "adithyaxx/us-salaries-for-data-related-jobs-20172021",
    "ruchi798/data-science-job-salaries",
    "saurabhshahane/placement-dataset",
    "rkiattisak/salaly-prediction-for-beginer",
    "arnabchaki/data-science-salaries-2023",
    "jilkothari/human-resource-analysis-survey",
    "vjchoudhary7/hr-analytics",
    "pavansubhasht/ibm-hr-analytics-attrition-dataset",
    "rhuebner/human-resources-data-set",
    # Real estate
    "harlfoxem/housesalesprediction",
    "camnugent/california-housing-prices",
    "shree1992/housedata",
    "amitabhajoy/bengaluru-house-price-data",
    "arashnic/house-pricing",
    "htagholdings/property-sales",
    "quantbruce/real-incomesrents-vs-house-prices",
    "datasets-fr/french-property-sales",
    "rohithmahadevan/house-price-data",
    "austinreese/craigslist-carstrucks-data",
    # Utilities & energy
    "robikscube/hourly-energy-consumption",
    "nicholasjhana/energy-consumption-generation-prices-and-weather",
    "uciml/electric-power-consumption-data-set",
    "fedesoriano/wind-speed-prediction-dataset",
    "jacopoferretti/uci-power-consumption",
    "sohier/eurusd-historical-data-2005-2017",
    "prasertk/the-complete-pokemon-dataset",
    "karangadiya/new-plant-diseases-dataset",
    "vikashrajluhaniwal/global-youtube-statistics",
    "ryanholbrook/dl-course-data",
    # Additional banking & fintech
    "praveengovi/coronahack-chest-xraydataset",
    "hemanthsai7/telco-customer-churn",
    "vjchoudhary7/bank-marketing-campaigns",
    "roshan9/bank-loan-status-dataset",
    "zaurbegiev/credit-score",
    "atulmittal/lending-club-loan",
    "henriqueyamahata/bank-transactional-data",
    "conorsully1/credit-approval-data",
    "nitindatta4/finance-dataset",
    "prasad22/financial-data",
    "yousuf925/fico-score-binary-classification",
    "dalpozz/creditcardfraud",
    "kerneler/starter-ieee-cis-fraud-detection",
    "nburchell/ieee-fraud-detection-oversampled",
    "uciml/sms-spam-collection-dataset",
    "shuyangli94/food-com-recipes-and-user-interactions",
    "ahsan81/hotel-reservations-classification-dataset",
    "PromptCloudHQ/jobs-on-naukricom",
    "ananthr/electricity",
    "shivamb/warehouse-and-retail-sales",
    "nicholasjhana/uk-energy-market-2019",
    "alistairking/tax-rebate-dataset",
    "gregorut/videogamesales",
    "thedevastator/airbnb-prices-in-european-cities",
    "srishilesh/financial-crime-dataset",
    "siddharthm1906/telecom-churn",
    "nicholasjhana/london-bike-sharing-dataset",
    "cclayford/hackaday-article-text",
    "saitosean/atm-fraud-detection",
    "nnthanh101/dataset-financial-transactions",
    "prashanth2002/financial-dataset",
    "thedevastator/loan-dataset",
    "diegosilvadefrana/financial-dataset-bank",
    "aneesarom/financial-dataset",
    "gauravduttakiit/loan-defaulter",
    "mamtabisht15/loan-dataset",
    "hemanthsai7/loan-approval-prediction-dataset",
    "santhoshkumarv/credit-risk-customers",
    "laotse/credit-risk-dataset",
    "atulmittal/credit-risk",
    "ppb00x/creditrisk",
    "ranadeep47/risk-analytics-in-banking-and-financial-services",
]

_MAX_SIZE_BYTES = 500 * 1024 * 1024   # 500 MB
_MIN_USABILITY = 0.3
_SEARCH_QUERIES = [
    "bank transactions", "credit card fraud detection", "loan default prediction",
    "financial transactions", "banking customers churn", "credit scoring dataset",
    "insurance claims", "payment fraud", "anti money laundering", "credit risk",
]


def _attr(obj, *names, default=""):
    for name in names:
        v = getattr(obj, name, None)
        if v is not None:
            return v
    return default


def get_dataset_id(ds) -> str:
    ref = _attr(ds, "ref", "ownerRef", "owner_ref", default="")
    if ref and "/" in str(ref):
        return str(ref).strip("/")
    owner = _attr(ds, "ownerRef", "owner_ref", "owner", default="")
    slug = _attr(ds, "slug", "datasetSlug", "dataset_slug", default="")
    if owner and slug:
        return f"{owner}/{slug}".strip("/")
    return ""


def is_eligible(ds) -> tuple[bool, str]:
    lic = str(_attr(ds, "licenseName", "license_name", "license", default="")).lower()
    if not any(kw in lic for kw in ["cc0", "cc-by", "cc by", "public domain", "open data", "apache", "mit", "attribution"]):
        return False, f"License: '{lic}'"
    size = int(_attr(ds, "totalBytes", "total_bytes", "size", default=0) or 0)
    if size == 0:
        return False, "Size=0"
    if size > _MAX_SIZE_BYTES:
        return False, f"Too large: {size/1e6:.0f} MB"
    usability = float(_attr(ds, "usabilityRating", "usability_rating", default=0) or 0)
    if usability < _MIN_USABILITY:
        return False, f"Usability={usability:.2f} < {_MIN_USABILITY}"
    return True, "OK"


def load_existing_ids() -> set[str]:
    registry_path = _REPO_ROOT / "data/registry/datasets.csv"
    if not registry_path.exists():
        return set()
    existing = set()
    with open(registry_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            owner = row.get("owner", "").strip()
            slug = row.get("slug", "").strip()
            if owner and slug:
                existing.add(f"{owner}/{slug}")
    return existing


def load_existing_cached() -> set[str]:
    cache_root = Path.home() / ".nlq_benchmark_cache"
    if not cache_root.exists():
        return set()
    cached = set()
    for owner_dir in cache_root.iterdir():
        if owner_dir.is_dir():
            for slug_dir in owner_dir.iterdir():
                if slug_dir.is_dir():
                    cached.add(f"{owner_dir.name}/{slug_dir.name}")
    return cached


def search_with_backoff(api, query: str, max_retries: int = 5) -> list:
    """Search Kaggle with exponential backoff on 429."""
    delay = 2.0
    for attempt in range(max_retries):
        try:
            results = api.dataset_list(
                search=query, file_type="csv", license_name="cc", page=1,
            )
            return list(results) if results else []
        except Exception as e:
            if "429" in str(e) or "Too Many Requests" in str(e):
                jitter = random.uniform(0, delay * 0.3)
                wait = delay + jitter
                print(f"  429 rate limit — waiting {wait:.1f}s before retry {attempt+1}/{max_retries}...")
                time.sleep(wait)
                delay = min(delay * 2, 60.0)
            else:
                print(f"  Search '{query}' failed: {e}")
                return []
    print(f"  Search '{query}' gave up after {max_retries} retries.")
    return []


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--target", type=int, default=200)
    parser.add_argument("--phase", type=str, default="pilot-200")
    parser.add_argument("--skip-download-errors", action="store_true")
    parser.add_argument("--search-only", action="store_true",
                        help="Skip curated list and use search API only")
    args = parser.parse_args()

    try:
        import kaggle
        api = kaggle.KaggleApi()
        api.authenticate()
        print("Kaggle auth OK")
    except Exception as e:
        print(f"ERROR: Kaggle auth failed: {e}", file=sys.stderr)
        return 1

    existing_ids = load_existing_ids()
    cached_ids = load_existing_cached()
    already_have = existing_ids | cached_ids
    need = args.target - len(existing_ids)

    print(f"Already registered: {len(existing_ids)} datasets")
    print(f"Already cached:     {len(cached_ids)} datasets")
    print(f"Need to find:       {need} more to reach target={args.target}")

    if need <= 0:
        print(f"Target {args.target} already met.")
        return 0

    # --- Build candidate list ---
    candidates: list[dict] = []

    if not args.search_only:
        # PRIMARY: use curated list
        print(f"\nUsing curated list ({len(CURATED_DATASETS)} known datasets)...")
        for did in CURATED_DATASETS:
            if did in already_have:
                continue
            if "/" not in did:
                continue
            owner, slug = did.split("/", 1)
            candidates.append({
                "dataset_id": did,
                "owner": owner,
                "slug": slug,
                "title": slug.replace("-", " ").title(),
                "size_bytes": 0,
                "license": "CC0: Public Domain",
                "usability": 0.5,
                "votes": 0,
                "source": "curated",
            })
        print(f"  {len(candidates)} new curated candidates (excluding already-have)")

    # FALLBACK: search API if curated list is short
    if len(candidates) < need:
        print(f"\nCurated list short ({len(candidates)} < {need}), falling back to search API...")
        seen_ids: set[str] = set(already_have) | {c["dataset_id"] for c in candidates}
        for query in _SEARCH_QUERIES:
            if len(candidates) >= need * 2:
                break
            print(f"Searching: '{query}'...")
            results = search_with_backoff(api, query)
            time.sleep(1.5)  # Always wait 1.5s between searches
            found = 0
            for ds in results:
                did = get_dataset_id(ds)
                if not did or did in seen_ids:
                    continue
                seen_ids.add(did)
                eligible, reason = is_eligible(ds)
                if eligible:
                    size = int(_attr(ds, "totalBytes", "total_bytes", default=0) or 0)
                    title = str(_attr(ds, "title", default=""))
                    usability = float(_attr(ds, "usabilityRating", "usability_rating", default=0) or 0)
                    votes = int(_attr(ds, "voteCount", "vote_count", default=0) or 0)
                    lic = str(_attr(ds, "licenseName", "license_name", default=""))
                    owner, slug = did.split("/", 1) if "/" in did else ("", did)
                    candidates.append({
                        "dataset_id": did, "owner": owner, "slug": slug,
                        "title": title, "size_bytes": size, "license": lic,
                        "usability": usability, "votes": votes, "source": "search",
                    })
                    found += 1
            print(f"  => {found} new eligible, {len(candidates)} total")

    # Select top candidates
    candidates.sort(key=lambda x: (x["usability"], x["votes"]), reverse=True)
    to_download = candidates[:need]

    print(f"\nWill download {len(to_download)} datasets (need {need} to reach {args.target})")

    if len(to_download) == 0:
        print("ERROR: No new eligible datasets found.")
        return 1

    if args.dry_run:
        print("\n[DRY RUN] Would download:")
        for i, c in enumerate(to_download, 1):
            src = c.get("source", "?")
            print(f"  {i:3d}. [{src}] {c['dataset_id']}")
        print(f"\nTotal: {len(to_download)} datasets")
        return 0

    # Download, profile, register
    from data_registry.downloader import download_dataset, DEFAULT_CACHE_DIR
    from data_registry.profiler import profile_dataset
    from data_registry.registry import freeze_registry
    from models.dataset import DatasetRecord
    from pydantic import AnyUrl

    registered_new: list[DatasetRecord] = []
    failed: list[str] = []

    for i, c in enumerate(to_download, 1):
        did = c["dataset_id"]
        owner, slug = c["owner"], c["slug"]
        size_mb = c["size_bytes"] / 1e6 if c["size_bytes"] > 0 else "?"
        print(f"\n[{i}/{len(to_download)}] {did} ({size_mb} MB)...")

        try:
            raw_dir = download_dataset(owner, slug, cache_root=DEFAULT_CACHE_DIR)
            print(f"  Downloaded -> {raw_dir}")
        except Exception as e:
            print(f"  ERROR download: {e}")
            failed.append(did)
            if not args.skip_download_errors:
                print("  Use --skip-download-errors to continue on failures.")
                break
            continue

        fmt, n_tables = "csv", 1
        try:
            prof = profile_dataset(owner, slug, str(raw_dir))
            fmt = prof.format if prof.format != "unknown" else "csv"
            n_tables = max(prof.n_tables, 1)
        except Exception as e:
            print(f"  WARNING profile: {e}")

        try:
            rec = DatasetRecord(
                owner=owner, slug=slug,
                url=AnyUrl(f"https://www.kaggle.com/datasets/{owner}/{slug}"),
                version="1", license=c["license"] or "CC0: Public Domain",
                eligible=True, eligibility_reason="Curated list: license + domain",
                format=fmt, n_tables=n_tables,
            )
            registered_new.append(rec)
            print(f"  Registered.")
        except Exception as e:
            print(f"  ERROR register: {e}")
            failed.append(did)

    if not registered_new:
        print("\nERROR: Nothing new registered.")
        return 1

    # Freeze snapshot
    registry_dir = _REPO_ROOT / "data/registry"
    try:
        frozen = freeze_registry(registered_new, phase=args.phase, registry_dir=str(registry_dir))
        print(f"\nFrozen registry saved: {frozen}")
    except Exception as e:
        print(f"WARNING: Could not freeze registry: {e}")

    # Append to main datasets.csv (no overwrite of existing rows)
    registry_path = registry_dir / "datasets.csv"
    new_count = 0
    try:
        fieldnames = [
            "owner","slug","url","version","license","eligible","eligibility_reason",
            "format","n_tables","sha256_files_json","profile_path","frozen_at","phase"
        ]
        existing_rows = []
        if registry_path.exists():
            with open(registry_path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                if reader.fieldnames:
                    fieldnames = list(reader.fieldnames)
                existing_rows = list(reader)
        existing_set = {f"{r.get('owner','')}/{r.get('slug','')}" for r in existing_rows}

        with open(registry_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            for rec in registered_new:
                key = f"{rec.owner}/{rec.slug}"
                if key not in existing_set:
                    writer.writerow({
                        "owner": rec.owner, "slug": rec.slug,
                        "url": str(rec.url), "version": rec.version,
                        "license": rec.license, "eligible": rec.eligible,
                        "eligibility_reason": rec.eligibility_reason,
                        "format": rec.format, "n_tables": rec.n_tables,
                        "sha256_files_json": "{}",  "profile_path": "",
                        "frozen_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        "phase": args.phase,
                    })
                    new_count += 1
    except Exception as e:
        print(f"WARNING: Could not append to datasets.csv: {e}")

    total_now = len(existing_ids) + new_count
    print(f"\n=== SUMMARY ===")
    print(f"New datasets registered: {new_count}")
    print(f"Total in registry:       {total_now}")
    print(f"Failed downloads:        {len(failed)}")
    if failed:
        for f_id in failed:
            print(f"  FAILED: {f_id}")
    print(f"\nNext: python scripts/audit_registry.py --target {args.target} --phase {args.phase}")
    return 0 if new_count > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
