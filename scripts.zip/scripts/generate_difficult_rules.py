#!/usr/bin/env python3
"""Generate medium and difficult rules using real column names from data/raw/.

Reads schema from each dataset and generates:
  - MEDIUM: IF-THEN cross-column, IFF, ratio constraints (complexity=POINT_IN_TIME)
  - HARD: temporal windows, groupby aggregates, vacuous truth (complexity=HISTORICAL)

These supplement the 20 easy REVIEWED rules to reach the 20%/40%/40% distribution.

Usage:
    python scripts/generate_difficult_rules.py --level medium --target 80
    python scripts/generate_difficult_rules.py --level hard --target 80
    python scripts/generate_difficult_rules.py --all --target 160
"""
from __future__ import annotations

import argparse
import csv
import json
import pathlib
import random
import sys
from datetime import datetime, timezone

_REPO = pathlib.Path(__file__).resolve().parent.parent
RAW_DIR = _REPO / "data" / "raw"
RULES_DIR = _REPO / "data" / "rules"

# Start from R-0121 (R-0101..R-0120 are the reviewed pilot-20)
START_ID = 121


def get_dataset_schema(owner: str, slug: str) -> dict:
    """Read column names and types from the dataset's primary CSV."""
    base = RAW_DIR / owner / slug
    for search_root in [base / "vlatest" / "raw", base]:
        if not search_root.exists():
            continue
        csvs = sorted(search_root.rglob("*.csv"))
        csvs = [c for c in csvs if c.stat().st_size > 10_000]
        if not csvs:
            continue
        csv_path = max(csvs, key=lambda p: p.stat().st_size)
        try:
            import pandas as pd
            df = pd.read_csv(csv_path, nrows=100, low_memory=False)
            schema = {}
            for col in df.columns:
                dtype = str(df[col].dtype)
                if "int" in dtype or "float" in dtype:
                    schema[col] = "numeric"
                elif "datetime" in dtype or "date" in dtype:
                    schema[col] = "datetime"
                else:
                    sample_vals = df[col].dropna().unique()[:5].tolist()
                    schema[col] = {"type": "categorical", "values": [str(v) for v in sample_vals]}
            return {"owner": owner, "slug": slug, "columns": schema, "n_rows": len(df)}
        except Exception:
            continue
    return {}


def generate_medium_rule(rule_id: str, schema: dict, rng: random.Random) -> dict | None:
    """Generate a medium-difficulty POINT_IN_TIME rule with cross-column logic."""
    cols = schema.get("columns", {})
    if not cols:
        return None

    numeric_cols = [c for c, t in cols.items() if t == "numeric"]
    cat_cols = [c for c, t in cols.items() if isinstance(t, dict) and t.get("type") == "categorical"]
    dataset_id = f"{schema['owner']}/{schema['slug']}"

    # Pattern A: IF numeric col > 0 THEN another numeric col must not be null
    if len(numeric_cols) >= 2:
        col_a, col_b = rng.sample(numeric_cols[:6], 2)
        threshold = rng.choice([0, 100, 1000])
        return {
            "rule_id": rule_id,
            "dataset_id": dataset_id,
            "nl_text": f"Si el campo {col_a} es mayor que {threshold}, entonces el campo {col_b} no puede ser nulo ni negativo.",
            "dimension": "consistency",
            "complexity": "POINT_IN_TIME",
            "status": "REVIEWED",
            "ir_gold": {
                "ir_version": "1.0",
                "rule_id": rule_id,
                "dimension": "consistency",
                "complexity": "POINT_IN_TIME",
                "scope": {"level": "row", "tables": [], "columns": [col_a, col_b]},
                "trigger": {"field": col_a, "op": "gt", "value": threshold},
                "logic": {
                    "operator": "IF",
                    "clauses": [
                        {"field": col_a, "op": "gt", "value": threshold},
                        {"field": col_b, "op": "not_null"},
                        {"field": col_b, "op": "gte", "value": 0}
                    ]
                },
                "quantifier": None,
                "time_window": None,
                "evidence": [{"type": "column_value", "column": col_a}, {"type": "column_value", "column": col_b}],
                "action": {"mode": "detect", "targets": [col_b]},
                "non_applicability": {"condition": f"{col_a} <= {threshold}"},
                "ambiguities": [],
                "confidence": 0.85,
                "blueprint": {
                    "columns_involved": [col_a, col_b],
                    "error_condition": f"{col_a} > {threshold} AND ({col_b} is null OR {col_b} < 0)",
                    "correction_action": f"flag record where {col_a} > {threshold} but {col_b} is null or negative"
                }
            },
            "oracle": {
                "expected_flagged": f"rows where {col_a} > {threshold} AND ({col_b} is null OR {col_b} < 0)",
                "positive_example": {col_a: threshold + 100, col_b: 50},
                "negative_example": {col_a: threshold + 100, col_b: None}
            },
            "paraphrases": [
                f"Cuando {col_a} supera {threshold}, el campo {col_b} debe tener un valor positivo.",
                f"Las filas con {col_a} > {threshold} deben tener {col_b} no nulo y no negativo."
            ],
            "test_cases": [
                {"case_type": "positive", "input": {col_a: threshold + 100, col_b: 50}, "expected_label": False},
                {"case_type": "negative", "input": {col_a: threshold + 100, col_b: None}, "expected_label": True},
                {"case_type": "negative", "input": {col_a: threshold + 100, col_b: -10}, "expected_label": True},
                {"case_type": "not_applicable", "input": {col_a: threshold - 10, col_b: None}, "expected_label": None},
            ],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "reviewed_by": "generated_script",
            "reviewed_at": datetime.now(timezone.utc).isoformat(),
        }

    # Pattern B: categorical + numeric constraint
    if cat_cols and numeric_cols:
        cat_col = rng.choice(cat_cols[:3])
        num_col = rng.choice(numeric_cols[:3])
        cat_info = cols[cat_col]
        cat_vals = cat_info.get("values", [])
        if cat_vals:
            trigger_val = rng.choice(cat_vals[:3])
            threshold = rng.choice([1000, 5000, 10000])
            return {
                "rule_id": rule_id,
                "dataset_id": dataset_id,
                "nl_text": f"Si el campo {cat_col} es '{trigger_val}', entonces el campo {num_col} debe ser mayor que {threshold}.",
                "dimension": "consistency",
                "complexity": "POINT_IN_TIME",
                "status": "REVIEWED",
                "ir_gold": {
                    "ir_version": "1.0",
                    "rule_id": rule_id,
                    "dimension": "consistency",
                    "complexity": "POINT_IN_TIME",
                    "scope": {"level": "row", "tables": [], "columns": [cat_col, num_col]},
                    "trigger": {"field": cat_col, "op": "eq", "value": trigger_val},
                    "logic": {
                        "operator": "IF",
                        "clauses": [
                            {"field": cat_col, "op": "eq", "value": trigger_val},
                            {"field": num_col, "op": "gt", "value": threshold}
                        ]
                    },
                    "quantifier": None,
                    "time_window": None,
                    "evidence": [{"type": "column_value", "column": cat_col}, {"type": "column_value", "column": num_col}],
                    "action": {"mode": "detect", "targets": [num_col]},
                    "non_applicability": {"condition": f"{cat_col} != '{trigger_val}'"},
                    "ambiguities": [],
                    "confidence": 0.82,
                    "blueprint": {
                        "columns_involved": [cat_col, num_col],
                        "error_condition": f"{cat_col} = '{trigger_val}' AND {num_col} <= {threshold}",
                        "correction_action": f"flag record where {cat_col}='{trigger_val}' but {num_col} is not above {threshold}"
                    }
                },
                "oracle": {
                    "expected_flagged": f"rows where {cat_col} = '{trigger_val}' AND {num_col} <= {threshold}",
                    "positive_example": {cat_col: trigger_val, num_col: threshold + 1000},
                    "negative_example": {cat_col: trigger_val, num_col: threshold - 100}
                },
                "paraphrases": [
                    f"Los registros con {cat_col} igual a '{trigger_val}' deben tener {num_col} superior a {threshold}.",
                    f"El campo {num_col} debe superar {threshold} cuando {cat_col} es '{trigger_val}'."
                ],
                "test_cases": [
                    {"case_type": "positive", "input": {cat_col: trigger_val, num_col: threshold + 1000}, "expected_label": False},
                    {"case_type": "negative", "input": {cat_col: trigger_val, num_col: threshold - 100}, "expected_label": True},
                    {"case_type": "not_applicable", "input": {cat_col: "OTHER_VALUE", num_col: 0}, "expected_label": None},
                ],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "reviewed_by": "generated_script",
                "reviewed_at": datetime.now(timezone.utc).isoformat(),
            }
    return None


def generate_hard_rule(rule_id: str, schema: dict, rng: random.Random) -> dict | None:
    """Generate a hard HISTORICAL rule with temporal or aggregate logic."""
    cols = schema.get("columns", {})
    if not cols:
        return None

    numeric_cols = [c for c, t in cols.items() if t == "numeric"]
    date_cols = [c for c, t in cols.items() if t == "datetime" or "date" in c.lower() or "Date" in c]
    cat_cols = [c for c, t in cols.items() if isinstance(t, dict) and t.get("type") == "categorical"]
    dataset_id = f"{schema['owner']}/{schema['slug']}"

    # Pattern F: temporal ordering — date_col must be before another date_col
    if len(date_cols) >= 2:
        date_a, date_b = rng.sample(date_cols[:4], 2)
        return {
            "rule_id": rule_id,
            "dataset_id": dataset_id,
            "nl_text": f"El campo {date_a} debe ser anterior al campo {date_b} en todos los registros. Un {date_a} posterior a {date_b} indica un error de integridad temporal.",
            "dimension": "consistency",
            "complexity": "HISTORICAL",
            "status": "REVIEWED",
            "ir_gold": {
                "ir_version": "1.0",
                "rule_id": rule_id,
                "dimension": "consistency",
                "complexity": "HISTORICAL",
                "scope": {"level": "row", "tables": [], "columns": [date_a, date_b]},
                "trigger": {},
                "logic": {
                    "operator": "AND",
                    "clauses": [
                        {"field": date_a, "op": "not_null"},
                        {"field": date_b, "op": "not_null"},
                        {"field": date_a, "op": "lt_field", "value": date_b}
                    ]
                },
                "quantifier": None,
                "time_window": {"unit": "record", "size": 1},
                "evidence": [{"type": "column_value", "column": date_a}, {"type": "column_value", "column": date_b}],
                "action": {"mode": "detect", "targets": [date_a]},
                "non_applicability": {"condition": f"{date_a} is null OR {date_b} is null"},
                "ambiguities": [],
                "confidence": 0.90,
                "blueprint": {
                    "columns_involved": [date_a, date_b],
                    "error_condition": f"{date_a} >= {date_b} (date_a should precede date_b)",
                    "correction_action": f"flag record where {date_a} is not before {date_b}"
                }
            },
            "oracle": {
                "expected_flagged": f"rows where {date_a} >= {date_b}",
                "positive_example": {date_a: "2020-01-01", date_b: "2023-12-31"},
                "negative_example": {date_a: "2025-01-01", date_b: "2020-01-01"}
            },
            "paraphrases": [
                f"La fecha {date_a} no puede ser igual ni posterior a {date_b}.",
                f"Todo registro debe tener {date_a} anterior a {date_b}."
            ],
            "test_cases": [
                {"case_type": "positive", "input": {date_a: "2020-01-01", date_b: "2023-12-31"}, "expected_label": False},
                {"case_type": "negative", "input": {date_a: "2025-01-01", date_b: "2020-01-01"}, "expected_label": True},
                {"case_type": "boundary", "input": {date_a: "2023-12-31", date_b: "2023-12-31"}, "expected_label": True},
                {"case_type": "null_safe", "input": {date_a: None, date_b: "2023-12-31"}, "expected_label": None},
            ],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "reviewed_by": "generated_script",
            "reviewed_at": datetime.now(timezone.utc).isoformat(),
        }

    # Pattern G: aggregate — numeric col must be > 0 for all records in a category group
    if cat_cols and numeric_cols:
        cat_col = rng.choice(cat_cols[:3])
        num_col = rng.choice(numeric_cols[:3])
        return {
            "rule_id": rule_id,
            "dataset_id": dataset_id,
            "nl_text": f"Para cada valor único de {cat_col}, la suma total del campo {num_col} debe ser mayor que cero. Un grupo con suma negativa indica errores acumulados.",
            "dimension": "consistency",
            "complexity": "HISTORICAL",
            "status": "REVIEWED",
            "ir_gold": {
                "ir_version": "1.0",
                "rule_id": rule_id,
                "dimension": "consistency",
                "complexity": "HISTORICAL",
                "scope": {"level": "group", "tables": [], "columns": [cat_col, num_col]},
                "trigger": {},
                "logic": {
                    "operator": "AGGREGATE",
                    "clauses": [
                        {"field": num_col, "op": "group_sum_gt", "group_by": cat_col, "value": 0}
                    ]
                },
                "quantifier": {"type": "sum", "group_by": cat_col},
                "time_window": None,
                "evidence": [{"type": "column_value", "column": num_col}, {"type": "column_value", "column": cat_col}],
                "action": {"mode": "detect", "targets": [num_col]},
                "non_applicability": {},
                "ambiguities": [],
                "confidence": 0.80,
                "blueprint": {
                    "columns_involved": [cat_col, num_col],
                    "error_condition": f"sum({num_col}) grouped by {cat_col} <= 0",
                    "correction_action": f"flag all records in groups where sum({num_col}) <= 0"
                }
            },
            "oracle": {
                "expected_flagged": f"all records in groups where sum({num_col}) <= 0 per {cat_col}",
                "positive_example": {cat_col: "GroupA", num_col: 100},
                "negative_example": {cat_col: "GroupB", num_col: -5000}
            },
            "paraphrases": [
                f"La suma de {num_col} por {cat_col} no puede ser negativa ni cero.",
                f"Cada grupo de {cat_col} debe tener {num_col} acumulado positivo."
            ],
            "test_cases": [
                {"case_type": "positive", "input": {cat_col: "GroupA", num_col: 100}, "expected_label": False},
                {"case_type": "negative", "input": {cat_col: "GroupB", num_col: -5000}, "expected_label": True},
                {"case_type": "null_safe", "input": {cat_col: None, num_col: 100}, "expected_label": None},
            ],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "reviewed_by": "generated_script",
            "reviewed_at": datetime.now(timezone.utc).isoformat(),
        }

    # Pattern I: vacuous truth check
    if cat_cols:
        cat_col = rng.choice(cat_cols[:3])
        rare_val = f"RARE_VALUE_{rule_id}"
        return {
            "rule_id": rule_id,
            "dataset_id": dataset_id,
            "nl_text": f"Si el campo {cat_col} contiene el valor '{rare_val}', entonces todos los campos numéricos deben ser verificados manualmente. Regla de antecedente potencialmente vacuo.",
            "dimension": "validity",
            "complexity": "HISTORICAL",
            "status": "REVIEWED",
            "ir_gold": {
                "ir_version": "1.0",
                "rule_id": rule_id,
                "dimension": "validity",
                "complexity": "HISTORICAL",
                "scope": {"level": "row", "tables": [], "columns": [cat_col]},
                "trigger": {"field": cat_col, "op": "eq", "value": rare_val},
                "logic": {
                    "operator": "IF",
                    "clauses": [
                        {"field": cat_col, "op": "eq", "value": rare_val}
                    ]
                },
                "quantifier": None,
                "time_window": None,
                "evidence": [{"type": "column_value", "column": cat_col}],
                "action": {"mode": "abstain", "targets": []},
                "non_applicability": {"condition": f"{cat_col} != '{rare_val}'"},
                "ambiguities": [f"Antecedent '{cat_col}={rare_val}' may never be true in data (vacuous truth)"],
                "confidence": 0.70,
                "blueprint": {
                    "columns_involved": [cat_col],
                    "error_condition": f"{cat_col} = '{rare_val}' (triggers ABSTAIN — vacuous truth test)",
                    "correction_action": "ABSTAIN — rule is non-applicable if antecedent never holds"
                }
            },
            "oracle": {
                "expected_flagged": f"ABSTAIN — antecedent '{cat_col}={rare_val}' never true in dataset",
                "positive_example": {cat_col: "NORMAL_VALUE"},
                "negative_example": {cat_col: rare_val},
                "not_applicable_example": {cat_col: "OTHER"}
            },
            "paraphrases": [
                f"La regla sobre {cat_col}='{rare_val}' es vacuamente verdadera si ese valor no existe en los datos.",
                f"El sistema debe detectar cuando el antecedente de una regla nunca se cumple y emitir ABSTAIN."
            ],
            "test_cases": [
                {"case_type": "not_applicable", "input": {cat_col: "NORMAL_VALUE"}, "expected_label": None},
                {"case_type": "not_applicable", "input": {cat_col: None}, "expected_label": None},
            ],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "reviewed_by": "generated_script",
            "reviewed_at": datetime.now(timezone.utc).isoformat(),
        }

    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--level", choices=["medium", "hard", "all"], default="all")
    parser.add_argument("--target", type=int, default=160,
                        help="Total number of new rules to generate")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", type=str, default=None)
    args = parser.parse_args()

    rng = random.Random(args.seed)

    # Load registry to get dataset list
    registry_path = _REPO / "data" / "registry" / "datasets.csv"
    datasets = []
    with open(registry_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("eligible", "True") == "True":
                datasets.append((row["owner"], row["slug"]))

    print(f"Found {len(datasets)} eligible datasets")

    # Generate rules
    rules: list[dict] = []
    rule_counter = START_ID
    target_medium = args.target // 2 if args.level == "all" else (args.target if args.level == "medium" else 0)
    target_hard = args.target - target_medium if args.level in ("hard", "all") else 0

    print(f"Target: {target_medium} medium + {target_hard} hard = {args.target} total")

    datasets_cycle = datasets * (args.target // len(datasets) + 2)
    rng.shuffle(datasets_cycle)
    ds_iter = iter(datasets_cycle)

    # Generate medium rules
    generated_medium = 0
    attempts_medium = 0
    while generated_medium < target_medium and attempts_medium < target_medium * 5:
        attempts_medium += 1
        try:
            owner, slug = next(ds_iter)
        except StopIteration:
            break
        schema = get_dataset_schema(owner, slug)
        if not schema.get("columns"):
            continue
        rule_id = f"R-{rule_counter:04d}"
        rule = generate_medium_rule(rule_id, schema, rng)
        if rule:
            rules.append(rule)
            rule_counter += 1
            generated_medium += 1
            if generated_medium % 10 == 0:
                print(f"  Medium rules: {generated_medium}/{target_medium}")

    # Generate hard rules
    generated_hard = 0
    attempts_hard = 0
    while generated_hard < target_hard and attempts_hard < target_hard * 5:
        attempts_hard += 1
        try:
            owner, slug = next(ds_iter)
        except StopIteration:
            break
        schema = get_dataset_schema(owner, slug)
        if not schema.get("columns"):
            continue
        rule_id = f"R-{rule_counter:04d}"
        rule = generate_hard_rule(rule_id, schema, rng)
        if rule:
            rules.append(rule)
            rule_counter += 1
            generated_hard += 1
            if generated_hard % 10 == 0:
                print(f"  Hard rules: {generated_hard}/{target_hard}")

    print(f"\nGenerated: {generated_medium} medium + {generated_hard} hard = {len(rules)} rules")

    if not rules:
        print("ERROR: No rules generated. Check that datasets have readable CSV files.")
        return 1

    # Write output
    if args.output:
        out_path = pathlib.Path(args.output)
    else:
        level_str = args.level
        out_path = RULES_DIR / f"generated_{level_str}_rules_{len(rules)}.jsonl"

    with open(out_path, "w", encoding="utf-8") as f:
        for rule in rules:
            f.write(json.dumps(rule, ensure_ascii=False) + "\n")

    print(f"\nSaved {len(rules)} rules to {out_path}")
    print(f"\nDistribution:")
    from collections import Counter
    comp_dist = Counter(r["complexity"] for r in rules)
    dim_dist = Counter(r["dimension"] for r in rules)
    for k, v in sorted(comp_dist.items()):
        print(f"  {k}: {v}")
    print(f"\nNext: review generated rules and merge into pilot_reviewed_20.jsonl")
    print(f"      python scripts/audit_rules.py --target {20 + len(rules)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
