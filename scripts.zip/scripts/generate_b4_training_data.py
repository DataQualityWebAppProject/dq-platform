#!/usr/bin/env python3
"""Generate NL→IR training pairs for B4 QLoRA adapter.

Each pair is: (NL rule text) → (IR JSON).
Uses the reviewed rules as source of gold IR.

Output format (JSONL, same as qlora training data):
  {"instruction": "...", "input": "...", "output": "..."}
  
Where:
  instruction = system prompt for NL→IR task
  input = NL rule text + dataset context
  output = IR JSON (the ir_gold field)

Usage:
    python scripts/generate_b4_training_data.py
    python scripts/generate_b4_training_data.py --rules data/rules/pilot_reviewed_20.jsonl --output data/qlora_training/pairs_nl2ir.jsonl
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

_REPO = pathlib.Path(__file__).resolve().parent.parent

_INSTRUCTION = (
    "You are a data quality rule analyzer. "
    "Given a natural language data quality rule, produce a structured JSON Intermediate Representation (IR) "
    "that captures the rule's dimension, complexity, scope (columns), logic (operator and clauses), "
    "trigger condition, non-applicability condition, and blueprint (columns_involved, error_condition, correction_action). "
    "Output ONLY the JSON object, no explanation."
)


def rule_to_training_pair(rule: dict) -> dict | None:
    """Convert a reviewed rule to a NL→IR training pair."""
    ir = rule.get("ir_gold")
    if not ir:
        return None
    nl_text = rule.get("nl_text", "")
    dataset_id = rule.get("dataset_id", "")
    dimension = rule.get("dimension", "")
    complexity = rule.get("complexity", "POINT_IN_TIME")

    # Build the input (what the model sees)
    cols = ir.get("scope", {}).get("columns", [])
    input_text = (
        f"Dataset: {dataset_id}\n"
        f"Rule: {nl_text}\n"
        f"Dimension hint: {dimension}\n"
        f"Complexity hint: {complexity}\n"
        f"Known columns: {', '.join(cols) if cols else 'unknown'}"
    )

    # Build the output (what the model should generate)
    # Clean the IR: remove internal fields not needed at inference time
    ir_output = {
        "ir_version": ir.get("ir_version", "1.0"),
        "rule_id": rule.get("rule_id", ""),
        "dimension": ir.get("dimension", dimension),
        "complexity": ir.get("complexity", complexity),
        "scope": ir.get("scope", {"level": "row", "tables": [], "columns": cols}),
        "trigger": ir.get("trigger", {}),
        "logic": ir.get("logic", {"operator": "AND", "clauses": []}),
        "quantifier": ir.get("quantifier"),
        "time_window": ir.get("time_window"),
        "evidence": ir.get("evidence", []),
        "action": ir.get("action", {"mode": "detect", "targets": cols}),
        "non_applicability": ir.get("non_applicability", {}),
        "ambiguities": ir.get("ambiguities", []),
        "confidence": ir.get("confidence", 0.85),
        "blueprint": ir.get("blueprint", {
            "columns_involved": cols,
            "error_condition": "",
            "correction_action": ""
        }),
    }

    return {
        "instruction": _INSTRUCTION,
        "input": input_text,
        "output": json.dumps(ir_output, ensure_ascii=False, indent=2),
        "rule_id": rule.get("rule_id", ""),
        "dimension": dimension,
        "complexity": complexity,
    }


def load_rules(path: pathlib.Path) -> list[dict]:
    rules = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                try:
                    rules.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return rules


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rules", nargs="+", default=[
        "data/rules/pilot_reviewed_20.jsonl",
        "data/rules/pilot_historical_rules.jsonl",
    ], help="JSONL files with reviewed rules")
    parser.add_argument("--output", default="data/qlora_training/pairs_nl2ir.jsonl")
    args = parser.parse_args()

    out_path = _REPO / args.output
    out_path.parent.mkdir(parents=True, exist_ok=True)

    all_rules = []
    for rules_file in args.rules:
        rules_path = _REPO / rules_file
        if rules_path.exists():
            rules = load_rules(rules_path)
            all_rules.extend(rules)
            print(f"Loaded {len(rules)} rules from {rules_path}")
        else:
            print(f"WARNING: {rules_path} not found, skipping")

    if not all_rules:
        print("ERROR: No rules loaded.", file=sys.stderr)
        return 1

    pairs = []
    skipped = 0
    for rule in all_rules:
        if rule.get("status") != "REVIEWED":
            skipped += 1
            continue
        pair = rule_to_training_pair(rule)
        if pair:
            pairs.append(pair)

    print(f"\nTotal rules: {len(all_rules)}")
    print(f"Skipped (not REVIEWED): {skipped}")
    print(f"Training pairs generated: {len(pairs)}")

    with open(out_path, "w", encoding="utf-8") as f:
        for pair in pairs:
            f.write(json.dumps(pair, ensure_ascii=False) + "\n")

    print(f"\nSaved {len(pairs)} NL→IR pairs to {out_path}")

    # Distribution
    from collections import Counter
    dim_dist = Counter(p["dimension"] for p in pairs)
    comp_dist = Counter(p["complexity"] for p in pairs)
    print("\nDistribution:")
    print("  Dimension:", dict(dim_dist))
    print("  Complexity:", dict(comp_dist))
    print(f"\nSHA-256 of output: ", end="")
    import hashlib
    content = out_path.read_bytes()
    print(hashlib.sha256(content).hexdigest())

    print(f"\nNext: python scripts/train_qlora.py --config configs/qlora_nl2ir.yaml --seed 42")
    print(f"      (update qlora_nl2ir.yaml with hyperparameters first)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
