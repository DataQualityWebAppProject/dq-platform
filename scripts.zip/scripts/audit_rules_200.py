#!/usr/bin/env python3
"""Audit pilot_rules_200.jsonl: check which rules have their dataset available.

Output:
  - Count of rules with CSV available
  - Count by dimension and complexity
  - List of rule_ids with missing datasets
  - Writes data/rules/pilot_rules_200_eligible.jsonl with only rules that have CSV

Usage:
    python scripts/audit_rules_200.py
"""
import json
import sys
from collections import Counter
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent


def main() -> int:
    rules_path = _REPO / "data/rules/pilot_rules_200.jsonl"
    rules = []
    with open(rules_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rules.append(json.loads(line))

    print(f"Total rules in pilot_rules_200.jsonl: {len(rules)}")

    eligible = []
    missing_dataset = []

    for rule in rules:
        dataset_id = rule.get("dataset_id", "")
        if not dataset_id or "/" not in dataset_id:
            missing_dataset.append(rule["rule_id"])
            continue
        owner, slug = dataset_id.split("/", 1)
        raw_dir = _REPO / "data" / "raw" / owner / slug / "vlatest" / "raw"
        csvs = list(raw_dir.glob("*.csv")) if raw_dir.exists() else []
        if csvs:
            eligible.append(rule)
        else:
            missing_dataset.append(rule["rule_id"])

    print(f"\nEligible (CSV available): {len(eligible)}")
    print(f"Missing dataset:          {len(missing_dataset)}")

    # Stats on eligible
    dims = Counter(r.get("dimension") for r in eligible)
    complexities = Counter(r.get("complexity") for r in eligible)
    datasets = Counter(r.get("dataset_id") for r in eligible)

    print("\nEligible by dimension:")
    for k, v in sorted(dims.items()):
        print(f"  {k}: {v}")

    print("\nEligible by complexity:")
    for k, v in sorted(complexities.items()):
        print(f"  {k}: {v}")

    print(f"\nTop 10 datasets by rule count:")
    for ds, cnt in datasets.most_common(10):
        print(f"  {ds}: {cnt} rules")

    # Write eligible rules
    out_path = _REPO / "data/rules/pilot_rules_200_eligible.jsonl"
    with open(out_path, "w", encoding="utf-8") as f:
        for r in eligible:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(eligible)} eligible rules to: {out_path}")

    if missing_dataset:
        print(f"\nMissing dataset rule_ids ({len(missing_dataset)}):")
        for rid in missing_dataset[:20]:
            print(f"  {rid}")
        if len(missing_dataset) > 20:
            print(f"  ... and {len(missing_dataset) - 20} more")

    return 0


if __name__ == "__main__":
    sys.exit(main())
