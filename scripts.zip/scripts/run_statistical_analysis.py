#!/usr/bin/env python3
"""Statistical analysis: Bootstrap CI 95%, McNemar/Wilcoxon, B5 ablation proxy.

Three experiments from existing parquets — no GPU required.

Experiment 1: Bootstrap CI 95% (grouped by dataset)
  - Resample datasets with replacement (not individual rules)
  - Include all rules from each selected dataset
  - Repeat B=10,000 times
  - Report percentiles 2.5 and 97.5

Experiment 2: McNemar test + Wilcoxon signed-rank test
  - Binary: F1 > 0.5 = correct, else incorrect
  - Wilcoxon: continuous F1 per rule, paired
  - Pairs: B6 vs B5, B6 vs B0, B5 vs B0, B5 vs B3, B0 vs B3, B2 vs B1

Experiment 3: B5 ablation proxy (from existing parquets)
  - B5_minus_REPAIR: use B0 predictions for rules where B5 repaired (n_repair>0)
  - B5_minus_AST:    treat AST-blocked rules as ERR (F1=0)
  - B5_minus_TDD:    replace B5 with B0 for rules where tdd_n_tests>0
  - Full B5 vs B0:   direct comparison
  NOTE: B5_minus_SCOPE/EVID/PLAN/CAN/META require re-inference (not computed here)

Usage:
    python scripts/run_statistical_analysis.py
    python scripts/run_statistical_analysis.py --split ext --B 10000
    python scripts/run_statistical_analysis.py --split pilot --B 5000
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time
import warnings
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")

_REPO = pathlib.Path(__file__).resolve().parent.parent
_METRICS = _REPO / "artifacts" / "metrics" / "pilot"
_OUT = _REPO / "artifacts" / "statistics"
_OUT.mkdir(parents=True, exist_ok=True)

_PREDICTIONS = _REPO / "artifacts" / "predictions" / "pilot"

# ── Config sets by split ──────────────────────────────────────────────────────
_PILOT_CONFIGS = {
    "B0": "B0_metrics",
    "B1": "B1_metrics",
    "B2": "B2_metrics",
    "B3_seed42": "B3_seed42_metrics",
    "B4_seed42": "B4_seed42_metrics",
    "B5": "B5_metrics",
}

_EXT_CONFIGS = {
    "B0": "B0_ext_metrics",
    "B1": "B1_ext_metrics",
    "B2": "B2_ext_metrics",
    "B3_seed42": "B3_seed42_ext_metrics",
    "B4_seed42": "B4_seed42_ext_metrics",
    "B5": "B5_ext_metrics",
    "B6_seed42": "B6_seed42_ext_metrics",
}

# Pairs to test (A vs B): (name_A, name_B)
_TEST_PAIRS = [
    ("B6_seed42", "B5"),
    ("B6_seed42", "B0"),
    ("B5", "B0"),
    ("B5", "B3_seed42"),
    ("B3_seed42", "B0"),
    ("B2", "B1"),
    ("B0", "B4_seed42"),
]


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_config(parquet_stem: str) -> pd.DataFrame | None:
    path = _METRICS / f"{parquet_stem}.parquet"
    if not path.exists():
        return None
    df = pd.read_parquet(path)
    return df[df["f1"].notna()].copy()


def grouped_bootstrap_f1(
    df: pd.DataFrame,
    B: int = 10_000,
    seed: int = 42,
    alpha: float = 0.05,
) -> dict:
    """Bootstrap macro-F1 grouped by dataset_id.

    Algorithm:
    1. Get unique datasets D = {d1, d2, ..., dk}
    2. For b in 1..B:
       a. Sample k datasets with replacement → D_b
       b. Collect all rules from those datasets
       c. Compute macro-F1 over the collected rules
    3. CI = [percentile(alpha/2), percentile(1-alpha/2)]
    """
    rng = np.random.default_rng(seed)
    datasets = df["dataset_id"].unique()
    k = len(datasets)
    observed_f1 = df["f1"].mean()

    boot_f1s = np.empty(B)
    for b in range(B):
        sampled = rng.choice(datasets, size=k, replace=True)
        boot_rules = df[df["dataset_id"].isin(sampled)]
        boot_f1s[b] = boot_rules["f1"].mean() if len(boot_rules) > 0 else 0.0

    lo = float(np.percentile(boot_f1s, 100 * alpha / 2))
    hi = float(np.percentile(boot_f1s, 100 * (1 - alpha / 2)))

    return {
        "f1_observed": float(observed_f1),
        "ci_lo": lo,
        "ci_hi": hi,
        "ci_width": hi - lo,
        "n_rules": int(len(df)),
        "n_datasets": int(k),
        "B": B,
        "seed": seed,
    }


def mcnemar_test(df_a: pd.DataFrame, df_b: pd.DataFrame, threshold: float = 0.5) -> dict:
    """McNemar test on paired binary outcomes (F1 > threshold = correct)."""
    merged = df_a[["rule_id", "f1"]].merge(
        df_b[["rule_id", "f1"]], on="rule_id", suffixes=("_a", "_b")
    )
    if len(merged) == 0:
        return {"error": "no common rules"}

    correct_a = merged["f1_a"] > threshold
    correct_b = merged["f1_b"] > threshold

    n_both_correct   = int(( correct_a &  correct_b).sum())
    n_only_a_correct = int(( correct_a & ~correct_b).sum())
    n_only_b_correct = int((~correct_a &  correct_b).sum())
    n_both_wrong     = int((~correct_a & ~correct_b).sum())

    # McNemar with continuity correction
    b = n_only_a_correct
    c = n_only_b_correct
    n_discordant = b + c

    if n_discordant == 0:
        chi2, p_value = 0.0, 1.0
    else:
        chi2 = (abs(b - c) - 1) ** 2 / n_discordant
        p_value = float(stats.chi2.sf(chi2, df=1))

    return {
        "n_rules": int(len(merged)),
        "n_both_correct": n_both_correct,
        "n_only_a_correct": n_only_a_correct,
        "n_only_b_correct": n_only_b_correct,
        "n_both_wrong": n_both_wrong,
        "n_discordant": n_discordant,
        "chi2": float(chi2),
        "p_value": p_value,
        "significant_alpha05": p_value < 0.05,
        "threshold": threshold,
    }


def wilcoxon_test(df_a: pd.DataFrame, df_b: pd.DataFrame) -> dict:
    """Wilcoxon signed-rank test on paired continuous F1 values."""
    merged = df_a[["rule_id", "f1"]].merge(
        df_b[["rule_id", "f1"]], on="rule_id", suffixes=("_a", "_b")
    )
    if len(merged) < 10:
        return {"error": f"too few paired observations: {len(merged)}"}

    diffs = merged["f1_a"].values - merged["f1_b"].values
    non_zero = diffs[diffs != 0]

    if len(non_zero) < 5:
        return {"error": f"too few non-zero differences: {len(non_zero)}"}

    try:
        stat, p_value = stats.wilcoxon(non_zero, alternative="two-sided",
                                        correction=True)
        # Effect size: r = Z / sqrt(N)
        z = stats.norm.ppf(1 - p_value / 2) * np.sign(stat - len(non_zero) * (len(non_zero) + 1) / 4)
        r = abs(z) / np.sqrt(len(non_zero))
    except Exception as e:
        return {"error": str(e)}

    return {
        "n_rules": int(len(merged)),
        "n_nonzero_diffs": int(len(non_zero)),
        "mean_diff_a_minus_b": float(diffs.mean()),
        "median_diff_a_minus_b": float(np.median(diffs)),
        "statistic": float(stat),
        "p_value": float(p_value),
        "effect_size_r": float(r),
        "significant_alpha05": float(p_value) < 0.05,
    }


def load_predictions(pred_dir_name: str) -> pd.DataFrame | None:
    """Load prediction parquet which contains pipeline metadata (n_repair, tdd, sandbox_ok)."""
    path = _PREDICTIONS / pred_dir_name / "predictions.parquet"
    if not path.exists():
        return None
    df = pd.read_parquet(path)
    return df


def b5_ablation_proxy(df_b5: pd.DataFrame, df_b0: pd.DataFrame,
                      pred_b5: pd.DataFrame | None = None) -> dict:
    """
    Proxy ablation from existing parquets.
    If pred_b5 is provided, uses pipeline metadata (n_repair_attempts, tdd_n_tests, sandbox_ok).

    B5_minus_REPAIR:
        For rules where B5 repaired (n_repair_attempts > 0),
        substitute B0's F1. This estimates B5 without repair.

    B5_minus_TDD:
        For rules where B5 generated TDD tests (tdd_n_tests > 0),
        substitute B0's F1. This estimates B5 without TDD context.

    B5_minus_PIPELINE (= B0):
        Use B0 F1 for all rules. Already computed.
    """
    # Join metrics with prediction metadata if available
    if pred_b5 is not None:
        meta_cols = ["rule_id"]
        for col in ["n_repair_attempts", "tdd_n_tests", "sandbox_ok"]:
            if col in pred_b5.columns:
                meta_cols.append(col)
        df_b5 = df_b5.merge(pred_b5[meta_cols], on="rule_id", how="left")

    merged = df_b5.merge(
        df_b0[["rule_id", "f1"]].rename(columns={"f1": "f1_b0"}),
        on="rule_id", how="inner"
    )

    results = {}

    # Full B5
    results["B5_full"] = {
        "f1_macro": float(merged["f1"].mean()),
        "n_rules": int(len(merged)),
    }

    # B0 baseline
    results["B5_minus_PIPELINE_B0"] = {
        "f1_macro": float(merged["f1_b0"].mean()),
        "n_rules": int(len(merged)),
        "delta_vs_B5": float(merged["f1_b0"].mean() - merged["f1"].mean()),
    }

    # B5 minus REPAIR
    if "n_repair_attempts" in merged.columns:
        repaired_mask = merged["n_repair_attempts"] > 0
        n_repaired = int(repaired_mask.sum())
        f1_no_repair = merged["f1"].copy()
        f1_no_repair[repaired_mask] = merged.loc[repaired_mask, "f1_b0"]
        results["B5_minus_REPAIR"] = {
            "f1_macro": float(f1_no_repair.mean()),
            "n_rules_affected": n_repaired,
            "delta_vs_B5": float(f1_no_repair.mean() - merged["f1"].mean()),
        }
    else:
        results["B5_minus_REPAIR"] = {"error": "n_repair_attempts not in parquet"}

    # B5 minus TDD
    if "tdd_n_tests" in merged.columns:
        tdd_mask = merged["tdd_n_tests"] > 0
        n_tdd = int(tdd_mask.sum())
        f1_no_tdd = merged["f1"].copy()
        f1_no_tdd[tdd_mask] = merged.loc[tdd_mask, "f1_b0"]
        results["B5_minus_TDD"] = {
            "f1_macro": float(f1_no_tdd.mean()),
            "n_rules_affected": n_tdd,
            "delta_vs_B5": float(f1_no_tdd.mean() - merged["f1"].mean()),
        }
    else:
        results["B5_minus_TDD"] = {"error": "tdd_n_tests not in parquet"}

    # B5 minus AST+SANDBOX (proxy: rules that needed repair)
    if "n_repair_attempts" in merged.columns:
        ast_repaired = merged["n_repair_attempts"] > 0
        n_ast = int(ast_repaired.sum())
        f1_no_ast = merged["f1"].copy()
        f1_no_ast[ast_repaired] = merged.loc[ast_repaired, "f1_b0"]
        results["B5_minus_AST_SANDBOX_proxy"] = {
            "f1_macro": float(f1_no_ast.mean()),
            "n_rules_affected": n_ast,
            "delta_vs_B5": float(f1_no_ast.mean() - merged["f1"].mean()),
            "note": "proxy: rules requiring repair — AST+Sandbox contribution",
        }
    else:
        results["B5_minus_AST_SANDBOX_proxy"] = {"error": "n_repair_attempts not available"}

    return results


def print_section(title: str) -> None:
    print(f"\n{'='*65}")
    print(f"  {title}")
    print(f"{'='*65}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", choices=["pilot", "ext", "both"], default="both",
                        help="Which split to analyse (default: both)")
    parser.add_argument("--B", type=int, default=10_000,
                        help="Bootstrap iterations (default: 10000)")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--alpha", type=float, default=0.05)
    args = parser.parse_args()

    splits_to_run = []
    if args.split in ("pilot", "both"):
        splits_to_run.append(("pilot", _PILOT_CONFIGS))
    if args.split in ("ext", "both"):
        splits_to_run.append(("ext", _EXT_CONFIGS))

    all_results: dict = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "B": args.B,
        "seed": args.seed,
        "alpha": args.alpha,
        "experiments": {},
    }

    # ── EXPERIMENT 1: Bootstrap CI ────────────────────────────────────────────
    for split_name, configs in splits_to_run:
        print_section(f"EXPERIMENT 1: Bootstrap CI 95% — {split_name} split (B={args.B})")
        boot_results = {}

        for cfg_name, parquet_stem in sorted(configs.items()):
            df = load_config(parquet_stem)
            if df is None:
                print(f"  {cfg_name:<20}: SKIP (parquet not found)")
                continue
            t0 = time.monotonic()
            r = grouped_bootstrap_f1(df, B=args.B, seed=args.seed, alpha=args.alpha)
            elapsed = time.monotonic() - t0
            boot_results[cfg_name] = r
            print(
                f"  {cfg_name:<20}: F1={r['f1_observed']:.4f}  "
                f"95% CI [{r['ci_lo']:.4f}, {r['ci_hi']:.4f}]  "
                f"width={r['ci_width']:.4f}  "
                f"(n_rules={r['n_rules']}, n_datasets={r['n_datasets']}, {elapsed:.1f}s)"
            )

        all_results["experiments"][f"bootstrap_ci_{split_name}"] = boot_results

    # ── EXPERIMENT 2: McNemar + Wilcoxon ─────────────────────────────────────
    for split_name, configs in splits_to_run:
        print_section(f"EXPERIMENT 2: McNemar + Wilcoxon — {split_name} split")
        test_results = {}

        for name_a, name_b in _TEST_PAIRS:
            if name_a not in configs or name_b not in configs:
                continue
            df_a = load_config(configs[name_a])
            df_b = load_config(configs[name_b])
            if df_a is None or df_b is None:
                continue

            mc = mcnemar_test(df_a, df_b, threshold=0.5)
            wc = wilcoxon_test(df_a, df_b)
            pair_key = f"{name_a}_vs_{name_b}"
            test_results[pair_key] = {"mcnemar": mc, "wilcoxon": wc}

            f1_a = df_a["f1"].mean()
            f1_b = df_b["f1"].mean()
            diff = f1_a - f1_b
            mc_sig = "(*)" if mc.get("significant_alpha05") else "ns"
            wc_sig = "(*)" if wc.get("significant_alpha05") else "ns"
            wc_p = wc.get("p_value", float("nan"))
            mc_p = mc.get("p_value", float("nan"))
            print(
                f"  {name_a:<15} vs {name_b:<15}: "
                f"ΔF1={diff:+.4f}  "
                f"McNemar p={mc_p:.4f}{mc_sig}  "
                f"Wilcoxon p={wc_p:.4f}{wc_sig}  "
                f"r={wc.get('effect_size_r', float('nan')):.3f}"
            )

        all_results["experiments"][f"significance_tests_{split_name}"] = test_results

    # ── EXPERIMENT 3: B5 Ablation proxy ──────────────────────────────────────
    print_section("EXPERIMENT 3: B5 Stage Ablation (proxy from parquets)")

    for split_name, configs in splits_to_run:
        if "B5" not in configs or "B0" not in configs:
            continue
        df_b5 = load_config(configs["B5"])
        df_b0 = load_config(configs["B0"])
        if df_b5 is None or df_b0 is None:
            print(f"  [{split_name}] SKIP: B5 or B0 parquet missing")
            continue

        # Load prediction metadata for pipeline columns
        pred_dir = "B5" if split_name == "pilot" else "B5_ext"
        pred_b5 = load_predictions(pred_dir)
        ablation = b5_ablation_proxy(df_b5, df_b0, pred_b5=pred_b5)
        print(f"\n  Split: {split_name}")
        print(f"  {'Variant':<30} {'F1':>7}  {'ΔvsB5':>8}  {'n_affected':>12}")
        print(f"  {'-'*65}")

        for variant, r in ablation.items():
            if "error" in r:
                print(f"  {variant:<30}  ERROR: {r['error']}")
                continue
            f1 = r["f1_macro"]
            delta = r.get("delta_vs_B5", 0.0)
            n_aff = r.get("n_rules_affected", r.get("n_rules", 0))
            note = f"  [{r['note']}]" if "note" in r else ""
            print(f"  {variant:<30} {f1:>7.4f}  {delta:>+8.4f}  {n_aff:>12}{note}")

        all_results["experiments"][f"ablation_{split_name}"] = ablation

    # ── Save results ──────────────────────────────────────────────────────────
    out_path = _OUT / f"statistical_analysis_{args.split}_B{args.B}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*65}")
    print(f"  Saved: {out_path}")
    print(f"{'='*65}")
    print("\nINTERPRETATION GUIDE:")
    print("  Bootstrap CI: non-overlapping intervals → difference likely real")
    print("  McNemar p<0.05 (*): significantly different in binary correct/wrong")
    print("  Wilcoxon p<0.05 (*): significantly different in continuous F1")
    print("  Effect size r: 0.1=small, 0.3=medium, 0.5=large")
    print("  Ablation ΔvsB5<0: removing that component HURTS performance")
    return 0


if __name__ == "__main__":
    sys.exit(main())
