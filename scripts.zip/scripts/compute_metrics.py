#!/usr/bin/env python3
"""T5.3 — Compute functional F1 metrics from predictions Parquet files.

For each rule × config:
  1. Load the generated code from predictions.parquet
  2. Find the real CSV from data/raw/{owner}/{slug}/vlatest/raw/
  3. Inject controlled errors via oracle_injector (seed=42, n_inject=20)
  4. Execute check(df_modified) in isolated sandbox
  5. Compute F1 against oracle indices

Outputs:
  artifacts/metrics/pilot/{config}_metrics.parquet
  artifacts/metrics/pilot/{config}_summary.csv
  artifacts/metrics/pilot/natural_errors_report.csv  (exploratory only)

Usage:
    python scripts/compute_metrics.py [--config B0] [--rules data/rules/pilot_reviewed_20.jsonl]
"""
from __future__ import annotations
import sys as _sys; _sys.stdout.reconfigure(encoding="utf-8", errors="replace") if hasattr(_sys.stdout, "reconfigure") else None

import argparse
import csv
import json
import pathlib
import sys
import traceback
import time
from typing import Any

import pandas as pd
import numpy as np

_REPO = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO / "src"))

from evaluation.oracle_injector import (
    inject_errors,
    compute_f1,
    profile_natural_errors,
    InjectionManifest,
)

PREDICTIONS_DIR = _REPO / "artifacts" / "predictions" / "pilot"
METRICS_DIR = _REPO / "artifacts" / "metrics" / "pilot"
RAW_DIR = _REPO / "data" / "raw"
RULES_FILE = _REPO / "data" / "rules" / "pilot_reviewed_20.jsonl"
METRICS_DIR.mkdir(parents=True, exist_ok=True)

INJECTION_SEED = 42
N_INJECT = 20
SANDBOX_TIMEOUT = 30  # seconds


def find_csv(owner: str, slug: str, target_columns: list[str] | None = None) -> pathlib.Path | None:
    """Find the best CSV for a rule in data/raw/{owner}/{slug}/.

    Strategy:
    1. If target_columns provided: find CSV that contains ALL of those columns.
    2. Fallback: return the largest CSV (most likely the main data file).

    Searches recursively under vlatest/raw/ first, then the slug root.
    Only considers files > 10 KB.
    """
    base = RAW_DIR / owner / slug
    all_csvs: list[pathlib.Path] = []
    for search_root in [base / "vlatest" / "raw", base]:
        if search_root.exists():
            found = [c for c in search_root.rglob("*.csv") if c.stat().st_size > 10_000]
            all_csvs.extend(found)

    if not all_csvs:
        return None

    # If no column hint, return the largest
    if not target_columns:
        return max(all_csvs, key=lambda p: p.stat().st_size)

    # Try to find a CSV that contains the target columns
    for csv_path in sorted(all_csvs, key=lambda p: p.stat().st_size, reverse=True):
        try:
            header = pd.read_csv(csv_path, nrows=0)
            cols_in_file = set(header.columns)
            if all(c in cols_in_file for c in target_columns):
                return csv_path
        except Exception:
            continue

    # Fallback: largest CSV even if columns don't match
    return max(all_csvs, key=lambda p: p.stat().st_size)


def load_csv_safe(path: pathlib.Path, max_rows: int = 10_000) -> pd.DataFrame | None:
    """Load CSV with encoding fallback. Cap at max_rows to avoid memory issues."""
    for enc in ["utf-8", "latin-1", "cp1252"]:
        try:
            df = pd.read_csv(path, encoding=enc, nrows=max_rows, low_memory=False)
            if len(df) > 0:
                return df
        except Exception:
            continue
    return None


def sanitize_code(code_str: str) -> str:
    """Auto-fix known issues in LLM-generated pandas code.

    Fixes applied:
    - BUG-012: iteritems() → items() (removed in pandas 2.0)
    - Date format: replace strptime hardcoded '%Y-%m-%d' with robust pd.to_datetime
    - Date format: replace strftime/strptime calls that assume one specific format
    """
    if not code_str:
        return code_str
    # BUG-012: iteritems() removed in pandas 2.0
    code_str = code_str.replace(".iteritems()", ".items()")
    # Replace common hard-coded strptime date format assumptions with robust parsing
    # Pattern: datetime.strptime(x, '%Y-%m-%d') → pd.to_datetime(x, errors='coerce')
    import re
    # Replace strptime with specific format strings with pd.to_datetime
    code_str = re.sub(
        r"datetime\.strptime\(([^,]+),\s*['\"][^'\"]+['\"]\)",
        r"pd.to_datetime(\1, errors='coerce')",
        code_str
    )
    # Replace pd.to_datetime(col, format='%Y-%m-%d') with pd.to_datetime(col, errors='coerce')
    code_str = re.sub(
        r"pd\.to_datetime\(([^,)]+),\s*format=['\"][^'\"]+['\"](.*?)\)",
        r"pd.to_datetime(\1, errors='coerce')",
        code_str
    )
    return code_str


def execute_check_in_sandbox(code_str: str, df: pd.DataFrame, timeout: int = SANDBOX_TIMEOUT) -> tuple[list[int], str | None]:
    """Execute check(df) in isolated namespace. Returns (indices, error_message)."""
    if not code_str or not isinstance(code_str, str):
        return [], "Empty or null generated code"

    # Auto-fix known pandas 2.0 incompatibilities in generated code
    code_str = sanitize_code(code_str)

    # Build isolated namespace — include date helpers for HISTORICAL rules
    import datetime as _datetime_module
    namespace: dict[str, Any] = {
        "pd": pd,
        "np": np,
        "df": df.copy(),
        "datetime": _datetime_module,
        # Robust date parser that handles int (Excel serial), string (any format), NaT
        "parse_date": lambda x: pd.to_datetime(x, unit='D', origin='1899-12-30', errors='coerce')
            if isinstance(x, (int, float)) and not pd.isna(x)
            else pd.to_datetime(x, errors='coerce'),
    }

    try:
        # Execute the code definition
        exec(code_str, namespace)  # noqa: S102

        # Find the check function
        check_fn = namespace.get("check")
        if check_fn is None:
            # Try limpiar_regla (conference paper convention)
            check_fn = namespace.get("limpiar_regla")
        if check_fn is None:
            return [], "No check() or limpiar_regla() function defined in generated code"

        # Execute
        result = check_fn(df.copy())

        # Normalize output to list[int]
        if isinstance(result, pd.DataFrame):
            # Some generators return a DataFrame — get modified row indices
            # by comparing with original df
            return [], "check() returned DataFrame instead of list[int] — BUG-002 pattern"
        if isinstance(result, (list, pd.Index, np.ndarray)):
            try:
                indices = [int(i) for i in result]
                return indices, None
            except (TypeError, ValueError) as e:
                return [], f"Could not convert result to list[int]: {e}"
        if result is None:
            return [], None  # No violations found
        return [], f"Unexpected return type: {type(result)}"

    except Exception as e:
        tb = traceback.format_exc()
        return [], f"{type(e).__name__}: {e}\n{tb[:300]}"


def load_rules(rules_file: pathlib.Path) -> dict[str, dict]:
    """Load rules indexed by rule_id."""
    rules = {}
    with open(rules_file, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rule = json.loads(line)
                rules[rule["rule_id"]] = rule
            except json.JSONDecodeError:
                continue
    return rules


def process_config(
    config_name: str,
    rules: dict[str, dict],
    natural_errors_records: list[dict],
) -> list[dict]:
    """Process all predictions for a single config. Returns list of metric rows."""
    parquet_path = PREDICTIONS_DIR / config_name / "predictions.parquet"
    if not parquet_path.exists():
        print(f"  [SKIP] {config_name}: predictions.parquet not found at {parquet_path}")
        return []

    print(f"\n{'='*60}")
    print(f"Config: {config_name}")
    print(f"{'='*60}")

    preds = pd.read_parquet(parquet_path)
    print(f"  Loaded {len(preds)} predictions")

    metric_rows = []

    for _, row in preds.iterrows():
        rule_id = row.get("rule_id", "")
        dataset_id = row.get("dataset_id", "")
        generated_code = row.get("generated_code", "")
        syntax_pass = bool(row.get("syntax_pass", False))

        if not rule_id or not dataset_id:
            continue

        rule = rules.get(rule_id)
        if rule is None:
            print(f"  [SKIP] Rule {rule_id} not found in rules file")
            continue

        # Parse dataset_id → owner/slug
        if "/" not in dataset_id:
            print(f"  [SKIP] {rule_id}: invalid dataset_id '{dataset_id}'")
            continue
        owner, slug = dataset_id.split("/", 1)

        # Find CSV — pass target columns from rule IR to find the right file in multi-CSV datasets
        ir_cols = rule.get("ir_gold", {}).get("scope", {}).get("columns", [])
        csv_path = find_csv(owner, slug, target_columns=ir_cols if ir_cols else None)
        if csv_path is None:
            print(f"  [SKIP] {rule_id}: no CSV found for {dataset_id}")
            metric_rows.append(_make_row(rule_id, dataset_id, config_name, error="CSV not found in data/raw/"))
            continue

        # Load DataFrame
        df = load_csv_safe(csv_path)
        if df is None or len(df) == 0:
            print(f"  [SKIP] {rule_id}: failed to load CSV from {csv_path}")
            metric_rows.append(_make_row(rule_id, dataset_id, config_name, error="Failed to load CSV"))
            continue

        # Profile natural errors (once per dataset, not per rule)
        nat_key = f"{owner}/{slug}"
        if nat_key not in {r["dataset_id"] for r in natural_errors_records}:
            try:
                nat_reports = profile_natural_errors(df.copy(), nat_key)
                for nr in nat_reports:
                    natural_errors_records.append({
                        "dataset_id": nat_key,
                        "column": nr.column,
                        "error_type": nr.error_type,
                        "n_errors": nr.n_errors,
                        "description": nr.description,
                    })
            except Exception as e:
                pass  # Natural error profiling is best-effort

        # If syntax failed, F1=0
        if not syntax_pass:
            print(f"  [{rule_id}] syntax FAIL → F1=0")
            metric_rows.append(_make_row(rule_id, dataset_id, config_name, f1=0.0, precision=0.0, recall=0.0,
                                          tp=0, fp=0, fn=N_INJECT, n_rows=len(df), error="syntax_fail"))
            continue

        # Inject errors
        try:
            df_modified, manifest = inject_errors(
                df.copy(), rule, n_inject=N_INJECT, seed=INJECTION_SEED
            )
        except Exception as e:
            print(f"  [{rule_id}] inject_errors failed: {e}")
            metric_rows.append(_make_row(rule_id, dataset_id, config_name, error=f"inject_errors: {e}"))
            continue

        # Execute check(df_modified)
        t0 = time.monotonic()
        predicted_indices, exec_error = execute_check_in_sandbox(generated_code, df_modified)
        elapsed = (time.monotonic() - t0) * 1000

        if exec_error:
            print(f"  [{rule_id}] exec error: {exec_error[:80]}")
            # F1=0: code failed to execute
            metrics = compute_f1([], manifest.injected_row_indices, len(df))
            metric_rows.append(_make_row(
                rule_id, dataset_id, config_name,
                f1=0.0, precision=0.0, recall=0.0,
                tp=0, fp=0, fn=len(manifest.injected_row_indices),
                n_rows=len(df), n_injected=manifest.n_injected,
                exec_latency_ms=elapsed,
                error=exec_error[:200],
                manifest_hash=manifest.modified_hash,
                dimension=rule.get("dimension", ""),
                complexity=rule.get("complexity", ""),
            ))
            continue

        # Compute F1
        metrics = compute_f1(predicted_indices, manifest.injected_row_indices, len(df))

        f1 = metrics["f1"]
        status = "OK" if f1 >= 0.5 else "--"
        print(f"  [{rule_id}] {status} F1={f1:.3f} | P={metrics['precision']:.3f} | R={metrics['recall']:.3f} | "
              f"TP={metrics['tp']} FP={metrics['fp']} FN={metrics['fn']} | n_pred={len(predicted_indices)}")

        metric_rows.append(_make_row(
            rule_id, dataset_id, config_name,
            f1=metrics["f1"],
            precision=metrics["precision"],
            recall=metrics["recall"],
            tp=metrics["tp"],
            fp=metrics["fp"],
            fn=metrics["fn"],
            n_rows=len(df),
            n_injected=manifest.n_injected,
            n_predicted=len(predicted_indices),
            exec_latency_ms=elapsed,
            error=None,
            manifest_hash=manifest.modified_hash,
            dimension=rule.get("dimension", ""),
            complexity=rule.get("complexity", ""),
        ))

    return metric_rows


def _make_row(rule_id: str, dataset_id: str, config: str, **kwargs) -> dict:
    defaults = {
        "rule_id": rule_id,
        "dataset_id": dataset_id,
        "config": config,
        "f1": None,
        "precision": None,
        "recall": None,
        "tp": None,
        "fp": None,
        "fn": None,
        "n_rows": None,
        "n_injected": None,
        "n_predicted": None,
        "exec_latency_ms": None,
        "manifest_hash": None,
        "dimension": "",
        "complexity": "",
        "error": None,
    }
    defaults.update(kwargs)
    return defaults


def print_summary(metric_rows: list[dict], config_name: str) -> None:
    if not metric_rows:
        print(f"\n  No metrics for {config_name}")
        return

    df = pd.DataFrame(metric_rows)
    valid = df[df["f1"].notna()]

    print(f"\n{'='*60}")
    print(f"SUMMARY: {config_name}")
    print(f"{'='*60}")
    print(f"  Rules processed   : {len(df)}")
    print(f"  With F1 computed  : {len(valid)}")
    if len(valid) > 0:
        print(f"  F1 macro          : {valid['f1'].mean():.4f}")
        print(f"  F1 min / max      : {valid['f1'].min():.4f} / {valid['f1'].max():.4f}")
        print(f"  Rules F1 = 0      : {(valid['f1'] == 0).sum()}")
        print(f"  Rules F1 = 1      : {(valid['f1'] == 1.0).sum()}")
        print(f"  Rules F1 > 0.5    : {(valid['f1'] > 0.5).sum()}")
        if "dimension" in df.columns:
            print(f"\n  By dimension:")
            for dim, grp in valid.groupby("dimension"):
                print(f"    {dim:<20}: F1={grp['f1'].mean():.3f} (n={len(grp)})")
    errors = df[df["error"].notna()]
    if len(errors) > 0:
        print(f"\n  Errors/skipped    : {len(errors)}")
        for _, erow in errors.iterrows():
            print(f"    {erow['rule_id']}: {str(erow['error'])[:80]}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=str, default=None,
                        help="Single config to process (e.g. B0). Default: all.")
    parser.add_argument("--rules", type=str, default=str(RULES_FILE),
                        help=f"Path to rules JSONL (default: {RULES_FILE})")
    parser.add_argument("--n-inject", type=int, default=N_INJECT,
                        help=f"Number of errors to inject per rule (default: {N_INJECT})")
    parser.add_argument("--seed", type=int, default=INJECTION_SEED,
                        help=f"Injection seed (default: {INJECTION_SEED})")
    args = parser.parse_args()

    rules_path = pathlib.Path(args.rules)
    if not rules_path.exists():
        print(f"ERROR: rules file not found: {rules_path}", file=sys.stderr)
        return 1

    rules = load_rules(rules_path)
    print(f"Loaded {len(rules)} rules from {rules_path}")

    # Discover configs
    if args.config:
        config_dirs = [PREDICTIONS_DIR / args.config]
    else:
        config_dirs = [d for d in PREDICTIONS_DIR.iterdir() if d.is_dir()]

    if not config_dirs:
        print("ERROR: No prediction directories found", file=sys.stderr)
        return 1

    print(f"Processing {len(config_dirs)} config(s): {[d.name for d in config_dirs]}")

    natural_errors_records: list[dict] = []
    all_metrics: list[dict] = []

    for config_dir in sorted(config_dirs):
        config_name = config_dir.name
        rows = process_config(config_name, rules, natural_errors_records)
        if rows:
            # Save per-config parquet
            metrics_df = pd.DataFrame(rows)
            out_parquet = METRICS_DIR / f"{config_name}_metrics.parquet"
            metrics_df.to_parquet(out_parquet, index=False)

            # Save per-config summary CSV
            out_csv = METRICS_DIR / f"{config_name}_summary.csv"
            metrics_df.to_csv(out_csv, index=False)

            print_summary(rows, config_name)
            all_metrics.extend(rows)

            print(f"\n  Saved: {out_parquet}")
            print(f"  Saved: {out_csv}")

    # Save natural errors report
    if natural_errors_records:
        nat_df = pd.DataFrame(natural_errors_records)
        nat_path = METRICS_DIR / "natural_errors_report.csv"
        nat_df.to_csv(nat_path, index=False)
        print(f"\nNatural errors report: {nat_path} ({len(nat_df)} records across {nat_df['dataset_id'].nunique()} datasets)")

    # Print combined summary
    if all_metrics:
        combined = pd.DataFrame(all_metrics)
        print(f"\n{'='*60}")
        print("COMBINED SUMMARY — all configs")
        print(f"{'='*60}")
        valid_all = combined[combined["f1"].notna()]
        for cfg, grp in valid_all.groupby("config"):
            print(f"  {cfg:<15}: F1={grp['f1'].mean():.4f}  n={len(grp)}  "
                  f"(F1>0.5: {(grp['f1']>0.5).sum()}/{len(grp)})")

        # BUG-001 validation check
        b3_r120 = combined[(combined["config"].str.startswith("B3")) & (combined["rule_id"] == "R-0120")]
        if len(b3_r120) > 0:
            f1_val = b3_r120.iloc[0]["f1"]
            if f1_val is not None and f1_val < 1.0:
                print(f"\nOK BUG-001 validation PASSED: B3/R-0120 F1={f1_val:.4f} < 1.0 (semantic error detected)")
            elif f1_val == 1.0:
                print(f"\nFAIL BUG-001 validation FAILED: B3/R-0120 F1=1.0 (injector may not be working correctly)")
            else:
                print(f"\n? BUG-001: B3/R-0120 F1=None (execution error)")

        # Save combined
        combined_path = METRICS_DIR / "all_configs_metrics.parquet"
        combined.to_parquet(combined_path, index=False)
        print(f"\nAll configs combined: {combined_path}")

    print(f"\nNext: update reports/results.md §2.4 with these F1 values")
    return 0


if __name__ == "__main__":
    sys.exit(main())
